<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Recharge via bkash'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3"><i class="icon-user"></i> <?php echo app('translator')->get('Recharge via bkash'); ?></h4>
                    
                             
            <?php if($errors->any()): ?>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="alert alert-danger"><?php echo e($error); ?></div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
     
               <div style="padding:20px;display:inline-block"> 
                <a href="<?php echo e(route('user.bkash')); ?>">
                    <img src="https://freelogopng.com/images/all_img/1656227753bkash-logo-png-download.png" style="width:50px" />
                </a>
                </div>
                
                  
                <form action="" method="post">
                    <?php echo csrf_field(); ?>
                    <label>Amount</label>
                    <input type="number" name="amount" class="form-control" required/>
                    <br/>
                    <button class="btn btn-success">Submit</button>
                </form>
               
               
               
                
                
                </div>
            </div>
        </div>
    </div>
</div>







<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function (e) {
            "use strict";

            $('#image').change(function(){
                let reader = new FileReader();
                reader.onload = (e) => {
                    $('#image_preview_container').attr('src', e.target.result);
                }
                reader.readAsDataURL(this.files[0]);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/bkash.blade.php ENDPATH**/ ?>