

<?php $__env->startSection('title'); ?>
    অর্ডার বিস্তারিত
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">টিন অর্ডার বিস্তারিত</h5>
                </div>
                <div class="card-body">
                    <!-- Order Info -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>অর্ডার আইডি:</strong> #<?php echo e($order->id); ?>

                        </div>
                        <div class="col-md-6">
                            <strong>তারিখ:</strong> <?php echo e($order->created_at->format('d/m/Y h:i A')); ?>

                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>সার্ভিস টাইপ:</strong>
                            <?php switch($order->type):
                                case (1): ?> টিন সার্টিফিকেট অর্ডার <?php break; ?>
                                <?php case (2): ?> নিউ টিন আবেদন <?php break; ?>
                                <?php case (3): ?> জিরো রিটার্ন আবেদন <?php break; ?>
                                <?php case (4): ?> টিন সার্টিফিকেট কারেকশন <?php break; ?>
                                <?php case (5): ?> টিন আইডি পাসওয়ার্ড সেট <?php break; ?>
                            <?php endswitch; ?>
                        </div>
                        <div class="col-md-6">
                            <strong>স্ট্যাটাস:</strong>
                            <?php if($order->status == 0): ?>
                                <span class="badge bg-warning">অপেক্ষমান</span>
                            <?php elseif($order->status == 1): ?>
                                <span class="badge bg-info">প্রক্রিয়াধীন</span>
                            <?php elseif($order->status == 2): ?>
                                <span class="badge bg-success">সম্পন্ন</span>
                            <?php else: ?>
                                <span class="badge bg-danger">বাতিল</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <hr>

                    <!-- Form Data -->
                    <h6 class="mb-3">জমা দেওয়া তথ্য:</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tbody>
                                <?php
                                    $formData = is_string($order->form_data) ? json_decode($order->form_data, true) : (array)$order->form_data;
                                ?>

                                <?php $__currentLoopData = $formData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($value): ?>
                                    <tr>
                                        <td style="width: 40%;">
                                            <strong>
                                                <?php switch($key):
                                                    case ('nid_tin_mobile'): ?> Nid/Tin/Mobile No <?php break; ?>
                                                    <?php case ('nid_no'): ?> Nid No <?php break; ?>
                                                    <?php case ('mobile_no'): ?> Mobile No <?php break; ?>
                                                    <?php case ('father_nid'): ?> Father Nid <?php break; ?>
                                                    <?php case ('mother_nid'): ?> Mother Nid <?php break; ?>
                                                    <?php case ('nid_number'): ?> Nid Number <?php break; ?>
                                                    <?php case ('tin_number'): ?> Tin Number <?php break; ?>
                                                    <?php case ('mobile_number'): ?> Mobile Number <?php break; ?>
                                                    <?php case ('user_id'): ?> User Id <?php break; ?>
                                                    <?php case ('pass'): ?> Password <?php break; ?>
                                                    <?php case ('correction_info'): ?> Correction Info <?php break; ?>
                                                    <?php case ('tin_no'): ?> Tin No <?php break; ?>
                                                    <?php case ('id_pass'): ?> Id & Pass <?php break; ?>
                                                    <?php default: ?> <?php echo e(ucfirst(str_replace('_', ' ', $key))); ?> <?php break; ?>
                                                <?php endswitch; ?>
                                            </strong>
                                        </td>
                                        <td><?php echo e($value); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($order->admin_note): ?>
                    <hr>
                    <div class="alert alert-info">
                        <strong>এডমিন নোট:</strong>
                        <p class="mb-0 mt-2"><?php echo e($order->admin_note); ?></p>
                    </div>
                    <?php endif; ?>

                    <div class="mt-4">
                        <a href="<?php echo e(route('user.tin.order.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> ফিরে যান
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/tin_order/view.blade.php ENDPATH**/ ?>