
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('login', 'active'); ?>
<?php $__env->startPush('style'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }


        .login-page {
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
        }

        /* Animated Background Effects */
        .bg-animation {
            position: absolute;
            width: 100%;
            z-index: 1;
        }

        .gradient-orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(120px);
            opacity: 0.4;
            animation: float-orb 20s ease-in-out infinite;
        }

        .orb-1 {
            width: 600px;
            height: 600px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            top: -200px;
            left: -100px;
        }

        .orb-2 {
            width: 500px;
            height: 500px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            bottom: -150px;
            right: -100px;
            animation-delay: 10s;
        }

        @keyframes  float-orb {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(80px, 80px) scale(1.1); }
        }

        .particles {
            position: absolute;
            width: 100%;
            height: 100%;
        }

        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            animation: particle-float 15s linear infinite;
        }

        @keyframes  particle-float {
            0% { transform: translateY(100vh) translateX(0); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100vh) translateX(100px); opacity: 0; }
        }

        .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
        .particle:nth-child(2) { left: 25%; animation-delay: 3s; }
        .particle:nth-child(3) { left: 45%; animation-delay: 6s; }
        .particle:nth-child(4) { left: 60%; animation-delay: 2s; }
        .particle:nth-child(5) { left: 80%; animation-delay: 8s; }
        .particle:nth-child(6) { left: 35%; animation-delay: 5s; }
        .particle:nth-child(7) { left: 70%; animation-delay: 7s; }
        .particle:nth-child(8) { left: 90%; animation-delay: 4s; }

        /* Login Container */
        .login-container {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 550px;
            margin: 20px;
        }

        .login-card {
            background: rgba(20, 20, 30, 0.85);
            backdrop-filter: blur(40px);
            border-radius: 28px;
            padding: 45px 40px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.7);
        }

        /* Logo Section */
        .logo-section {
            text-align: center;
            margin-bottom: 35px;
        }

        .logo-wrapper {
            display: inline-block;
            margin-bottom: 20px;
            animation: logo-float 4s ease-in-out infinite;
        }

        @keyframes  logo-float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }

        .logo-wrapper img {
            width: 90px;
            height: 90px;
            object-fit: contain;
            filter: drop-shadow(0 10px 30px rgba(102, 126, 234, 0.5));
        }

        .login-title {
            font-size: 32px;
            font-weight: 800;
            color: white;
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }

        .login-subtitle {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.6);
            font-weight: 400;
        }

        /* Form Styling */
        .form-group {
            margin-bottom: 20px;
        }

        .input-label {
            display: block;
            color: rgba(255, 255, 255, 0.8);
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
            letter-spacing: 0.3px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.4);
            font-size: 17px;
            transition: all 0.3s ease;
            pointer-events: none;
        }

        .form-control {
            width: 100%;
            background: rgba(255, 255, 255, 0.05) !important;
            border: 2px solid rgba(255, 255, 255, 0.1) !important;
            border-radius: 14px !important;
            color: white !important;
            padding: 15px 18px 15px 50px !important;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.08) !important;
            border-color: #667eea !important;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15) !important;
            outline: none;
        }

        .form-control:focus ~ .input-icon {
            color: #667eea;
            transform: translateY(-50%) scale(1.1);
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.35);
        }



        @keyframes  shimmer {
            0% { left: -100%; }
            100% { left: 100%; }
        }


        /* Buttons */
        .btn {
            width: 100%;
            padding: 16px 28px;
            border-radius: 14px;
            font-size: 15px;
            font-weight: 700;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.6s ease;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
            margin-bottom: 15px;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 45px rgba(102, 126, 234, 0.5);
        }

        .btn-success {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
            box-shadow: 0 15px 35px rgba(72, 187, 120, 0.4);
        }

        .btn-success:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 45px rgba(72, 187, 120, 0.5);
        }

        .btn i {
            margin-right: 10px;
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 22px 0;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(255, 255, 255, 0.1);
        }

        .divider span {
            padding: 0 18px;
            color: rgba(255, 255, 255, 0.5);
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .forgot-link {
            text-align: center;
            margin-top: 20px;
        }

        .forgot-link a {
            color: #667eea !important;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 7px;
            transition: all 0.3s ease;
        }

        .forgot-link a:hover {
            color: #764ba2 !important;
            gap: 10px;
        }

        /* Alert */
        .alert {
            border-radius: 14px;
            padding: 14px 18px;
            margin-bottom: 20px;
            border: none;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 13px;
            animation: slideIn 0.4s ease;
        }

        @keyframes  slideIn {
            from {
                opacity: 0;
                transform: translateY(-15px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-danger {
            background: rgba(245, 85, 108, 0.18);
            color: #fc8181;
            border: 1px solid rgba(245, 85, 108, 0.3);
        }

        /* Loading */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            backdrop-filter: blur(10px);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }

        .loading-overlay.active {
            display: flex;
        }

        .spinner {
            width: 55px;
            height: 55px;
            border: 4px solid rgba(255, 255, 255, 0.1);
            border-top-color: #667eea;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        @keyframes  spin {
            to { transform: rotate(360deg); }
        }

        /* Responsive */
        @media (max-width: 576px) {
            .login-card {
                padding: 35px 28px;
                border-radius: 24px;
            }

            .login-title {
                font-size: 28px;
            }

            .logo-wrapper img {
                width: 75px;
                height: 75px;
            }



            .form-control {
                padding: 14px 16px 14px 48px !important;
            }

            .btn {
                padding: 15px 24px;
                font-size: 14px;
            }
        }

        /* Captcha Styles */
        .captcha-container {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .captcha-display {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 15px;
            padding: 10px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 6px;
        }

        .captcha-number {
            font-size: 24px;
            font-weight: bold;
            padding: 8px 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
            min-width: 50px;
            text-align: center;
        }

        .captcha-operator {
            font-size: 20px;
            color: #63b3ed;
        }

        .captcha-equals {
            font-size: 20px;
            color: #fff;
        }

        .captcha-input-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .captcha-refresh {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .captcha-refresh:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: rotate(45deg);
        }

        .captcha-label {
            display: block;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 8px;
            font-size: 14px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="login-page">
        <!-- Animated Background -->
        <div class="bg-animation">
            <div class="gradient-orb orb-1"></div>
            <div class="gradient-orb orb-2"></div>
        </div>

        <div class="particles">
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
        </div>

        <!-- Login Container -->
        <div class="login-container">
            <div class="login-card">
                <form method="post" action="<?php echo e(route('login.submit')); ?>" id="loginForm">
                    <?php echo csrf_field(); ?>

                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger">
                                <i class="fas fa-circle-exclamation"></i>
                                <span><?php echo e($error); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <!-- Logo & Title -->
                    <div class="logo-section">
                        <div class="logo-wrapper">
                            <img src="<?php echo e(asset('assets/uploads/logo/Screenshot_2025-10-18_021531-removebg-preview.png')); ?>" alt="Logo">
                        </div>
                        <h2 class="login-title">Welcome Back</h2>
                        <p class="login-subtitle">Sign in to continue to your account</p>
                    </div>

                    <!-- Email Input -->
                    <div class="form-group">
                        <label class="input-label">Email Address</label>
                        <div class="input-wrapper">
                            <input class="form-control" type="email" name="username" placeholder="Enter your email" required autocomplete="email">
                            <i class="fas fa-envelope input-icon"></i>
                        </div>
                    </div>

                    <!-- Password Input -->
                    <div class="form-group">
                        <label class="input-label">Password</label>
                        <div class="input-wrapper">
                            <input class="form-control" type="password" name="password" placeholder="Enter your password" required autocomplete="current-password">
                            <i class="fas fa-lock input-icon"></i>
                        </div>
                    </div>

                    <!-- Captcha -->
                    <!-- Captcha Section -->
                    <div class="captcha-container">
                        <label class="captcha-label">
                            <i class="fas fa-shield-alt me-1"></i> Please solve the captcha
                        </label>

                        <div class="captcha-display">
                            <span class="captcha-number"><?php echo e($num1 ?? rand(1, 9)); ?></span>
                            <span class="captcha-operator">+</span>
                            <span class="captcha-number"><?php echo e($num2 ?? rand(1, 9)); ?></span>
                            <span class="captcha-equals">=</span>
                            <span class="captcha-number">?</span>
                        </div>

                        <div class="captcha-input-group">
                            <input type="hidden" name="num1" value="<?php echo e($num1 ?? ''); ?>">
                            <input type="hidden" name="num2" value="<?php echo e($num2 ?? ''); ?>">

                            <div style="flex-grow: 1;">
                                <input class="form-control"
                                       type="number"
                                       id="captcha"
                                       name="captcha"
                                       placeholder="Enter sum here"
                                       required
                                       min="0"
                                       max="20">
                            </div>

                            <button type="button" class="captcha-refresh" onclick="refreshCaptcha()" title="Refresh Captcha">
                                <i class="fas fa-redo"></i>
                            </button>
                        </div>
                    </div>


                    <!-- Sign In Button -->
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-arrow-right-to-bracket"></i>
                        Sign In
                    </button>

                    <!-- Register Button -->
                    <?php if(get_settings()->register_option == '1'): ?>
                        <div class="divider">
                            <span>OR</span>
                        </div>
                        <a class="btn btn-success" href="<?php echo e(route('register')); ?>">
                            <i class="fas fa-user-plus"></i>
                            Create New Account
                        </a>
                    <?php endif; ?>

                    <!-- Forgot Password Link -->
                    <div class="forgot-link">
                        <a href="<?php echo e(route('password.request')); ?>">
                            <i class="fas fa-key"></i>
                            <span>Forgot your password?</span>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        function refreshCaptcha() {
            // Generate new random numbers
            const num1 = Math.floor(Math.random() * 9) + 1;
            const num2 = Math.floor(Math.random() * 9) + 1;

            // Update the display
            document.querySelectorAll('.captcha-number')[0].textContent = num1;
            document.querySelectorAll('.captcha-number')[1].textContent = num2;

            // Update hidden inputs
            document.querySelector('input[name="num1"]').value = num1;
            document.querySelector('input[name="num2"]').value = num2;

            // Clear the captcha input
            document.getElementById('captcha').value = '';

            // Focus on captcha field
            document.getElementById('captcha').focus();
        }

        // Add form submission handler
        document.getElementById('loginForm').addEventListener('submit', function() {
            document.getElementById('loadingOverlay').classList.add('active');
        });

        // Auto-refresh captcha every 2 minutes for security
        setInterval(refreshCaptcha, 120000);


        // Input focus effects
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.closest('.input-wrapper').style.transform = 'scale(1.01)';
            });

            input.addEventListener('blur', function() {
                this.closest('.input-wrapper').style.transform = 'scale(1)';
            });
        });

        // Auto-dismiss alerts
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.transition = 'all 0.3s ease';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);



        // Focus on email field on page load
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('email').focus();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project files\ifixfast24\resources\views/auth/login.blade.php ENDPATH**/ ?>