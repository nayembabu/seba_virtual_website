
<?php $__env->startSection('title'); ?>
    নাগরিক সনদ তালিকা
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="text-right mb-3">
            <a href="<?php echo e(route('user.nagorik-sonod.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus"></i> নতুন সনদ তৈরি করুন
            </a>
        </div>

        <div style="overflow-x:auto;">
            <table class="categories-show-table table table-hover table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col"><?php echo app('translator')->get('নং'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('নাম'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('সার্টিফিকেট নং'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('এনআইডি নম্বর'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('সার্টিফিকেট'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('যাচাই'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('তারিখ'); ?></th>
                        <th scope="col" style="text-align:center"><?php echo app('translator')->get('অ্যাকশন'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sonods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sonod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('নং'); ?>"><?php echo e($key + 1); ?></td>
                            <td data-label="<?php echo app('translator')->get('নাম'); ?>"><?php echo e($sonod->name); ?></td>
                            <td data-label="<?php echo app('translator')->get('সার্টিফিকেট নং'); ?>"><?php echo e($sonod->certificate_number); ?></td>
                            <td data-label="<?php echo app('translator')->get('এনআইডি নম্বর'); ?>"><?php echo e($sonod->nid_number); ?></td>
                            <td data-label="<?php echo app('translator')->get('সার্টিফিকেট'); ?>">
                                <a href="<?php echo e(route('user.nagorik-sonod.show', $sonod->id)); ?>" class="btn btn-primary" target="_blank">
                                    <i class="fas fa-print"></i> প্রিন্ট
                                </a>
                            </td>
                            <td data-label="<?php echo app('translator')->get('যাচাই'); ?>">
                                <a href="<?php echo e(route('verify.certificate', $sonod->certificate_number)); ?>" class="btn btn-success" target="_blank">
                                    <i class="fas fa-check"></i> যাচাই
                                </a>
                            </td>
                            <td data-label="<?php echo app('translator')->get('তারিখ'); ?>">
                                <?php echo e(date('d F Y', strtotime($sonod->created_at))); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('অ্যাকশন'); ?>" class="text-lg-center text-right">
                                <form action="<?php echo e(route('user.nagorik-sonod.destroy', $sonod->id)); ?>" 
                                      method="POST" 
                                      style="display:inline-block"
                                      onsubmit="return confirm('আপনি কি নিশ্চিত যে আপনি এই সনদটি মুছে ফেলতে চান?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger">
                                        <i class="fas fa-trash"></i> মুছুন
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-danger" colspan="8"><?php echo app('translator')->get('কোন তথ্য পাওয়া যায়নি'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if(method_exists($sonods, 'links')): ?>
            <?php echo e($sonods->links('partials.pagination')); ?>

        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        // Any additional JavaScript if needed
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/nagorik-sonod/index.blade.php ENDPATH**/ ?>