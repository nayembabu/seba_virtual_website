<?php $__env->startSection('title','Register Fee Payment'); ?>
<?php $__env->startSection('register','active'); ?>
<?php $__env->startSection('content'); ?>
    <section class="clean-block clean-form dark">
            <div class="container">
                <div class="block-heading">
                    <h2 class="text-info">Register Fee Payment </h2>
                </div>
                <form method="post" action="">
                    
                    <div class="info" style="padding:4px;border:1px solid purple">
                        
                       <h4>Your Information</h4> 
                       Name : <b> <?php echo e($user->name); ?> </b> <br/>
                       Email : <b> <?php echo e($user->email); ?> </b> <br/>
                       Phone : <b> <?php echo e($user->phone); ?> </b> <br/>
                       Gender : <b> <?php echo e($user->gender); ?> </b> <br/>
                       Date of Birth : <b> <?php echo e($user->dob); ?> </b> <br/>
                       NID : <b> <?php echo e($user->nid); ?> </b> <br/>
                       
                    </div>
                    
                    
                    <?php echo csrf_field(); ?>
                    
                     <?php if($errors->any()): ?>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="alert alert-danger"><?php echo e($error); ?></div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?> 
                    <p class="text-center">Register fee is <?php echo e(get_settings()->register_fee); ?>TK . Click "Pay Now" button and you will be redirected to payment.</p>
                    
                    <button class="btn btn-success btn-block" type="submit">Pay Now</button>
                    
                    <a class="btn btn-danger btn-block" href="<?php echo e(route('register')); ?>">Cancel</a>
                   
                    </form>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/auth/bkash.blade.php ENDPATH**/ ?>