
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("Transactions"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .fa-ellipsis-v:before {
            content: "\f142";
        }
    </style>
    
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
        
           
               <br/>
          
                <table class="categories-show-table table table-hover table-striped table-bordered">
                    <thead class="thead-dark">
                    <tr>
                       
                        <th scope="col"><?php echo app('translator')->get('No.'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Details'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Type'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('TX ID'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                       
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            
                            <td data-label="<?php echo app('translator')->get('No.'); ?>">
                                <?php echo e($key + 1); ?>

                                </td>
                             <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                <?php echo e($transaction->amount); ?>

                             </td>
                            <td data-label="<?php echo app('translator')->get('Details'); ?>">
                                <?php echo e($transaction->details); ?>

                             </td>
                             
                             <td data-label="<?php echo app('translator')->get('Type'); ?>">
                                <?php if( $transaction->type == '+'): ?>
                                <b style="color:green">Credit</b>
                                <?php else: ?>
                                <b style="color:red">Debit</b>
                                <?php endif; ?>
                            </td>
                            
                             <td data-label="<?php echo app('translator')->get('TX ID'); ?>">
                                <?php echo e($transaction->tx_id); ?>

                                </td>
                            
                            <td data-label="<?php echo app('translator')->get('Date'); ?>">
                                <?php echo e(date('d F Y',strtotime(@$transaction->created_at))); ?>

                            </td>
                          
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-danger" colspan="9"><?php echo app('translator')->get('No Data'); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($transactions->appends(@$_GET)->links('partials.pagination')); ?>

            </div>
        </div>
    </div>
    
    
    
   
    

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script>
         $(document).on('click', '.more-details', function () {
            var id = $(this).attr('data-id');
            var status = $(this).attr('data-status');
            $('#ht').html('');
            $('#status-ch').modal('show');
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/transactions.blade.php ENDPATH**/ ?>