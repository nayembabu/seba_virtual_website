
<?php $__env->startSection('title'); ?>
    স্মার্ট কার্ড তৈরি
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
        }
        
        .form-group {
            margin-bottom: 1.25rem;
        }

        .card-body {
            padding: 1.25rem;
        }

        .form-control {
            padding: 0.75rem 1rem;
            height: calc(1.5em + 1.5rem + 2px);
            font-size: 1rem;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            transition: border-color 0.15s ease-in-out;
            background-color: #fff;
        }

        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
            background-color: #fff;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #495057;
        }

        .form-control.is-invalid {
            border-color: #e74a3b;
            padding-right: calc(1.5em + 0.75rem);
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23e74a3b' viewBox='0 0 12 12'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23e74a3b' stroke='none'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right calc(0.375em + 0.1875rem) center;
            background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
        }

        .card {
            border: 1px solid #e3e6f0;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            background: #fff;
            margin-bottom: 1.5rem;
            border-radius: 0.5rem;
        }

        .card-body {
            padding: 2rem;
        }

        .card-header {
            background-color: transparent;
            border-bottom: 1px solid #e3e6f0;
            padding: 1.5rem 2rem;
        }

        .card-header h5 {
            margin: 0;
            color: #4e73df;
            font-weight: 500;
        }

        .required-label::after {
            content: " *";
            color: #e74a3b;
            font-weight: bold;
        }

        .img-preview {
            max-width: 160px;
            max-height: 160px;
            margin: 15px auto;
            border: 1px solid #dee2e6;
            padding: 3px;
            border-radius: 4px;
            display: block;
        }

        .photo-upload-section {
            text-align: center;
            margin-top: 2rem;
        }

        .custom-file {
            position: relative;
            display: inline-block;
            width: 100%;
            height: calc(1.5em + 1.25rem + 2px);
            margin-bottom: 0;
        }

        .custom-file-input {
            position: relative;
            z-index: 2;
            width: 100%;
            height: calc(1.5em + 1.25rem + 2px);
            margin: 0;
            opacity: 0;
            cursor: pointer;
        }

        .custom-file-label {
            position: absolute;
            top: 0;
            right: 0;
            left: 0;
            z-index: 1;
            height: calc(1.5em + 1.25rem + 2px);
            padding: 0.625rem 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
        }

        .custom-file-label::after {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            z-index: 3;
            display: block;
            height: calc(1.5em + 1.25rem);
            padding: 0.625rem 1rem;
            line-height: 1.5;
            color: #495057;
            content: "Browse";
            background-color: #e9ecef;
            border-left: inherit;
            border-radius: 0 0.25rem 0.25rem 0;
        }

        #photo-preview, #signature-preview {
            width: 160px;
            height: 160px;
            border: 2px dashed #dee2e6;
            margin: 10px 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }

        #photo-preview img, #signature-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .alert {
            border-radius: 0.35rem;
            border-left: 0.25rem solid !important;
        }

        .alert-info {
            color: #1c606a;
            background-color: #eef8fb;
            border-color: #36b9cc !important;
        }

        .alert-danger {
            color: #78261f;
            background-color: #fef0ed;
            border-color: #e74a3b !important;
        }

        .btn {
            padding: 0.5rem 1.25rem;
            font-weight: 500;
            border-radius: 0.35rem;
            transition: all 0.15s ease-in-out;
        }

        .btn-primary {
            background-color: #4e73df;
            border-color: #4e73df;
        }

        .btn-primary:hover {
            background-color: #2e59d9;
            border-color: #2653d4;
            transform: translateY(-1px);
        }

        .btn-dark {
            background-color: #5a5c69;
            border-color: #5a5c69;
        }

        .btn-dark:hover {
            background-color: #484a54;
            border-color: #42444e;
        }

        .form-text {
            font-size: 0.875rem;
            color: #858796;
        }

        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 16px 12px;
        }

        @media (max-width: 768px) {
            .card-body {
                padding: 1rem;
            }
            
            .form-group {
                margin-bottom: 1rem;
            }

            .btn {
                display: block;
                width: 100%;
                margin: 0.5rem 0;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php
    $serviceCharge = \App\Models\ServiceCharge::where('service_name', 'smartcard')->first();
?>

<?php $__env->startSection('content'); ?>
        <?php if($chargeAmount > 0): ?>
            <div class="alert alert-info border-info mb-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-info-circle fa-2x mr-3"></i>
                    <div>
                        <h4 class="alert-heading mb-1">সার্ভিস চার্জ</h4> 
                        <p class="mb-0"  >প্রতিটি কার্ড তৈরির জন্য <span class="font-weight-bold"  style="color:red; " > <?php echo e(number_format($serviceCharge->amount, 1)); ?></span> টাকা কাটা হবে।</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

<div class="card card-custom m-0 m-md-4 my-4 m-md-0 shadow">
    <div class="card-body">
                <div class="row justify-content-between mb-4">
            <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center">
                    <h3 class="card-title text-primary mb-0">
                        <i class="fas fa-id-card"></i> স্মার্ট কার্ড তৈরি
                    </h3>
                    <a href="<?php echo e(route('user.smartcard.index')); ?>" class="btn btn-dark">
                        <i class="fas fa-arrow-left"></i> তালিকায় ফিরে যান
                    </a>
                </div>
            </div>
        </div>

        <!-- PDF Upload Section -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card border-left-info shadow-sm">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <i class="fas fa-file-pdf fa-3x text-info"></i>
                            </div>
                            <div class="col">
                                <h5 class="mb-2"><i class="fas fa-magic mr-2"></i>পিডিএফ থেকে অটো পূরণ</h5>
                                <p class="mb-0 text-muted">এনআইডি পিডিএফ আপলোড করুন এবং সমস্ত তথ্য স্বয়ংক্রিয়ভাবে পূরণ হবে</p>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col">
                                <div class="form-group mb-0">
                                    <label for="pdfUpload" class="mb-2">
                                        <i class="fas fa-file-pdf mr-1"></i><strong>পিডিএফ ফাইল নির্বাচন করুন</strong>
                                    </label>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="pdfUpload" name="pdf" accept=".pdf">
                                        <label class="custom-file-label" for="pdfUpload">পিডিএফ ফাইল ব্রাউজ করুন...</label>
                                    </div>
                                    <small class="form-text">শুধুমাত্র PDF ফাইল আপলোড করুন (সর্বোচ্চ 5MB) - প্রক্রিয়াকরণ সময় ৩০ সেকেন্ড থেকে ২ মিনিট হতে পারে</small>
                                    <div id="pdfUploadStatus" style="margin-top: 10px; display: none;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger border-left border-danger border-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-exclamation-circle fa-2x mr-3"></i>
                    <div>
                        <h4 class="alert-heading mb-1">ত্রুটি সংশোধন করুন!</h4>
                        <ul class="list-unstyled mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fas fa-times-circle mr-2"></i><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <form action="<?php echo e(route('user.smartcard.store')); ?>" method="POST" enctype="multipart/form-data" class="form needs-validation" novalidate>
            <?php echo csrf_field(); ?>
            
            <div class="row">
                <!-- All form fields in one card -->
                <div class="col-12">
                    <div class="card shadow-sm border-0 mb-4">
                        <div class="card-body">
                            <div class="row">
                                
                                <div class="col-12">
                                    <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-user mr-1"></i>নাম (বাংলায়)
                                        </label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['name_bn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="name_bn" name="name_bn" value="<?php echo e(old('name_bn')); ?>" 
                                               placeholder="বাংলায় নাম লিখুন" required>
                                        <?php $__errorArgs = ['name_bn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-user mr-1"></i>Name (English)
                                        </label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="name_en" name="name_en" value="<?php echo e(old('name_en')); ?>" 
                                               placeholder="ENTER NAME IN ENGLISH" required>
                                        <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-male mr-1"></i>পিতার নাম
                                        </label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="father_name" name="father_name" value="<?php echo e(old('father_name')); ?>" 
                                               placeholder="পিতার নাম লিখুন" required>
                                        <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-female mr-1"></i>মাতার নাম
                                        </label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="mother_name" name="mother_name" value="<?php echo e(old('mother_name')); ?>" 
                                               placeholder="মাতার নাম লিখুন" required>
                                        <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-calendar-alt mr-1"></i>জন্ম তারিখ
                                        </label>
                                        <input type="date" class="form-control <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" required>
                                        <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-map-marker-alt mr-1"></i>জন্মস্থান
                                        </label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['place_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="place_of_birth" name="place_of_birth" value="<?php echo e(old('place_of_birth')); ?>" 
                                               placeholder="জন্মস্থানের নাম লিখুন" required>
                                        <?php $__errorArgs = ['place_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-id-card mr-1"></i>জাতীয় পরিচয়পত্র নম্বর
                                        </label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['nid_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="nid_no" name="nid_no" value="<?php echo e(old('nid_no')); ?>" 
                                               placeholder="১০ অথবা ১৭ ডিজিটের এনআইডি নম্বর" required>
                                        <?php $__errorArgs = ['nid_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <i class="fas fa-tint mr-1"></i>রক্তের গ্রুপ
                                        </label>
                                        <select class="form-control <?php $__errorArgs = ['blood_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="blood_group" name="blood_group">
                                            <option value="">রক্তের গ্রুপ নির্বাচন করুন</option>
                                            <?php $__currentLoopData = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($group); ?>" <?php echo e(old('blood_group') == $group ? 'selected' : ''); ?>>
                                                    <?php echo e($group); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['blood_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-calendar-check mr-1"></i>ইস্যু তারিখ
                                        </label>
                                        <input type="date" class="form-control <?php $__errorArgs = ['issue_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="issue_date" name="issue_date" value="<?php echo e(old('issue_date', date('Y-m-d'))); ?>" required>
                                        <?php $__errorArgs = ['issue_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-venus-mars mr-1"></i>লিঙ্গ
                                        </label>
                                        <select class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="gender" name="gender" required>
                                            <option value="">লিঙ্গ নির্বাচন করুন</option>
                                            <option value="male" <?php echo e(old('gender') == 'male' ? 'selected' : ''); ?>>পুরুষ</option>
                                            <option value="female" <?php echo e(old('gender') == 'female' ? 'selected' : ''); ?>>মহিলা</option>
                                            <option value="other" <?php echo e(old('gender') == 'other' ? 'selected' : ''); ?>>অন্যান্য</option>
                                        </select>
                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="required-label">
                                            <i class="fas fa-home mr-1"></i>স্থায়ী ঠিকানা
                                        </label>
                                        <textarea class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                  id="address" name="address" rows="3" 
                                                  placeholder="আপনার স্থায়ী ঠিকানা লিখুন" required><?php echo e(old('address')); ?></textarea>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Photo & Signature Upload Section -->
                <div class="col-12">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="required-label">ছবি</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="photo" name="photo" accept=".jpg,.jpeg,.png">
                                        <label class="custom-file-label" for="photo">Browse</label>
                                    </div>
                                </div>
                                <div id="photo-preview" class="mt-2"></div>
                                <small class="form-text text-muted">সর্বোচ্চ সাইজ: ২MB | ফরম্যাট: JPG, JPEG, PNG (পিডিএফ থেকে স্বয়ংক্রিয়ভাবে পূরণ হতে পারে)</small>
                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="required-label">স্বাক্ষর</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input <?php $__errorArgs = ['signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="signature" name="signature" accept=".jpg,.jpeg,.png">
                                        <label class="custom-file-label" for="signature">Browse</label>
                                    </div>
                                </div>
                                <div id="signature-preview" class="mt-2"></div>
                                <small class="form-text text-muted">সর্বোচ্চ সাইজ: ২MB | ফরম্যাট: JPG, JPEG, PNG (পিডিএফ থেকে স্বয়ংক্রিয়ভাবে পূরণ হতে পারে)</small>
                                <?php $__errorArgs = ['signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                               
            <div class="row">
                <div class="col-md-12 text-center">
                    <button type="submit" class="btn btn-primary btn-lg px-5">
                        <i class="fas fa-save mr-2"></i>স্মার্ট কার্ড তৈরি করুন
                    </button>
                    <a href="<?php echo e(route('user.smartcard.index')); ?>" class="btn btn-danger btn-lg px-5 ml-3">
                        <i class="fas fa-times mr-2"></i>বাতিল করুন
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<style>
.form-card {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    padding: 20px;
    margin-bottom: 20px;
}

.form-section {
    margin-bottom: 20px;
}

.form-section h3 {
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
    margin-bottom: 20px;
}

.preview-container {
    margin-top: 30px;
}

label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

.img-thumbnail {
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
    max-height: 100px;
}

.btn {
    margin: 0 5px;
}

.form-text {
    color: #6c757d;
    font-size: 0.875rem;
}
</style>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // File input label update
    document.querySelectorAll('.custom-file-input').forEach(input => {
        input.addEventListener('change', function(e) {
            const fileName = e.target.files[0]?.name || 'পিডিএফ ফাইল ব্রাউজ করুন...';
            const label = e.target.nextElementSibling;
            label.textContent = fileName;
        });
    });

    // Photo preview
    const photoInput = document.getElementById('photo');
    if (photoInput) {
        photoInput.addEventListener('change', function(e) {
            const preview = document.getElementById('photo-preview');
            const file = e.target.files[0];
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.innerHTML = `<img src="${e.target.result}" style="max-width: 160px; max-height: 160px;">`;
                };
                reader.readAsDataURL(file);
            } else {
                preview.innerHTML = '';
            }
        });
    }

    // Signature preview
    const signatureInput = document.getElementById('signature');
    if (signatureInput) {
        signatureInput.addEventListener('change', function(e) {
            const preview = document.getElementById('signature-preview');
            const file = e.target.files[0];
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.innerHTML = `<img src="${e.target.result}" style="max-width: 160px; max-height: 160px;">`;
                };
                reader.readAsDataURL(file);
            } else {
                preview.innerHTML = '';
            }
        });
    }

    // PDF Upload and Parse
    let pdfUploadAbortController = null;
    
    // Function to convert date formats
    function convertDateToISO(dateStr) {
        if (!dateStr) return '';
        
        // If already in YYYY-MM-DD format, return as is
        if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
            return dateStr;
        }
        
        // Parse "25 Sep 1993" format
        const months = {
            'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04', 'May': '05', 'Jun': '06',
            'Jul': '07', 'Aug': '08', 'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12'
        };
        
        // Try to parse various date formats
        let match = dateStr.match(/(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})/);
        if (match) {
            const day = match[1].padStart(2, '0');
            const month = months[match[2]] || match[2];
            const year = match[3];
            return `${year}-${month}-${day}`;
        }
        
        // Try DD/MM/YYYY format
        match = dateStr.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (match) {
            const day = match[1].padStart(2, '0');
            const month = match[2].padStart(2, '0');
            const year = match[3];
            return `${year}-${month}-${day}`;
        }
        
        // Try DD-MM-YYYY format
        match = dateStr.match(/(\d{1,2})-(\d{1,2})-(\d{4})/);
        if (match) {
            const day = match[1].padStart(2, '0');
            const month = match[2].padStart(2, '0');
            const year = match[3];
            return `${year}-${month}-${day}`;
        }
        
        // If unable to parse, return as is
        console.warn('Unable to parse date format:', dateStr);
        return dateStr;
    }
    
    const pdfInput = document.getElementById('pdfUpload');
    if (pdfInput) {
        pdfInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;

            // Validate file type
            if (file.type !== 'application/pdf') {
                Swal.fire({
                    icon: 'error',
                    title: 'ত্রুটি!',
                    text: 'শুধুমাত্র PDF ফাইল আপলোড করুন',
                    confirmButtonText: 'ঠিক আছে'
                });
                pdfInput.value = '';
                return;
            }

            // Validate file size (max 5MB)
            if (file.size > 5 * 1024 * 1024) {
                Swal.fire({
                    icon: 'error',
                    title: 'ত্রুটি!',
                    text: 'ফাইলের আকার 5MB এর বেশি হতে পারে না',
                    confirmButtonText: 'ঠিক আছে'
                });
                pdfInput.value = '';
                return;
            }

            const formData = new FormData();
            formData.append('pdf', file);
            
            // Create abort controller for this request
            pdfUploadAbortController = new AbortController();
            
            // Show progress in status div
            const statusDiv = document.getElementById('pdfUploadStatus');
            if (statusDiv) {
                statusDiv.innerHTML = '<div class="alert alert-info mb-0"><i class="fas fa-spinner fa-spin mr-2"></i>পিডিএফ আপলোড হচ্ছে...</div>';
                statusDiv.style.display = 'block';
            }
            
            // Show loading state with cancel button
            let progressUpdated = false;
            const progressInterval = setInterval(() => {
                if (progressUpdated || !statusDiv) return;
                progressUpdated = true;
                if (statusDiv) {
                    statusDiv.innerHTML = '<div class="alert alert-warning mb-0"><i class="fas fa-hourglass-half mr-2"></i>API সার্ভার প্রক্রিয়া করছে... এটি ১-২ মিনিট সময় নিতে পারে</div>';
                }
            }, 3000);
            
            Swal.fire({
                title: 'অনুগ্রহ করে অপেক্ষা করুন...',
                html: '<p>পিডিএফ থেকে তথ্য লোড হচ্ছে</p><p style="font-size: 0.9rem; color: #666;">এটি ৩০ সেকেন্ড থেকে ২ মিনিট সময় নিতে পারে</p><p id="uploadProgress" style="font-size: 0.85rem; color: #999; margin-top: 10px;">প্রক্রিয়া চলছে...</p>',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showCancelButton: true,
                cancelButtonText: 'বাতিল করুন',
                didOpen: () => {
                    Swal.showLoading();
                }
            }).then((result) => {
                if (result.dismiss === Swal.DismissReason.cancel) {
                    clearInterval(progressInterval);
                    pdfUploadAbortController.abort();
                    if (statusDiv) {
                        statusDiv.innerHTML = '<div class="alert alert-secondary mb-0">আপলোড বাতিল করা হয়েছে। অন্য ফাইল নির্বাচন করুন।</div>';
                    }
                }
            });

            // Send PDF to server for parsing
            const timeoutId = setTimeout(() => {
                console.warn('PDF processing timeout - aborting');
                clearInterval(progressInterval);
                pdfUploadAbortController.abort();
            }, 180000); // 3 minutes timeout
            
            console.log('Starting PDF upload...');
            console.log('File name:', file.name);
            console.log('File size:', file.size, 'bytes');

            // Get CSRF token safely
            const csrfTokenEl = document.querySelector('meta[name="csrf-token"]');
            const csrfToken = csrfTokenEl ? csrfTokenEl.content : '';
            
            // Build the request URL
            const requestUrl = '<?php echo e(route("user.smartcard.parsePdf")); ?>';
            console.log('Request URL:', requestUrl);
            console.log('CSRF Token present:', !!csrfToken);

            fetch(requestUrl, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                },
                signal: pdfUploadAbortController.signal
            })
            .then(response => {
                clearTimeout(timeoutId);
                clearInterval(progressInterval);
                console.log('Response received. Status:', response.status);
                console.log('Content-Type:', response.headers.get('content-type'));
                
                if (!response.ok) {
                    return response.text().then(text => {
                        console.error('Error response (not ok):', text.substring(0, 500));
                        throw new Error(`HTTP ${response.status}: ${text.substring(0, 200)}`);
                    });
                }
                
                // Check if response is actually JSON
                const contentType = response.headers.get('content-type');
                console.log('Full Content-Type header:', contentType);
                
                if (!contentType || !contentType.includes('application/json')) {
                    return response.text().then(text => {
                        console.error('Response is not JSON!');
                        console.error('Expected: application/json');
                        console.error('Got: ' + contentType);
                        console.error('Response body length:', text.length);
                        console.error('Response body (first 1000 chars):', text.substring(0, 1000));
                        
                        // Check if it's an HTML error page (contains HTML tags)
                        if (text.includes('<!DOCTYPE') || text.includes('<html') || text.includes('<body')) {
                            console.error('Server returned an HTML error page');
                            // Try to extract the error message
                            const errorMatch = text.match(/<h1[^>]*>([^<]+)<\/h1>/);
                            const errorMsg = errorMatch ? errorMatch[1] : 'Server error page';
                            console.error('Extracted error:', errorMsg);
                            throw new Error(`Server error (${response.status}): ${errorMsg}. Please refresh and try again.`);
                        }
                        
                        throw new Error(`Server returned ${contentType || 'invalid content type'} instead of JSON`);
                    });
                }
                
                return response.json().catch(err => {
                    console.error('Failed to parse JSON:', err.message);
                    throw new Error('Server returned invalid JSON: ' + err.message);
                });
            })
            .then(data => {
                console.log('Parsed JSON response:', data);
                console.log('Data object keys:', Object.keys(data.data));
                console.log('Full data.data content:', JSON.stringify(data.data, null, 2));
                
                if (data.success && data.data) {
                    console.log('API returned success, filling form...');
                    
                    // Auto-fill form fields
                    const fillField = (id, value) => {
                        const element = document.getElementById(id);
                        if (element) {
                            // Convert date format if it's a date field
                            let finalValue = value || '';
                            if (id === 'date_of_birth' || id === 'issue_date') {
                                finalValue = convertDateToISO(finalValue);
                            }
                            element.value = finalValue;
                            console.log(`Filled ${id} with: ${finalValue}`);
                        }
                    };

                    fillField('name_bn', data.data.name_bn);
                    fillField('name_en', data.data.name_en);
                    fillField('father_name', data.data.father_name);
                    fillField('mother_name', data.data.mother_name);
                    fillField('date_of_birth', data.data.date_of_birth);
                    fillField('place_of_birth', data.data.place_of_birth);
                    fillField('nid_no', data.data.nid_no);
                    fillField('blood_group', data.data.blood_group);
                    fillField('gender', data.data.gender);
                    fillField('address', data.data.address);
                    fillField('birth_place_en', data.data.birth_place_en);
                    fillField('postal_code', data.data.postal_code);
                    
                    // Handle photo image from API
                    console.log('Photo value:', data.data.photo);
                    console.log('Photo exists:', !!data.data.photo);
                    console.log('Photo is string:', typeof data.data.photo === 'string');
                    if (data.data.photo) {
                        console.log('✓ Photo image received from API, length:', data.data.photo.length);
                        const photoPreview = document.getElementById('photo-preview');
                        if (photoPreview) {
                            photoPreview.innerHTML = `<img src="${data.data.photo}" style="max-width: 160px; max-height: 160px;" onerror="console.error('Photo image failed to load')">`;
                            console.log('✓ Photo preview updated');
                        }
                        
                        // Set photo file input with data URI (if possible)
                        try {
                            const photoInput = document.getElementById('photo');
                            if (photoInput && data.data.photo.startsWith('data:image')) {
                                console.log('Converting photo data URI to file...');
                                // Create a blob from data URI and set it
                                fetch(data.data.photo)
                                    .then(res => res.blob())
                                    .then(blob => {
                                        console.log('✓ Photo blob created:', blob.size, 'bytes, type:', blob.type);
                                        const dataTransfer = new DataTransfer();
                                        const file = new File([blob], 'photo.jpg', { type: blob.type });
                                        dataTransfer.items.add(file);
                                        photoInput.files = dataTransfer.files;
                                        console.log('✓ Photo file set successfully');
                                    })
                                    .catch(err => console.warn('✗ Could not set photo file:', err));
                            } else {
                                console.log('Photo is not a data URI, skipping file input');
                            }
                        } catch (err) {
                            console.warn('Error handling photo file:', err);
                        }
                    } else {
                        console.log('✗ No photo received from API');
                    }
                    
                    // Handle signature image from API
                    console.log('Signature value:', data.data.signature);
                    console.log('Signature exists:', !!data.data.signature);
                    if (data.data.signature) {
                        console.log('✓ Signature image received from API, length:', data.data.signature.length);
                        const signaturePreview = document.getElementById('signature-preview');
                        if (signaturePreview) {
                            signaturePreview.innerHTML = `<img src="${data.data.signature}" style="max-width: 160px; max-height: 160px;" onerror="console.error('Signature image failed to load')">`;
                            console.log('✓ Signature preview updated');
                        }
                        
                        // Set signature file input with data URI (if possible)
                        try {
                            const signatureInput = document.getElementById('signature');
                            if (signatureInput && data.data.signature.startsWith('data:image')) {
                                console.log('Converting signature data URI to file...');
                                // Create a blob from data URI and set it
                                fetch(data.data.signature)
                                    .then(res => res.blob())
                                    .then(blob => {
                                        console.log('✓ Signature blob created:', blob.size, 'bytes, type:', blob.type);
                                        const dataTransfer = new DataTransfer();
                                        const file = new File([blob], 'signature.png', { type: blob.type });
                                        dataTransfer.items.add(file);
                                        signatureInput.files = dataTransfer.files;
                                        console.log('✓ Signature file set successfully');
                                    })
                                    .catch(err => console.warn('✗ Could not set signature file:', err));
                            } else {
                                console.log('Signature is not a data URI, skipping file input');
                            }
                        } catch (err) {
                            console.warn('Error handling signature file:', err);
                        }
                    } else {
                        console.log('✗ No signature received from API');
                    }

                    Swal.close();
                    if (statusDiv) {
                        statusDiv.innerHTML = '<div class="alert alert-success mb-0"><i class="fas fa-check-circle mr-2"></i>পিডিএফ সফলভাবে প্রক্রিয়া করা হয়েছে এবং ফর্ম পূরণ করা হয়েছে।</div>';
                    }
                    
                    Swal.fire({
                        icon: 'success',
                        title: 'সফল!',
                        html: '<p>পিডিএফ থেকে সকল তথ্য সফলভাবে লোড করা হয়েছে</p><p style="font-size: 0.9rem; color: #666;">অনুগ্রহ করে ফর্ম চেক করুন এবং প্রয়োজন অনুযায়ী সম্পাদনা করুন</p>',
                        confirmButtonText: 'ঠিক আছে'
                    });
                } else {
                    console.error('API returned failure:', data);
                    throw new Error(data.message || 'পিডিএফ প্রক্রিয়াকরণ ব্যর্থ');
                }
            })
            .catch(error => {
                clearTimeout(timeoutId);
                clearInterval(progressInterval);
                console.error('Full Error:', error);
                console.error('Error name:', error.name);
                console.error('Error message:', error.message);
                
                Swal.close();
                
                let errorTitle = 'ত্রুটি!';
                let errorMessage = error.message || 'অনুগ্রহ করে আবার চেষ্টা করুন';
                
                if (error.name === 'AbortError') {
                    errorTitle = 'বাতিল করা হয়েছে';
                    errorMessage = 'পিডিএফ প্রক্রিয়াকরণ বাতিল করা হয়েছে বা সময়সীমা অতিক্রম হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।';
                    if (statusDiv) {
                        statusDiv.innerHTML = '<div class="alert alert-danger mb-0"><i class="fas fa-times-circle mr-2"></i>সময়সীমা অতিক্রম - অনুগ্রহ করে ফর্মটি ম্যানুয়ালি পূরণ করুন</div>';
                    }
                } else if (error.message.includes('HTTP')) {
                    errorMessage = 'সার্ভারে একটি সমস্যা হয়েছে। অনুগ্রহ করে কিছুক্ষণ পরে আবার চেষ্টা করুন।';
                    if (statusDiv) {
                        statusDiv.innerHTML = '<div class="alert alert-danger mb-0"><i class="fas fa-server mr-2"></i>সার্ভার ত্রুটি - ফর্মটি ম্যানুয়ালি পূরণ করুন</div>';
                    }
                } else {
                    if (statusDiv) {
                        statusDiv.innerHTML = '<div class="alert alert-danger mb-0"><i class="fas fa-exclamation-triangle mr-2"></i>পিডিএফ প্রক্রিয়া করা যায়নি - ফর্মটি ম্যানুয়ালি পূরণ করুন</div>';
                    }
                }
                
                Swal.fire({
                    icon: 'error',
                    title: errorTitle,
                    html: `<p>পিডিএফ প্রক্রিয়াকরণে সমস্যা হয়েছে</p><p style="font-size: 0.85rem; color: #666;">${errorMessage}</p><p style="font-size: 0.85rem; color: #999; margin-top: 10px;">অনুগ্রহ করে নিচের ফর্মটি ম্যানুয়ালি পূরণ করুন</p>`,
                    confirmButtonText: 'ঠিক আছে'
                });
                
                pdfInput.value = '';
            });
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/smartcard/create.blade.php ENDPATH**/ ?>