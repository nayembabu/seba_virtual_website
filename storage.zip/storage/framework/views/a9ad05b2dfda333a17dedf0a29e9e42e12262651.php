<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>SIM Conversion Orders Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            z-index: 1000;
            overflow-y: auto;
            transition: all 0.3s;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0 10px;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.2);
            color: white;
            transform: translateX(5px);
        }
        .sidebar-menu a i {
            margin-right: 12px;
            font-size: 18px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
            padding: 20px;
            transition: all 0.3s;
        }
        .top-navbar {
            background: white;
            padding: 15px 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            text-align: center;
            transition: all 0.3s;
        }
        .stat-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-5px);
        }
        .stat-card h6 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .stat-card h3 {
            color: #667eea;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .stat-card .icon {
            font-size: 32px;
            color: #667eea;
            opacity: 0.2;
        }
        .badge-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-processing {
            background: #e7d4f5;
            color: #5a21b5;
        }
        .badge-completed {
            background: #d1ecf1;
            color: #0c5460;
        }
        .badge-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .table-wrapper {
            overflow-x: auto;
        }
        .table thead {
            background: #f8f9fa;
        }
        .table thead th {
            border: none;
            color: #667eea;
            font-weight: 600;
            padding: 15px;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .table tbody td {
            border: none;
            padding: 15px;
            vertical-align: middle;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }
        .table tbody tr:hover {
            background: #f9f9f9;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .action-buttons .btn {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 5px;
        }
        .btn-action {
            background: #667eea;
            color: white;
            border: none;
        }
        .btn-action:hover {
            background: #5568d3;
            color: white;
        }
        .btn-reject {
            background: #dc3545;
            color: white;
            border: none;
        }
        .btn-reject:hover {
            background: #c82333;
            color: white;
        }
        .btn-complete {
            background: #28a745;
            color: white;
            border: none;
        }
        .btn-complete:hover {
            background: #218838;
            color: white;
        }
        .expand-icon {
            cursor: pointer;
            transition: transform 0.3s;
            color: #667eea;
        }
        .expand-icon.expanded {
            transform: rotate(180deg);
        }
        .details-section {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 10px;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 15px;
        }
        .detail-item {
            padding: 12px;
            background: white;
            border-radius: 5px;
            border-left: 3px solid #667eea;
        }
        .detail-item strong {
            color: #667eea;
            display: block;
            font-size: 12px;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        .detail-item span {
            color: #333;
            font-size: 14px;
        }
        .search-box {
            position: relative;
        }
        .search-box input {
            padding-left: 35px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-group select {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 8px 12px;
        }
        
        /* Mobile Sidebar Toggle Button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transition: all 0.3s;
        }
        .sidebar-toggle:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        .sidebar-toggle i {
            font-size: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar-toggle {
                display: block;
            }
            .sidebar {
                width: 0;
                padding: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 10px;
                padding-top: 70px;
            }
            .stat-card {
                margin-bottom: 15px;
            }
            .action-buttons {
                flex-direction: column;
            }
            .action-buttons .btn {
                width: 100%;
            }
            .details-grid {
                grid-template-columns: 1fr;
            }
            .top-navbar {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Mobile Menu Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Page Title with Bengali -->
        <div class="page-header mb-4">
            <div class="d-flex align-items-center gap-3 mb-3">
                <div style="font-size: 28px; color: #667eea;">
                    <i class="fas fa-sim-card"></i>
                </div>
                <div>
                    <h2 class="mb-1" style="color: #333;">সিম কনভার্সন অর্ডার ম্যানেজমেন্ট</h2>
                    <p class="text-muted mb-0" style="font-size: 13px;">সকল সিম কনভার্সন অর্ডারের তালিকা এবং পরিচালনা</p>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h3 id="stat-total">0</h3>
                        <p class="mb-0">Total Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h3 id="stat-pending">0</h3>
                        <p class="mb-0">Pending</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h3 id="stat-processing">0</h3>
                        <p class="mb-0">Processing</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h3 id="stat-completed">0</h3>
                        <p class="mb-0">Completed</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="searchInput" 
                            placeholder="Search by phone number..."
                        >
                    </div>
                    <div class="col-md-3">
                        <select id="statusFilter" class="form-select">
                            <option value="">All Status</option>
                            <option value="0">Pending</option>
                            <option value="1">Processing</option>
                            <option value="2">Completed</option>
                            <option value="3">Rejected</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="typeFilter" class="form-select">
                            <option value="">All Types</option>
                            <option value="1">জিপি</option>
                            <option value="2">বাংলালিংক</option>
                            <option value="3">রবি</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-secondary w-100" onclick="resetFilters()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orders Table -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0">সকল সিম কনভার্সন অর্ডার</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th></th>
                                <th>Order ID</th>
                                <th>User ID</th>
                                <th>Phone Number</th>
                                <th>Form Type</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>PDF Upload</th>
                                <th>নোট</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="ordersTableBody">
                            <!-- Orders will be loaded here -->
                            <tr>
                                <td colspan="10" class="text-center py-4 text-muted">
                                    <i class="fas fa-spinner fa-spin"></i> Loading orders...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white">
                <nav>
                    <ul class="pagination mb-0" id="pagination">
                        <!-- Pagination will be loaded here -->
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Rejection Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="rejectModalLabel">
                        <i class="fas fa-times-circle"></i> অর্ডার বাতিল করুন
                    </h5>
                    <button type="button" class="btn-close btn-close-white" onclick="closeRejectModal();" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3"><strong>বাতিল করার কারণ নির্বাচন করুন:</strong></p>
                    <div class="d-flex flex-column gap-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason1" value="নথিপত্র অসম্পূর্ণ বা অবৈধ">
                            <label class="form-check-label" for="reason1">
                                নথিপত্র অসম্পূর্ণ বা অবৈধ
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason2" value="ভুল নম্বর প্রদান করা হয়েছে">
                            <label class="form-check-label" for="reason2">
                                ভুল নম্বর প্রদান করা হয়েছে
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason3" value="তথ্য মিলছে না">
                            <label class="form-check-label" for="reason3">
                                তথ্য মিলছে না
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason4" value="ব্যবহারকারীর বাতিলের অনুরোধ">
                            <label class="form-check-label" for="reason4">
                                ব্যবহারকারীর বাতিলের অনুরোধ
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeRejectModal();">বাতিল করুন</button>
                    <button type="button" class="btn btn-danger" id="confirmRejectBtn" onclick="confirmReject();">
                        <i class="fas fa-check"></i> নিশ্চিত করুন
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Hidden PDF File Input -->
    <input type="file" id="hiddenPDFInput" accept=".pdf" style="display: none;">
    <input type="hidden" id="currentOrderId" value=""

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentPage = 1;
        let currentRejectOrderId = null;

        // Load orders on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadOrders();
            setupEventListeners();
        });

        function setupEventListeners() {
            document.getElementById('searchInput').addEventListener('keyup', function() {
                currentPage = 1;
                loadOrders();
            });

            document.getElementById('statusFilter').addEventListener('change', function() {
                currentPage = 1;
                loadOrders();
            });

            document.getElementById('typeFilter').addEventListener('change', function() {
                currentPage = 1;
                loadOrders();
            });
        }

        function loadOrders(page = 1) {
            currentPage = page;
            const search = document.getElementById('searchInput').value;
            const status = document.getElementById('statusFilter').value;
            const type = document.getElementById('typeFilter').value;

            const queryParams = new URLSearchParams();
            if (search) queryParams.append('search', search);
            if (status !== '') queryParams.append('status', status);
            if (type) queryParams.append('type', type);
            queryParams.append('page', page);

            fetch(`/admin/sim-conversions/get-orders?${queryParams}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                renderOrders(data.orders);
                updateStats(data.stats);
                updatePagination(data.pagination);
            })
            .catch(error => {
                console.error('Error loading orders:', error);
                document.getElementById('ordersTableBody').innerHTML = 
                    '<tr><td colspan="10" class="text-center py-4 text-danger">Error loading orders. Please try again.</td></tr>';
            });
        }

        function renderOrders(orders) {
            const tbody = document.getElementById('ordersTableBody');
            
            if (orders.length === 0) {
                tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4 text-muted">No orders found</td></tr>';
                return;
            }

            tbody.innerHTML = orders.map(order => `
                <tr class="order-row" onclick="toggleDetails(${order.id})" style="cursor: pointer;">
                    <td>
                        <i class="fas fa-chevron-right expand-icon-${order.id}" id="icon-${order.id}"></i>
                    </td>
                    <td>
                        <strong>#${order.id}</strong>
                    </td>
                    <td>${order.user_id || 'N/A'}</td>
                    <td>
                        <strong>${getPhoneNumber(order.form_data)}</strong>
                    </td>
                    <td>
                        <span class="badge bg-info">${order.form_type_name || getFormTypeName(order.type)}</span>
                    </td>
                    <td>${getStatusBadge(order.status)}</td>
                    <td>${formatDate(order.created_at)}</td>
                    <td onclick="event.stopPropagation();" style="text-align: center;">
                        ${order.admin_note && order.admin_note.includes('.pdf') ? `
                            <a href="/admin/sim-conversions/${order.id}/download-pdf" class="btn btn-sm btn-success" title="Download PDF">
                                <i class="fas fa-download"></i> Download
                            </a>
                        ` : `
                            <button class="btn btn-sm btn-primary" onclick="openUploadPDFModal(${order.id})" title="Upload PDF">
                                <i class="fas fa-cloud-upload-alt"></i> Upload
                            </button>
                        `}
                    </td>
                    <td onclick="event.stopPropagation();">
                        <div style="max-width: 200px;">
                            <textarea id="note-${order.id}" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px; min-height: 60px; resize: vertical; font-family: inherit;">${order.text || ''}</textarea>
                            <button onclick="saveNote(${order.id})" style="width: 100%; margin-top: 5px; background-color: #3498db; color: white; border: none; padding: 6px; border-radius: 4px; font-size: 12px; cursor: pointer;">Save</button>
                        </div>
                    </td>
                    <td onclick="event.stopPropagation();">
                        ${getActionButtons(order)}
                    </td>
                </tr>

                <!-- Expandable Details Row -->
                <tr id="details-row-${order.id}" class="details-row" style="display: none;">
                    <td colspan="10">
                        <div class="details-panel p-4" style="background: #f9f9f9; border-left: 4px solid #667eea;">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <h6 class="mb-3"><i class="fas fa-info-circle"></i> Order Information</h6>
                                    <p><strong>Order ID:</strong> #${order.id}</p>
                                    <p><strong>User ID:</strong> ${order.user_id}</p>
                                    <p><strong>Phone Number:</strong> ${getPhoneNumber(order.form_data)}</p>
                                    <p><strong>Form Type:</strong> ${order.form_type_name || getFormTypeName(order.type)}</p>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="mb-3"><i class="fas fa-clock"></i> Timestamps</h6>
                                    <p><strong>Type:</strong> ${getTypeBadge(order.type)}</p>
                                    <p><strong>Status:</strong> ${getStatusBadge(order.status)}</p>
                                    <p><strong>Created:</strong> ${formatDate(order.created_at)}</p>
                                    <p><strong>Updated:</strong> ${formatDate(order.updated_at)}</p>
                                </div>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-end gap-2">
                                <button class="btn btn-sm btn-secondary" onclick="toggleDetails(${order.id})">
                                    <i class="fas fa-times"></i> Close
                                </button>
                            </div>
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        function toggleDetails(orderId) {
            const detailsRow = document.getElementById('details-row-' + orderId);
            const icon = document.getElementById('icon-' + orderId);
            
            if (detailsRow.style.display === 'none' || !detailsRow.style.display) {
                detailsRow.style.display = 'table-row';
                icon.classList.remove('fa-chevron-right');
                icon.classList.add('fa-chevron-down');
            } else {
                detailsRow.style.display = 'none';
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-right');
            }
        }

        function getActionButtons(order) {
            let buttons = '';
            
            if (order.status == 0) { // Pending
                buttons += `
                    <button class="btn btn-sm btn-success" onclick="event.stopPropagation(); processOrder(${order.id}, ${order.status})" title="Approve">
                        <i class="fas fa-check"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="event.stopPropagation(); rejectOrder(${order.id})" title="Reject">
                        <i class="fas fa-times"></i>
                    </button>
                `;
            } else if (order.status == 1) { // Processing
                buttons += `
                    <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); processOrder(${order.id}, ${order.status})" title="Complete">
                        <i class="fas fa-check-double"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="event.stopPropagation(); rejectOrder(${order.id})" title="Reject">
                        <i class="fas fa-times"></i>
                    </button>
                `;
            }
            
            return buttons;
        }

        function updateStats(stats) {
            document.getElementById('stat-total').textContent = stats.total;
            document.getElementById('stat-pending').textContent = stats.pending;
            document.getElementById('stat-processing').textContent = stats.processing;
            document.getElementById('stat-completed').textContent = stats.completed;
        }

        function updatePagination(pagination) {
            const paginationEl = document.getElementById('pagination');
            if (!pagination || pagination.last_page <= 1) {
                paginationEl.innerHTML = '';
                return;
            }

            let html = '';
            if (pagination.current_page > 1) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="loadOrders(${pagination.current_page - 1}); return false;">Previous</a></li>`;
            }

            for (let i = 1; i <= pagination.last_page; i++) {
                html += `<li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                    <a class="page-link" href="#" onclick="loadOrders(${i}); return false;">${i}</a>
                </li>`;
            }

            if (pagination.current_page < pagination.last_page) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="loadOrders(${pagination.current_page + 1}); return false;">Next</a></li>`;
            }

            paginationEl.innerHTML = html;
        }

        function processOrder(orderId, currentStatus) {
            // If pending (0), mark as processing (1). If processing (1), mark as completed (2)
            const newStatus = currentStatus == 0 ? 1 : 2;
            updateOrderStatus(orderId, newStatus);
        }

        function rejectOrder(orderId) {
            event.stopPropagation(); // Stop event bubbling
            currentRejectOrderId = orderId;
            console.log('Reject button clicked for order:', orderId);
            
            const modalElement = document.getElementById('rejectModal');
            if (!modalElement) {
                alert('Modal not found!');
                return;
            }

            // Remove all checked radios first
            document.querySelectorAll('input[name="rejectionReason"]').forEach(radio => {
                radio.checked = false;
            });

            // Show modal manually
            modalElement.style.display = 'block';
            modalElement.classList.add('show');
            modalElement.setAttribute('aria-hidden', 'false');
            document.body.classList.add('modal-open');
            
            // Add backdrop
            let backdrop = document.querySelector('.modal-backdrop');
            if (!backdrop) {
                backdrop = document.createElement('div');
                backdrop.className = 'modal-backdrop fade show';
                document.body.appendChild(backdrop);
            }
        }

        function confirmReject() {
            if (!currentRejectOrderId) {
                alert('Order ID not found');
                return;
            }

            const reason = document.querySelector('input[name="rejectionReason"]:checked');

            if (!reason) {
                alert('অনুগ্রহ করে বাতিলের কারণ নির্বাচন করুন');
                return;
            }

            const reasonValue = reason.value;
            console.log('Confirming rejection for order:', currentRejectOrderId, 'Reason:', reasonValue);
            
            // Update order status first
            updateOrderStatus(currentRejectOrderId, 3, reasonValue);
            
            // Hide modal after a brief delay
            setTimeout(() => {
                closeRejectModal();
            }, 100);
        }

        function closeRejectModal() {
            const modalElement = document.getElementById('rejectModal');
            if (modalElement) {
                // Manual close
                modalElement.style.display = 'none';
                modalElement.classList.remove('show');
                modalElement.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('modal-open');
                
                // Remove backdrop
                const backdrop = document.querySelector('.modal-backdrop');
                if (backdrop) {
                    backdrop.remove();
                }
                
                console.log('Modal closed successfully');
            }
        }

        function updateOrderStatus(orderId, status, reason = '') {
            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/admin/sim-conversions/${orderId}/update-status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    status: status,
                    reason: reason
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadOrders(currentPage);
                    clearRejectionForm();
                } else {
                    alert(data.message || 'Error updating order status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error updating order status');
            });
        }

        function clearRejectionForm() {
            document.querySelectorAll('input[name="rejectionReason"]').forEach(radio => {
                radio.checked = false;
            });
        }

        function resetFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('statusFilter').value = '';
            document.getElementById('typeFilter').value = '';
            currentPage = 1;
            loadOrders();
        }

        function getStatusBadge(status) {
            const badges = {
                0: '<span class="badge-status badge-pending">Pending</span>',
                1: '<span class="badge-status badge-processing">Processing</span>',
                2: '<span class="badge-status badge-completed">Completed</span>',
                3: '<span class="badge-status badge-rejected">Rejected</span>'
            };
            return badges[status] || `<span class="badge-status">${status}</span>`;
        }

        function getTypeBadge(type) {
            const badges = {
                1: '<span class="badge bg-success">জিপি</span>',
                2: '<span class="badge bg-warning text-dark">বাংলালিংক</span>',
                3: '<span class="badge bg-danger">রবি</span>'
            };
            return badges[type] || `<span class="badge bg-secondary">${type}</span>`;
        }

        function getFormTypeName(type) {
            const names = {
                1: 'জিপি',
                2: 'বাংলালিংক',
                3: 'রবি'
            };
            return names[type] || 'Unknown';
        }

        function getPhoneNumber(formData) {
            try {
                if (typeof formData === 'string') {
                    formData = JSON.parse(formData);
                }
                return formData.number || 'N/A';
            } catch (e) {
                return 'N/A';
            }
        }

        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
            return new Date(dateString).toLocaleDateString('en-US', options);
        }

        function saveNote(orderId) {
            const noteText = document.getElementById('note-' + orderId).value;
            
            // If note is empty, don't update status
            if (!noteText.trim()) {
                alert('অনুগ্রহ করে কিছু নোট লিখুন');
                return;
            }
            
            fetch(`/admin/sim-conversions/${orderId}/save-note`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ note: noteText })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Note saved successfully');
                    // Auto update status to completed (2) when note is saved
                    updateOrderStatus(orderId, 2);
                }
            })
            .catch(error => console.error('Error saving note:', error));
        }

        function openUploadPDFModal(orderId) {
            document.getElementById('currentOrderId').value = orderId;
            document.getElementById('hiddenPDFInput').click();
        }

        // Hidden file input change event
        document.addEventListener('DOMContentLoaded', function() {
            const hiddenPDFInput = document.getElementById('hiddenPDFInput');
            
            hiddenPDFInput.addEventListener('change', function() {
                const orderId = document.getElementById('currentOrderId').value;
                const file = this.files[0];
                
                if (!file) return;
                
                if (file.type !== 'application/pdf') {
                    alert('শুধুমাত্র PDF ফাইল আপলোড করুন');
                    return;
                }
                
                if (file.size > 10 * 1024 * 1024) {
                    alert('ফাইলের আকার ১০MB এর বেশি হতে পারে না');
                    return;
                }
                
                uploadPDFFile(orderId, file);
                
                // Reset file input
                this.value = '';
            });
        });

        function uploadPDFFile(orderId, file) {
            const formData = new FormData();
            formData.append('pdf', file);
            formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

            // Show loading message
            const button = document.querySelector(`button[onclick="openUploadPDFModal(${orderId})"]`);
            const originalHTML = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            button.disabled = true;

            fetch(`/admin/sim-conversions/${orderId}/upload-pdf`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadOrders(currentPage);
                } else {
                    alert('Error: ' + data.message);
                    button.innerHTML = originalHTML;
                    button.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('PDF আপলোডে ত্রুটি');
                button.innerHTML = originalHTML;
                button.disabled = false;
            });
        }
    </script>
</body>
</html>
<?php /**PATH /home/ifixfast24/public_html/resources/views/admin/Seam_Biometric_order/index.blade.php ENDPATH**/ ?>