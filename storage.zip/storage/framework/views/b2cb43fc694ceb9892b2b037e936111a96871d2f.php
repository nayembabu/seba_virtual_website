

<?php $__env->startSection('title'); ?>
    নিবন্ধন তালিকা
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <?php if($notification ?? false): ?>
                <div class="alert alert-info">
                    <?php echo e($notification); ?>

                </div>
            <?php endif; ?>

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="card-title text-primary mb-0">
                    <i class="fas fa-file-alt fa-fw"></i> নিবন্ধন তালিকা
                </h3>
                <a href="<?php echo e(route('user.nibondon.create')); ?>" class="btn btn-success">
                    <i class="fas fa-plus"></i> নতুন নিবন্ধন যোগ করুন
                </a>
            </div>

            <hr class="border-primary opacity-75">

            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>ক্রমিক</th>
                            <th>নিবন্ধন নং</th>
                            <th>নাম (বাংলা)</th>
                            <th>নাম (ইংরেজি)</th>
                            <th>পিতার নাম</th>
                            <th>নিবন্ধন তারিখ</th>
                           
                            <th>ডাউনলোড</th>
                            <th>কার্যক্রম</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nibondon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($nibondon->registration_no); ?></td>
                                <td><?php echo e($nibondon->name_bn); ?></td>
                                <td><?php echo e($nibondon->name_en ?? 'N/A'); ?></td>
                                <td><?php echo e($nibondon->father_name_bn); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($nibondon->registration_date)->format('d/m/Y')); ?></td>
                                
                                <td>
                                    <a href="<?php echo e(route('user.nibondon.show', $nibondon->id)); ?>" 
                                       class="btn btn-primary btn-sm">
                                        <i class="fas fa-print"></i> প্রিন্ট
                                    </a>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('user.nibondon.edit', $nibondon->id)); ?>" 
                                           class="btn btn-info btn-sm">
                                            <i class="fas fa-edit"></i> সম্পাদনা
                                        </a>
                                        
                                        <form action="<?php echo e(route('user.nibondon.destroy', $nibondon->id)); ?>" 
                                              method="POST" style="display: inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" 
                                                    onclick="return confirm('আপনি কি নিশ্চিতভাবে এটি মুছে ফেলতে চান?')">
                                                <i class="fas fa-trash"></i> মুছুন
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">
                                    <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                    কোনো নিবন্ধন পাওয়া যায়নি
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($registrations->hasPages()): ?>
                <div class="mt-3">
                    <?php echo e($registrations->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
    .badge {
        font-size: 0.9em;
        padding: 5px 10px;
    }
    .btn-group .btn {
        margin: 0 2px;
    }
    .alert {
        border-radius: 0.25rem;
    }
    .table {
        margin-bottom: 0;
    }
    .table thead th {
        vertical-align: middle;
        border-bottom: 2px solid #dee2e6;
        background-color: #343a40;
        color: white;
        font-weight: 600;
    }
    .table tbody td {
        vertical-align: middle;
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0,123,255,0.05);
    }
    .btn-sm {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
    .text-muted i {
        color: #6c757d;
        opacity: 0.5;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        // Auto hide alerts after 5 seconds
        setTimeout(function() {
            $('.alert:not(.alert-info)').fadeOut('slow');
        }, 5000);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/nibondon/index.blade.php ENDPATH**/ ?>