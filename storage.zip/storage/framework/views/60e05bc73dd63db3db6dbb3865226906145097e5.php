
<?php $__env->startSection('title'); ?>
    সাইন কপি অর্ডার বিস্তারিত
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style>
    .classic-card {
        background: linear-gradient(to bottom, #ffffff 0%, #f8f9fa 100%);
        border: none;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1) !important;
    }

    .detail-section {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .detail-header {
        background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
        color: white;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }

    .detail-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #eee;
    }

    .detail-row:last-child {
        border-bottom: none;
    }

    .detail-label {
        font-weight: 600;
        color: #2c3e50;
    }

    .detail-value {
        color: #34495e;
    }

    .status-badge {
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: 500;
    }

    .status-pending {
        background-color: #ffeeba;
        color: #856404;
    }

    .status-processing {
        background-color: #b8daff;
        color: #004085;
    }

    .status-completed {
        background-color: #c3e6cb;
        color: #155724;
    }

    .status-cancelled {
        background-color: #f5c6cb;
        color: #721c24;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="card classic-card m-0 m-md-4 my-4 m-md-0">
    <div class="card-body">
        <div class="detail-header">
            <h4 class="mb-0">অর্ডার আইডি: #<?php echo e($order->id); ?></h4>
        </div>

        <div class="detail-section">
            <h5 class="mb-3">অর্ডার তথ্য</h5>
            <div class="detail-row">
                <span class="detail-label">অর্ডার ধরন</span>
                <span class="detail-value"><?php echo e($order->getFormTypeTextAttribute()); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">মূল্য</span>
                <span class="detail-value"><?php echo e($order->price); ?> টাকা</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">স্ট্যাটাস</span>
                <span class="status-badge 
                    <?php if($order->status == 0): ?> status-pending
                    <?php elseif($order->status == 1): ?> status-processing
                    <?php elseif($order->status == 2): ?> status-completed
                    <?php else: ?> status-cancelled
                    <?php endif; ?>">
                    <?php if($order->status == 0): ?>
                        পেন্ডিং
                    <?php elseif($order->status == 1): ?>
                        প্রসেসিং
                    <?php elseif($order->status == 2): ?>
                        সম্পন্ন
                    <?php else: ?>
                        বাতিল
                    <?php endif; ?>
                </span>
            </div>
            <div class="detail-row">
                <span class="detail-label">অর্ডারের তারিখ</span>
                <span class="detail-value"><?php echo e($order->created_at->format('d/m/Y h:i A')); ?></span>
            </div>
        </div>

        <div class="detail-section">
            <h5 class="mb-3">অর্ডার বিবরণ</h5>
            <?php if($order->form_type <= 2): ?>
                <div class="detail-row">
                    <span class="detail-label">নাম</span>
                    <span class="detail-value"><?php echo e($order->name); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">এনআইডি নম্বর</span>
                    <span class="detail-value"><?php echo e($order->nid); ?></span>
                </div>
            <?php elseif($order->form_type <= 4): ?>
                <div class="detail-row">
                    <span class="detail-label">এনআইডি নম্বর</span>
                    <span class="detail-value"><?php echo e($order->nid); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">জন্ম তারিখ</span>
                    <span class="detail-value"><?php echo e($order->dob ? $order->dob->format('d/m/Y') : 'N/A'); ?></span>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = json_decode($order->form_data, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($value && $key != 'photo'): ?>
                        <div class="detail-row">
                            <span class="detail-label">
                                <?php switch($key):
                                    case ('name'): ?>
                                        নিজ নাম
                                        <?php break; ?>
                                    <?php case ('father_name'): ?>
                                        পিতার নাম
                                        <?php break; ?>
                                    <?php case ('mother_name'): ?>
                                        মাতার নাম
                                        <?php break; ?>
                                    <?php case ('spouse_name'): ?>
                                        স্বামী/স্ত্রী নাম
                                        <?php break; ?>
                                    <?php case ('birth_cert'): ?>
                                        জন্ম সনদ
                                        <?php break; ?>
                                    <?php case ('division'): ?>
                                        বিভাগ
                                        <?php break; ?>
                                    <?php case ('district'): ?>
                                        জেলা
                                        <?php break; ?>
                                    <?php case ('upazila'): ?>
                                        উপজেলা
                                        <?php break; ?>
                                    <?php case ('union'): ?>
                                        ইউনিয়ন/পৌরসভা/সিটি করপোরেশন
                                        <?php break; ?>
                                    <?php case ('ward'): ?>
                                        ওয়ার্ড নং
                                        <?php break; ?>
                                    <?php case ('post_office'): ?>
                                        ডাকঘর
                                        <?php break; ?>
                                    <?php case ('village'): ?>
                                        গ্রাম
                                        <?php break; ?>
                                    <?php case ('father_nid'): ?>
                                        পিতার এনআইডি নং
                                        <?php break; ?>
                                    <?php case ('mother_nid'): ?>
                                        মাতার এনআইডি নং
                                        <?php break; ?>
                                    <?php case ('voter_nid'): ?>
                                        সাথে ভোটার হওয়া একজনের এনআইডি
                                        <?php break; ?>
                                    <?php default: ?>
                                        <?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>

                                <?php endswitch; ?>
                            </span>
                            <span class="detail-value"><?php echo e($value); ?></span>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($order->form_type == 6 && isset(json_decode($order->form_data, true)['photo'])): ?>
                    <div class="detail-row">
                        <span class="detail-label">ছবি</span>
                        <span class="detail-value">
                            <img src="<?php echo e(asset('storage/' . json_decode($order->form_data, true)['photo'])); ?>" 
                                alt="User Photo" class="img-thumbnail" style="max-width: 200px;">
                        </span>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="text-end mt-4">
            <a href="<?php echo e(route('user.sign.copy.order.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> পেছনে যান
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/sign_copy_order/show.blade.php ENDPATH**/ ?>