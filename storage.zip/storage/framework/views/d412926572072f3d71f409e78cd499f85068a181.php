
<?php $__env->startSection('title', 'Register'); ?>
<?php $__env->startSection('register', 'active'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .login-page {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        position: relative;
    }

    .background {
        background: url('/login-background.png') no-repeat center center; /* Center the background */
        background-size: 100%;
        position: absolute;
        width: 100%;
        height: 100%;
        bottom: -100px;
        z-index: -2;
        filter: blur(2px); /* Optional: add blur for a soft effect */
    }

    .form-container {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        max-width: 500px;
        margin: auto;
        position: relative; /* Make sure the form is above the background */
        z-index: 1;
    }

    .form-container h2 {
        margin-bottom: 20px;
        text-align: center; /* Center the title */
    }

    .step {
        display: none;
    }

    .step.active {
        display: block;
    }

    .step-nav {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
    }

    .step-nav button {
        padding: 10px 20px;
        transition: background-color 0.3s, transform 0.3s; /* Add transition for button effects */
    }

    .step-nav .btn-prev {
        background-color: #f0ad4e;
        color: white;
    }

    .step-nav .btn-next {
        background-color: #5cb85c;
        color: white;
    }

    .step-nav .btn-submit {
        background-color: #28a745;
        color: white;
        font-weight: bold;
        text-transform: uppercase;
        letter-spacing: 1px;
        animation: pulse 1.5s infinite; /* Add animation to the button */
    }

    @keyframes  pulse {
        0% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.05);
        }
        100% {
            transform: scale(1);
        }
    }

    .preloader {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        border: 4px solid #f3f3f3;
        border-top: 4px solid #3498db;
        border-radius: 50%;
        width: 30px;
        height: 30px;
        animation: spin 1s linear infinite;
        z-index: 9999;
        display: none;
    }

    @keyframes  spin {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }

    /* Add responsiveness for smaller screens */
    @media (max-width: 600px) {
        .form-container {
            width: 90%; /* Full width on smaller screens */
        }
    }
</style>

<section class="login-page">
    <div class="background"></div>
    
    <div class="logo text-center mb-4">
        <img src="<?php echo e(url('assets/uploads/logo/'.get_settings()->logo)); ?>" style="width: 250px;" alt="Logo">
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <form id="registerForm" action="<?php echo e(route('register.submit')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-container">
            <!-- Step 1: Personal Information -->
            <div class="step active" id="step-1">
                <div class="form-group">
                    <label>Full Name <span class="req">*</span></label>
                    <input type="text" name="name" class="form-control" required />
                </div>
                <div class="form-group">
                    <label>Phone Number <span class="req">*</span></label>
                    <input type="text" name="phone" class="form-control" required />
                </div>
            </div>

            <!-- Step 2: Account Information -->
            <div class="step" id="step-2">
                <div class="form-group">
                    <label>Email <span class="req">*</span></label>
                    <input type="email" name="email" class="form-control" required />
                </div>
                <div class="form-group">
                    <label>Password (Min: 6 Characters) <span class="req">*</span></label>
                    <input type="password" name="password" class="form-control" minlength="6" required />
                </div>
            </div>

            <!-- Step 3: Additional Information -->
            <div class="step" id="step-3">
                <div class="form-group">
                    <label>Gender <span class="req">*</span></label>
                    <select name="gender" class="form-control" required>
                        <option value="">Select One</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Date of Birth</label>
                    <input type="date" name="dob" class="form-control" />
                </div>
            </div>

            <!-- Step 4: National ID and Promo Code -->
            <div class="step" id="step-4">
                <div class="form-group">
                    <label>National ID</label>
                    <input type="text" name="nid" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Promo Code(optional)</label>
                    <input type="text" name="promo" class="form-control" />
                </div>
            </div>

            <!-- Navigation Buttons -->
            <div class="step-nav">
                <button type="button" class="btn-prev btn btn-warning" onclick="prevStep()">Previous</button>
                <button type="button" class="btn-next btn btn-success" onclick="nextStep()">Next</button>
                <button type="submit" class="btn-submit btn btn-primary" style="display: none;">Register Now</button>
            </div>
        </div>
    </form>

    <!-- Preloader -->
    <div class="preloader"></div>
</section>

<script>
    let currentStep = 1;
    const totalSteps = 4;

    function showStep(step) {
        document.querySelectorAll('.step').forEach((stepEl, index) => {
            if (index + 1 === step) {
                stepEl.classList.add('active');
            } else {
                stepEl.classList.remove('active');
            }
        });

        document.querySelector('.btn-prev').style.display = step > 1 ? 'inline-block' : 'none';
        document.querySelector('.btn-next').style.display = step < totalSteps ? 'inline-block' : 'none';
        document.querySelector('.btn-submit').style.display = step === totalSteps ? 'inline-block' : 'none';
    }

    function validateStep(step) {
        const currentStepEl = document.getElementById(`step-${step}`);
        const inputs = currentStepEl.querySelectorAll('input[required], select[required]');
        let isValid = true;

        inputs.forEach(input => {
            if (!input.value.trim()) {
                isValid = false;
                input.classList.add('is-invalid');
                const feedback = document.createElement('div');
                feedback.className = 'invalid-feedback';
                feedback.textContent = 'This field is required';
                input.parentNode.appendChild(feedback);
            } else {
                input.classList.remove('is-invalid');
                const feedback = input.parentNode.querySelector('.invalid-feedback');
                if (feedback) {
                    feedback.remove();
                }
            }
        });

        return isValid;
    }

    function nextStep() {
        if (validateStep(currentStep)) {
            if (currentStep < totalSteps) {
                currentStep++;
                showStep(currentStep);
            }
        }
    }

    function prevStep() {
        if (currentStep > 1) {
            currentStep--;
            showStep(currentStep);
        }
    }

    document.getElementById('registerForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateStep(currentStep)) {
            document.querySelector('.preloader').style.display = 'block';
            this.submit();
        }
    });

    // Hide preloader on page load
    window.addEventListener('load', function () {
        document.querySelector('.preloader').style.display = 'none';
    });

    // Initialize the form with step 1
    showStep(currentStep);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/auth/register.blade.php ENDPATH**/ ?>