

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h2>Uttoradhikar Certificate Management</h2>
                    <a href="<?php echo e(route('user.uttoradhikarsonod.create')); ?>" class="btn btn-primary">Create New Certificate</a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Certificate ID</th>
                                    <th>Certificate Number</th>
                                    <th>Name (Bengali)</th>
                                    <th>Relationship</th>
                                    <th>Issue Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($certificate->id); ?></td>
                                        <td><?php echo e($certificate->certificate_number); ?></td>
                                        <td><?php echo e($certificate->person_bn); ?></td>
                                        <td><?php echo e($certificate->he_she_is); ?></td>
                                        <td><?php echo e($certificate->created_at->format('Y-m-d')); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo e($certificate->status == 'active' ? 'success' : 'warning'); ?>">
                                                <?php echo e(ucfirst($certificate->status ?? 'Pending')); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('user.uttoradhikarsonod.show', $certificate->id)); ?>" class="btn btn-info btn-sm">View</a>
                                                <a href="<?php echo e(route('user.uttoradhikarsonod.edit', $certificate->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                                <?php if(isset($certificate->certificate_number)): ?>
                                                    <a href="<?php echo e(route('verify.uttoradhikar', $certificate->certificate_number)); ?>" 
                                                       target="_blank" 
                                                       class="btn btn-success btn-sm">Verify</a>
                                                <?php endif; ?>
                                                <form action="<?php echo e(route('user.uttoradhikarsonod.destroy', $certificate->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this certificate?')">Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No certificates found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($certificates->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.btn-group .btn {
    margin-right: 4px;
}
.btn-group .btn:last-child {
    margin-right: 0;
}
.badge {
    padding: 8px 12px;
    font-size: 12px;
    border-radius: 4px;
}
.badge-success {
    background-color: #28a745;
    color: white;
}
.badge-warning {
    background-color: #ffc107;
    color: #212529;
}
.table {
    margin-bottom: 0;
}
.table td, .table th {
    vertical-align: middle;
}
.card-header h2 {
    margin-bottom: 0;
    font-size: 1.5rem;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/uttoradhikarsonod/index.blade.php ENDPATH**/ ?>