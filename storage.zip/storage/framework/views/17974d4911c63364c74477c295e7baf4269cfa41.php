
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Home'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Latest Updates Section -->
    <div class="container-fluid mb-4">
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">
                    <i class="fas fa-bell"></i> Latest Updates 
                    <span class="badge badge-danger">LIVE</span>
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="latest-updates-marquee" style="background: linear-gradient(45deg, #1a237e, #0d47a1);">
                    <marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();" style="padding: 15px; color: #fff; font-size: 16px;">
                        <i class="fas fa-circle text-danger blink" style="font-size: 10px;"></i>
                        সার্ভার অপশন চালু করা হয়েছে। বিস্তারিত জানতে ভিজিট করুন: https://www.facebook.com/ &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                        <i class="fas fa-circle text-danger blink" style="font-size: 10px;"></i>
                        নতুন আপডেট: স্মার্ট কার্ড NID সার্ভিস এখন উপলব্ধ &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                        <i class="fas fa-circle text-danger blink" style="font-size: 10px;"></i>
                        সিস্টেম আপগ্রেড চলছে, আরও নতুন ফিচার আসছে
                    </marquee>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        
        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                <div class="card shadow border-right">
                    <div class="card-body">
                        <div class="d-flex d-lg-flex d-md-block align-items-center">
                            <div>
                                <div class="d-inline-flex align-items-center">
                                    <h2 class="text-dark mb-1 font-weight-medium"><?php echo e(inum($user->balance)); ?></h2>
                                </div>
                                <h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate"><?php echo app('translator')->get('My Balance'); ?></h6>
                            </div>
                            <div class="ml-auto mt-md-3 mt-lg-0">
                                <span class="opacity-7 text-muted"><i class="fa fa-file"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('style'); ?>
<style>
    /* Latest Updates Marquee Styles */
    .latest-updates-marquee {
        border-radius: 0 0 4px 4px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .blink {
        animation: blinker 1s linear infinite;
    }
    
    @keyframes  blinker {
        50% {
            opacity: 0;
        }
    }
    
    marquee::-webkit-scrollbar {
        display: none;
    }
    
    .card-header {
        padding: 0.75rem 1.25rem;
        border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .badge-danger {
        background-color: #dc3545;
        padding: 0.4em 0.6em;
        font-size: 12px;
        font-weight: normal;
        animation: pulse 2s infinite;
    }
    
    @keyframes  pulse {
        0% {
            opacity: 1;
        }
        50% {
            opacity: 0.5;
        }
        100% {
            opacity: 1;
        }
    }

    .modal-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }
    .modal-title {
        font-weight: bold;
    }
    .modal-body {
        background-color: #e9ecef;
    }
    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        color: #fff;
    }
    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #004085;
    }
    .btn-success {
        background-color: #28a745;
        border-color: #28a745;
        color: #fff;
    }
    .btn-success:hover {
        background-color: #218838;
        border-color: #1e7e34;
    }
    .text-primary {
        color: #007bff !important;
    }
    .text-info {
        color: #17a2b8 !important;
    }
    .text-warning {
        color: #ffc107 !important;
    }
    .modal-footer {
        background-color: #f8f9fa;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/dashboard.blade.php ENDPATH**/ ?>