
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get($title); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body bn-layout">
            <div class="text-right">
                <a href="<?php echo e(route('user.land.create')); ?>" class="btn btn-success"> <i class="fas fa-plus"></i> কর দিন </a>
            </div>
            <div style="overflow-x:auto;">
                <table class="categories-show-table table table-hover table-striped table-bordered">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="col"><?php echo app('translator')->get('আইডি'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('সিটি/পৌর/ইউনিয়ন নাম'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('মালিক'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('ক্রমিক নং'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('তারিখ'); ?></th>
                        <th scope="col" style="text-align:center"><?php echo app('translator')->get('অ্যাকশান'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('আইডি'); ?>">
                                <?php echo e($key + 1); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('সিটি/পৌর/ইউনিয়ন নাম'); ?>">
                                <?php echo e($data->office_name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('মালিক'); ?>">
                                <?php
                                $names = '';
                                $ndata = json_decode($data->malik_name);
                                $ndata = !blank($ndata) ? $ndata : array();
                                foreach ($ndata as $n) {
                                    $names .= "$n->name, ";
                                }
                                ?>
                                <?php echo e($names); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('ক্রমিক নং'); ?>">
                                <?php echo e($data->sl_no); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('তারিখ'); ?>">
                                <?php echo e(date('d F Y', strtotime($data->created_at))); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('অ্যাকশান'); ?>" class="text-lg-center text-right">
                                <!-- Print Button -->
                                <a href="<?php echo e(route('user.land.print', $data->uid)); ?>" class="btn btn-primary" target="_blank">
                                    <i class="fas fa-print"></i>
                                </a>

                                <!-- Edit Button -->
                                <a href="<?php echo e(route('user.land.update', $data->uid)); ?>" class="btn btn-info">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>

                                <!-- Delete Button -->
                                <form style="display:inline-block" action="<?php echo e(route('user.land.delete', $data->uid)); ?>" method="post" onsubmit="return confirm('Do you really want to delete this?');">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-danger" colspan="9"><?php echo app('translator')->get('No Data'); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($objects->appends(@$_GET)->links('partials.pagination')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).on('click', '.recharge', function () {
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/land/index.blade.php ENDPATH**/ ?>