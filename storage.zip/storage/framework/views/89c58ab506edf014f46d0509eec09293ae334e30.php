<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get($title); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   
    
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
<?php
    $serviceCharge = \App\Models\ServiceCharge::where('service_name', 'land')->first();
?>



         <?php if($serviceCharge): ?>
            <div class="alert alert-info border-info mb-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-info-circle fa-2x mr-3"></i>
                    <div>
                        <h4 class="alert-heading mb-1">সার্ভিস চার্জ</h4> 
                        <p class="mb-0">প্রতিটি সার্টিফিকেট তৈরির জন্য <span class="font-weight-bold" style="color:red;"><?php echo e(number_format($serviceCharge->amount, 1)); ?></span> টাকা কাটা হবে।</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

     <?php if($errors->any()): ?>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="alert alert-danger"><?php echo e($error); ?></div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
     
     
     
          <form action="" method="post" class="bn-layout">
              <?php echo csrf_field(); ?>
              
              <h3 class="text-center"> ভূমি তথ্য </h3>
              
                            <div class="row">
                               
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="bn-text">ক্রমিক নং:</label>
                                        <input class="form-control" type="text" name="sl_no" value="<?php echo $sl_no = str_pad(mt_rand(1,999999999999),12,'0',STR_PAD_LEFT); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="bn-text">চালান নং:</label>
                                        <input class="form-control" type="text" name="chalan_no" value="<?php echo $chalan_no = str_pad(mt_rand(1,9999),4,'0',STR_PAD_LEFT).'-'.str_pad(mt_rand(1,9999999999),10,'0',STR_PAD_LEFT); ?>" required>
                                    </div>
                                </div>
                                    
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="bn-text">সিটি কর্পোরেশন / পৌর / ইউনিয়ন ভূমি অফিসের নাম:</label>
                                        <input class="form-control" type="text" name="office_name" value="" required>
                                    </div>
                                </div>
                                    
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="bn-text">মৌজার ও জে. এল. নং:</label>
                                        <input class="form-control bn-input" type="text" name="muja_no" required>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="bn-text">উপজেলা / থানা:</label>
                                        <input class="form-control bn-input" type="text" name="upazila_name" required>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="bn-text">জেলা:</label>
                                        <input class="form-control bn-input" type="text" name="zila_name" required>
                                    </div>
                                </div>

                               
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="bn-text">২ নং রেজিস্টার অনুযায়ী হোল্ডিং নম্বর:</label>
                                        <input class="form-control bn-input" type="text" name="holding_no" required>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="bn-text">খতিয়ান নং:</label>
                                        <input class="form-control bn-input" type="text" name="khotiyan_no" required>
                                    </div>
                                </div>
                                
                               <div class="col-md-6">
        <div class="row">
    <div class="col-md-6">
        <div class="form-group">
        <label class="bn-text">পরিশোধের সাল: (BN)</label>
            <input class="form-control input" type="text" name="porishud" <input class="form-control input" type="text" name="porishud" placeholder="2024-2025 (অর্থবছর)" value="<?php echo e(isset($land) ? $land->porishud : ''); ?>" required>


        </div>
    
</div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bn-text">তারিখ (EN):</label>
                                                <input maxlength="10" class="form-control bn-input datetime" type="text" name="publish_date" placeholder="dd-mm-yyyy" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bn-text">দিন:</label>
                                                <select class="form-control bn-input" name="din" required>
                                                    <option value="">--নির্বাচন--</option>
                                                <?php
                                                for ($din = 1; $din <= 31; $din++) {
                                                    echo '<option value="'.bn_number($din).'">'.bn_number($din).'</option>';
                                                }
                                                ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bn-text">মাস:</label>
                                                <select class="form-control bn-input" name="mas" required>
                                                    <option value="">--নির্বাচন--</option>
                                                <?php
                                                $mas_bn = [
                                                    'বৈশাখ',
                                                    'জ্যৈষ্ঠ',
                                                    'আষাঢ়',
                                                    'শ্রাবণ',
                                                    'ভাদ্র',
                                                    'আশ্বিন',
                                                    'কার্তিক',
                                                    'অগ্রহায়ণ',
                                                    'পৌষ',
                                                    'মাঘ',
                                                    'ফাল্গুন',
                                                    'চৈত্র',
                                                ];
                                                for($mas = 0;$mas < count($mas_bn);$mas++){
                                                    echo '<option value="'.$mas_bn[$mas].'">'.$mas_bn[$mas].'</option>';
                                                }
                                                ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="bn-text">বছর:</label>
                                                <select class="form-control bn-input" name="bochor" required>
                                                    <option value="">--নির্বাচন--</option>
                                                <?php
                                                for ($din = 1400; $din <= 1490; $din++) {
                                                    echo '<option value="'.bn_number($din).'">'.bn_number($din).'</option>';
                                                }
                                                ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered">
                                            <thead class="thead-dark">
                                            <tr>
                                                <th class="bn-text">ক্রম</th>
                                                <th class="bn-text">মালিকের নাম</th>
                                                <th class="bn-text">মালিকের অংশ </th>
                                                <th class="bn-text">আরও</th>
                                            </tr>
                                            </thead>
                                            <tbody class="malik_wrapper">
                                            <tr>
                                                <td width="1%">
                                                    <div class="form-group">
                                                        <label class="bn-text mcromik">১</label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="মালিকের নাম" class="form-control bn-input" type="text" name="m_name[]" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="মালিকের অংশ" class="form-control bn-input" type="text" name="m_total[]" >
                                                    </div>
                                                </td>
                                                <td width="1%">
                                                    <a href="javascript:void(0);" class="malik_plus malik_add_button btn btn-info btn-sm"><i class="fa fa-plus"></i></a>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered">
                                            <thead class="thead-dark">
                                            <tr>
                                                <th class="bn-text">ক্রম</th>
                                                <th class="bn-text">দাগ নং</th>
                                                <th class="bn-text">জমির শ্রেণী</th>
                                                <th class="bn-text">জমির পরিমাণ (EN)</th>
                                                <th class="bn-text">আরও</th>
                                            </tr>
                                            </thead>
                                            <tbody class="field_wrapper">
                                            <tr>
                                                <td width="1%">
                                                    <div class="form-group">
                                                        <label class="bn-text" id="cromik">১</label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="৬২৮৫" class="form-control bn-input" type="text" name="dag_no[]" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="পুকুর( কৃষি ২)" class="form-control bn-input" type="text" name="jomi_type[]" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="জমির পরিমাণ (শতক) শুধুমাত্র ইংলিশ লিখা যাবে! যেমন: 12.00000" class="form-control bn-input" type="text" name="jomi_poriman[]" required>
                                                    </div>
                                                </td>
                                                <td width="1%">
                                                    <a href="javascript:void(0);" class="plus add_button btn btn-info btn-sm"><i class="fa fa-plus"></i></a>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered">
                                            <thead class="thead-dark">
                                            <h1 class="bn-text" style="text-align: center;font-size: 18px !important;color: #000;margin-bottom: 15px;">আদায়ের বিবরণ</h1>
                                            <tr>
                                                <th class="bn-text">তিন বৎসরের ঊর্ধ্বের বকেয়া (EN)</th>
                                                <th class="bn-text">গত তিন বৎসরের বকেয়া (EN)</th>
                                                <th class="bn-text">বকেয়ার সুদ ও ক্ষতিপূরণ (EN)</th>
                                                <th class="bn-text">হাল দাবি (EN)</th>
                                                <th class="bn-text">মোট দাবি (EN)</th>
                                                <th class="bn-text">মোট আদায় (EN)</th>
                                                <th class="bn-text">মোট বকেয়া (EN)</th>
                                                <th class="bn-text">মন্তব্য</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="০" class="form-control bn-input" type="text" name="tin_bokaya" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="০" class="form-control bn-input" type="text" name="goto_bokaya" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="০" class="form-control bn-input" type="text" name="bokayar_khoti" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="০" class="form-control bn-input" type="text" name="hall_dabi" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="০" class="form-control bn-input" type="text" name="mot_dabi" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="০" class="form-control bn-input" type="text" name="mot_aday" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="০" class="form-control bn-input" type="text" name="mot_bokaya" required>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <input placeholder="" class="form-control bn-input" type="text" name="montobo">
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                
                                <button type="submit" class="btn btn-primary bn-text" name="submit" style="margin: 0 auto; display: block;"><i class="fa fa-check"></i> সাবমিট</button>
                                   
                            </div>
                        </form>

     
            
       
          
            
            
        </div>
    </div>
    
    
    
   
   
 
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
     <script>
$(document).ready(function() {
    var maxField = 1000; // Input fields increment limitation
    var addButton = $('.add_button'); // Add button selector
    var wrapper = $('.field_wrapper'); // Input field wrapper
    var fieldHTML = '<tr class="minus"><td width="1%"><div class="form-group"><label class="bn-text">+</label></div></td><td><div class="form-group"><input class="form-control bn-input" type="text" name="dag_no[]" required></div></td><td><div class="form-group"><input class="form-control bn-input" type="text" name="jomi_type[]" required></div></td><td><div class="form-group"><input class="form-control bn-input" type="text" name="jomi_poriman[]" required></div></td><td width="1%"><a href="javascript:void(0);" class="minus remove_button btn btn-warning btn-sm"><i class="fa fa-minus"></i></a></td></tr>'; // New input field html 
    var x = $('.field_wrapper tr').length; // Get initial count of fields

    // Once add button is clicked
    $(addButton).click(function() {
        // Check maximum number of input fields
        if (x < maxField) {
            x++; // Increase field counter
            document.getElementById("cromik").innerHTML = x;
            $(wrapper).append(fieldHTML); // Add field html
        } else {
            alert('A maximum of ' + maxField + ' fields are allowed to be added.');
        }
    });

    // Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e) {
        e.preventDefault();
        $(this).closest('tr').remove(); // Remove field html
        x--; // Decrease field counter
        document.getElementById("cromik").innerHTML = x;
    });

    // For malik_wrapper
    let thtml = '<tr><td width="1%"><div class="form-group"><label class="bn-text mcromik1">+</label></div></td><td><div class="form-group"><input placeholder="মালিকের নাম" class="form-control bn-input" type="text" name="m_name[]" required></div></td><td><div class="form-group"><input placeholder="মালিকের অংশ" class="form-control bn-input" type="text" name="m_total[]"></div></td><td width="1%"><a href="javascript:void(0);" class="malik_remove btn btn-danger btn-sm"><i class="fa fa-minus"></i></a></td></tr>';
    let l = $('.malik_wrapper tr').length; // Get initial count of malik fields

    $('.malik_add_button').click(function() {
        if (l < maxField) {
            l++;
            $('.mcromik').html(l);
            $('.malik_wrapper').append(thtml);
        } else {
            alert('A maximum of ' + maxField + ' fields are allowed to be added.');
        }
    });

    $('.malik_wrapper').on('click', '.malik_remove', function(e) {
        e.preventDefault();
        $(this).closest('tr').remove(); // Remove field html
        l--; // Decrease field counter
        $('.mcromik').html(l);
    });
});

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/land/create.blade.php ENDPATH**/ ?>