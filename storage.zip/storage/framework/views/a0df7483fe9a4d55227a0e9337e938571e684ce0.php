

<?php $__env->startSection('title'); ?>
    এনআইডি তালিকা
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-custom m-0 m-md-4 my-4 m-md-0 shadow">
    <div class="card-body">
        <div class="row justify-content-between mb-4">
            <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center">
                    <h3 class="card-title text-primary mb-0">
                        <i class="fas fa-id-card fa-fw"></i> এনআইডি তালিকা
                    </h3>
                    <a href="<?php echo e(route('user.nid.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus fa-fw"></i> নতুন এনআইডি
                    </a>
                </div>
                <hr class="border-primary opacity-75 mt-3">
            </div>
        </div>

        <?php if($nids->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>ক্রমিক</th>
                            <th>ছবি</th>
                            <th>নাম (বাংলা)</th>
                            <th>এনআইডি নাম্বার</th>
                            <th>জন্ম তারিখ</th>
                            <th>স্ট্যাটাস</th>
                            <th width="150">অ্যাকশন</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $nids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($nids->firstItem() + $key); ?></td>
                                <td class="text-center">
                                    <?php if(!empty($nid->photo)): ?>
                                        <?php
                                            $photoPath = $nid->photo;
                                            if (\Illuminate\Support\Facades\Storage::disk('public')->exists($photoPath)) {
                                                try {
                                                    $photoContents = \Illuminate\Support\Facades\Storage::disk('public')->get($photoPath);
                                                    $mime = finfo_buffer(finfo_open(), $photoContents, FILEINFO_MIME_TYPE) ?: 'image/jpeg';
                                                    $photoBase64 = 'data:' . $mime . ';base64,' . base64_encode($photoContents);
                                                } catch (\Exception $e) {
                                                    $photoBase64 = null;
                                                }
                                            }
                                        ?>
                                        <?php if(!empty($photoBase64)): ?>
                                            <img src="<?php echo e($photoBase64); ?>" alt="ফটো" class="img-thumbnail" style="max-width: 50px;">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('storage/' . $nid->photo)); ?>" alt="ফটো" class="img-thumbnail" style="max-width: 50px;">
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div class="img-thumbnail" style="width:50px;height:50px;display:inline-block;background:#f5f5f5;"></div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($nid->name_bn); ?></td>
                                <td><?php echo e($nid->nid_number); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($nid->date_of_birth)->format('d/m/Y')); ?></td>
                                <td>
                                    <span class="badge badge-pill badge-success">
                                        সম্পন্ন
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('user.nid.show', $nid->id)); ?>" 
                                           class="btn btn-info" 
                                           title="বিস্তারিত দেখুন">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('user.nid.edit', $nid->id)); ?>" 
                                           class="btn btn-primary" 
                                           title="সম্পাদনা করুন">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('user.nid.destroy', $nid->id)); ?>" 
                                              method="POST" 
                                              class="d-inline delete-form"
                                              onsubmit="return confirm('আপনি কি নিশ্চিত যে আপনি এই এনআইডি মুছে ফেলতে চান?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" 
                                                    class="btn btn-danger" 
                                                    title="মুছে ফেলুন">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

   
        <?php else: ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-info-circle fa-2x mb-2"></i>
                <p class="mb-0">কোন এনআইডি পাওয়া যায়নি!</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/nid/index.blade.php ENDPATH**/ ?>