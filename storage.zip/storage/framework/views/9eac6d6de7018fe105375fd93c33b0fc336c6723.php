

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Recharge'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3"><i class="icon-user"></i> <?php echo app('translator')->get('Recharge'); ?></h4>

                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <div style="display: flex; align-items: center; justify-content: center; flex-wrap: wrap;">
                        <div style="margin-right: 20px;">
                            <a href="<?php echo e(route('user.bkash')); ?>" style="display: inline-block; width: 100px; height: 50px; border: 2px solid #007bff; border-radius: 5px; text-align: center; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                                <img src="https://freelogopng.com/images/all_img/1656227753bkash-logo-png-download.png" style="width: 100%; height: 85%; object-fit: contain;" />
                            </a>
                        </div>

                        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="margin-right: 20px;">
                                <a href="<?php echo e(route('user.recharge-form', $gateway->id)); ?>" style="display: inline-block; width: 100px; height: 50px; border: 2px solid #007bff; border-radius: 5px; text-align: center; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                                    <img src="<?php echo e(url('storage/uploads/' . $gateway->logo)); ?>" style="width: 100%; height: auto; object-fit: contain;" />
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!--- <div style="margin-right: 20px;">
                            <!--- <a href="<?php echo e(route('user.aamarpay')); ?>" style="display: inline-block; width: 100px; height: 50px; border: 2px solid #007bff; border-radius: 5px; text-align: center; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                                <!--- <img src="https://cdn4.iconfinder.com/data/icons/payment-method/160/payment_method_card_visa-1024.png" style="width: 100%; height: 95%; object-fit: contain;" />
                            <!--- </a>
                        <!--- </div>
                    <!--- </div>--->

                    <hr/>

                    <h3 class="card-title mt-3">Recharge History</h3>

                    <table class="categories-show-table table table-hover table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('No.'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Gateway'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('From No.'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('TXID'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recharges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $recharge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('No.'); ?>"><?php echo e($key + 1); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Amount'); ?>"><?php echo e($recharge->amount); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Gateway'); ?>"><?php echo e(@$recharge->gateway->name); ?></td>
                                    <td data-label="<?php echo app('translator')->get('From'); ?>"><?php echo e(@$recharge->from); ?></td>
                                    <td data-label="<?php echo app('translator')->get('TXID'); ?>"><?php echo e(@$recharge->txid); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($recharge->status == '0'): ?>
                                            <b style="color:red">Pending</b>
                                        <?php endif; ?>
                                        <?php if($recharge->status == '1'): ?>
                                            <b style="color:green">Success</b>
                                        <?php endif; ?>
                                        <?php if($recharge->status == '2'): ?>
                                            <b style="color:red">Rejected</b>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center text-danger" colspan="9"><?php echo app('translator')->get('No Data'); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($recharges->appends(@$_GET)->links('partials.pagination')); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/recharge.blade.php ENDPATH**/ ?>