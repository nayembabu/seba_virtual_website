<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Sign Copy Orders Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            z-index: 1000;
            overflow-y: auto;
            transition: all 0.3s;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0 10px;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.2);
            color: white;
            transform: translateX(5px);
        }
        .sidebar-menu a i {
            margin-right: 12px;
            font-size: 18px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
            padding: 20px;
            transition: all 0.3s;
        }
        .top-navbar {
            background: white;
            padding: 15px 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .badge-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-approved {
            background: #d4edda;
            color: #155724;
        }
        .badge-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .badge-completed {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        /* Mobile Sidebar Toggle Button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transition: all 0.3s;
        }
        .sidebar-toggle:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        .sidebar-toggle i {
            font-size: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar-toggle {
                display: block;
            }
            .sidebar {
                left: -260px;
            }
            .main-content {
                margin-left: 0;
                padding-top: 70px;
            }
        }
    </style>
</head>
<body>
     <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Mobile Menu Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Top Navbar -->
        <div class="top-navbar">
            <h4 class="mb-0">Sign Copy Orders Management</h4>
            <div>
                <span class="text-muted">Welcome, Admin</span>
            </div>
        </div>

        <!-- Page Header -->
        <div class="page-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2><i class="fas fa-file-signature text-primary"></i> সাইন কপি অর্ডার ম্যানেজমেন্ট</h2>
                    <p class="text-muted mb-0">সকল সাইন কপি অর্ডারের তালিকা এবং পরিচালনা</p>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h3><?php echo e($orders->count()); ?></h3>
                        <p class="mb-0">Total Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h3><?php echo e($orders->where('status', 0)->count()); ?></h3>
                        <p class="mb-0">Pending</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h3><?php echo e($orders->where('status', 1)->count()); ?></h3>
                        <p class="mb-0">Approved</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h3><?php echo e($orders->where('status', 3)->count()); ?></h3>
                        <p class="mb-0">Completed</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <input type="text" class="form-control" placeholder="Search orders by user name, phone, NID...">
                    </div>
                    <div class="col-md-4">
                        <select class="form-select">
                            <option>All Orders</option>
                            <option>Pending</option>
                            <option>Approved</option>
                            <option>Rejected</option>
                            <option>Completed</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orders List -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0">Sign Copy Orders List</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th></th>
                                <th>Order ID</th>
                                <th>User Name</th>
                                <th>Phone</th>
                                <th>Form Type</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>PDF Upload</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="order-row" onclick="toggleDetails(<?php echo e($order->id); ?>)" style="cursor: pointer;">
                                    <td>
                                        <i class="fas fa-chevron-right expand-icon-<?php echo e($order->id); ?>" id="icon-<?php echo e($order->id); ?>"></i>
                                    </td>
                                    <td>
                                        <strong>#<?php echo e($order->id); ?></strong>
                                    </td>
                                    <td>
                                        <strong><?php echo e($order->user->name ?? 'N/A'); ?></strong><br>
                                        <small class="text-muted"><?php echo e($order->user->email ?? 'N/A'); ?></small>
                                    </td>
                                    <td><?php echo e($order->user->phone ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge bg-info"><?php echo e($order->form_type_name); ?></span>
                                    </td>
                                    <td><strong>৳ <?php echo e(number_format($order->cost, 2)); ?></strong></td>
                                    <td>
                                        <?php if($order->status == 0): ?>
                                            <span class="badge-status badge-pending">Pending</span>
                                        <?php elseif($order->status == 1): ?>
                                            <span class="badge-status badge-approved">Approved</span>
                                        <?php elseif($order->status == 2): ?>
                                            <span class="badge-status badge-rejected">Rejected</span>
                                        <?php elseif($order->status == 3): ?>
                                            <span class="badge-status badge-completed">Completed</span>
                                        <?php else: ?>
                                            <span class="badge-status">Unknown</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($order->created_at->format('d M, Y')); ?></td>
                                    <td>
                                        <?php if($order->admin_note): ?>
                                            <a href="<?php echo e(route('admin.sign-copy-orders.download', $order->admin_note)); ?>" class="btn btn-sm btn-success" title="Download PDF">
                                                <i class="fas fa-download"></i> Download
                                            </a>
                                        <?php else: ?>
                                            <input type="file" id="pdf-<?php echo e($order->id); ?>" accept=".pdf" style="display: none;" onchange="uploadPDF(<?php echo e($order->id); ?>, this)">
                                            <button class="btn btn-sm btn-primary" onclick="document.getElementById('pdf-<?php echo e($order->id); ?>').click(); event.stopPropagation();" title="Upload PDF">
                                                <i class="fas fa-file-pdf"></i> Upload
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                    <td onclick="event.stopPropagation();">
                                        <?php if($order->status == 0): ?>
                                            <button class="btn btn-sm btn-success" onclick="approveOrder(<?php echo e($order->id); ?>)" title="Approve">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="rejectOrder(<?php echo e($order->id); ?>)" title="Reject">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        <?php elseif($order->status == 1): ?>
                                            <button class="btn btn-sm btn-primary" onclick="completeOrder(<?php echo e($order->id); ?>)" title="Complete">
                                                <i class="fas fa-check-double"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <!-- Expandable Details Row -->
                                <tr id="details-row-<?php echo e($order->id); ?>" class="details-row" style="display: none;">
                                    <td colspan="10">
                                        <div class="details-panel p-4" style="background: #f9f9f9; border-left: 4px solid #667eea;">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <h6 class="mb-3"><i class="fas fa-user-circle"></i> User Information</h6>
                                                    <p><strong>Order ID:</strong> #<?php echo e($order->id); ?></p>
                                                    <p><strong>User Name:</strong> <?php echo e($order->user->name ?? 'N/A'); ?></p>
                                                    <p><strong>Email:</strong> <?php echo e($order->user->email ?? 'N/A'); ?></p>
                                                    <p><strong>Phone:</strong> <?php echo e($order->user->phone ?? 'N/A'); ?></p>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6 class="mb-3"><i class="fas fa-info-circle"></i> Order Information</h6>
                                                    <p><strong>Form Type:</strong> <?php echo e($order->form_type_name); ?></p>
                                                    <p><strong>Price:</strong> ৳ <?php echo e(number_format($order->cost, 2)); ?></p>
                                                    <p><strong>Status:</strong>
                                                        <?php if($order->status == 0): ?>
                                                            <span class="badge-status badge-pending">Pending</span>
                                                        <?php elseif($order->status == 1): ?>
                                                            <span class="badge-status badge-approved">Approved</span>
                                                        <?php elseif($order->status == 2): ?>
                                                            <span class="badge-status badge-rejected">Rejected</span>
                                                        <?php elseif($order->status == 3): ?>
                                                            <span class="badge-status badge-completed">Completed</span>
                                                        <?php endif; ?>
                                                    </p>
                                                    <p><strong>Created:</strong> <?php echo e($order->created_at->format('d M, Y H:i:s')); ?></p>
                                                </div>
                                            </div>

                                            <hr>

                                            <h6 class="mb-3"><i class="fas fa-list"></i> Form Data</h6>
                                            <?php if(is_array($order->form_data) && count($order->form_data) > 0): ?>
                                                <div class="row">
                                                    <?php $__currentLoopData = $order->form_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-6 mb-2">
                                                            <div class="p-2" style="background: white; border-radius: 5px; border-left: 3px solid #667eea;">
                                                                <strong><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:</strong><br>
                                                                <span class="text-muted"><?php echo e(is_array($value) ? json_encode($value) : $value); ?></span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php else: ?>
                                                <p class="text-muted">No form data available</p>
                                            <?php endif; ?>

                                            <hr>

                                            <div class="d-flex justify-content-end gap-2">
                                                <button class="btn btn-sm btn-secondary" onclick="toggleDetails(<?php echo e($order->id); ?>)">
                                                    <i class="fas fa-times"></i> Close
                                                </button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-danger py-4">
                                        <i class="fas fa-inbox"></i> No orders found
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white">
                <nav>
                    <ul class="pagination mb-0">
                        <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Rejection Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="rejectModalLabel">
                        <i class="fas fa-times-circle"></i> অর্ডার বাতিল করুন
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3"><strong>বাতিল করার কারণ নির্বাচন করুন:</strong></p>
                    <div class="d-flex flex-column gap-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason1" value="নথিপত্র অসম্পূর্ণ বা অবৈধ">
                            <label class="form-check-label" for="reason1">
                                নথিপত্র অসম্পূর্ণ বা অবৈধ
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason2" value="ডকুমেন্টের মান দুর্বল">
                            <label class="form-check-label" for="reason2">
                                ডকুমেন্টের মান দুর্বল
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason3" value="তথ্য মিলছে না">
                            <label class="form-check-label" for="reason3">
                                তথ্য মিলছে না
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason4" value="ব্যবহারকারীর বাতিলের অনুরোধ">
                            <label class="form-check-label" for="reason4">
                                ব্যবহারকারীর বাতিলের অনুরোধ
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল করুন</button>
                    <button type="button" class="btn btn-danger" onclick="confirmReject()">
                        <i class="fas fa-check"></i> নিশ্চিত করুন
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleDetails(orderId) {
            const detailsRow = document.getElementById('details-row-' + orderId);
            const icon = document.getElementById('icon-' + orderId);
            
            if (detailsRow.style.display === 'none' || !detailsRow.style.display) {
                detailsRow.style.display = 'table-row';
                icon.classList.remove('fa-chevron-right');
                icon.classList.add('fa-chevron-down');
            } else {
                detailsRow.style.display = 'none';
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-right');
            }
        }

        function uploadPDF(orderId, fileInput) {
            const file = fileInput.files[0];

            if (!file) {
                return;
            }

            // Check file size (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                alert('File size must not exceed 10MB');
                return;
            }

            // Check file type
            if (file.type !== 'application/pdf') {
                alert('Only PDF files are allowed');
                return;
            }

            const formData = new FormData();
            formData.append('pdf_file', file);
            const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>';

            // Find the upload button and show loading state
            const button = fileInput.parentElement.querySelector('button');
            if (button) {
                button.disabled = true;
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            }

            fetch(`/admin/sign-copy-orders/${orderId}/upload-pdf`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    // alert(data.message); // Removed confirmation popup
                    fileInput.value = ''; // Clear file input
                    if (button) {
                        button.disabled = false;
                        button.innerHTML = '<i class="fas fa-file-pdf"></i> Upload';
                    }
                    location.reload(); // Reload to show new file
                } else {
                    alert('Error: ' + data.message);
                    if (button) {
                        button.disabled = false;
                        button.innerHTML = '<i class="fas fa-file-pdf"></i> Upload';
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while uploading the PDF: ' + error.message);
                if (button) {
                    button.disabled = false;
                    button.innerHTML = '<i class="fas fa-file-pdf"></i> Upload';
                }
            });
        }

        let currentRejectOrderId = null;

        function approveOrder(orderId) {
            updateOrderStatus(orderId, 'approve');
        }

        function rejectOrder(orderId) {
            currentRejectOrderId = orderId;
            // Show rejection modal
            const rejectModal = new bootstrap.Modal(document.getElementById('rejectModal'));
            rejectModal.show();
        }

        function confirmReject() {
            // Get selected reason
            const selectedReason = document.querySelector('input[name="rejectionReason"]:checked');
            
            if (!selectedReason) {
                alert('অনুগ্রহ করে বাতিলের কারণ নির্বাচন করুন');
                return;
            }

            const reason = selectedReason.value;
            
            // Close modal
            const rejectModal = bootstrap.Modal.getInstance(document.getElementById('rejectModal'));
            rejectModal.hide();

            // Update order status with reason
            updateOrderStatusWithReason(currentRejectOrderId, 'reject', reason);
        }

        function completeOrder(orderId) {
            updateOrderStatus(orderId, 'complete');
        }

        function updateOrderStatus(orderId, action) {
            const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>';
            
            fetch(`/admin/sign-copy-orders/${orderId}/${action}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({})
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    // alert(data.message); // Removed confirmation popup
                    location.reload(); // Reload page to see changes
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the order');
            });
        }

        function updateOrderStatusWithReason(orderId, action, reason) {
            const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>';
            
            fetch(`/admin/sign-copy-orders/${orderId}/${action}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ status_note: reason })
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    // alert(data.message); // Removed confirmation popup
                    location.reload(); // Reload page to see changes
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the order');
            });
        }
    </script>
</body>
</html>
<?php /**PATH /home/ifixfast24/public_html/resources/views/admin/sign_copy_order/index.blade.php ENDPATH**/ ?>