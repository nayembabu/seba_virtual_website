
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get($title); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            
            
         
               <div class="text-right">
                <a href="<?php echo e(route('user.surokkha.create')); ?>" class="btn btn-success"> <i class="fas fa-plus"></i> Add Certificate </a>
               </div>
               
                 <div style="overflow-x:auto;">
                <table class="categories-show-table table table-hover table-striped table-bordered" >
                    <thead class="thead-dark">
                    <tr>
                       
                        <th scope="col"><?php echo app('translator')->get('No.'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Name'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Date of Birth'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Nationality'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Gender'); ?></th>
                        <th scope="col" style="text-align:center"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            
                            <td data-label="<?php echo app('translator')->get('No.'); ?>">
                                <?php echo e($key + 1); ?>

                                </td>
                            <td data-label="<?php echo app('translator')->get('Name'); ?>">
                               <?php echo e($data->name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Date of Birth'); ?>">
                               <?php echo e($data->date_birth); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Nationality'); ?>">
                             <?php echo e($data->nationality); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Gender'); ?>">
                            <?php echo e($data->gender); ?>

                            </td>
                         
                            
                            <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-lg-center text-right">
        
                              <a href="<?php echo e(route('user.surokkha.edit', $data->id)); ?>" class="btn btn-info"> <i class="fas fa-pencil-alt"> </i> Edit </a>
                                
                                <form style="display:inline-block" action="<?php echo e(route('user.surokkha.destroy',$data->id)); ?>" method="post" onsubmit="return confirm('Do you really want to delete this?');">
                                          <?php echo csrf_field(); ?> 
                                          <?php echo method_field('DELETE'); ?>
                                         <button class="btn btn-danger"> <i class="fas fa-trash"></i> Delete  </button>
                               </form>
                               
                                <a href="<?php echo e(route('user.surokkha.print',$data->id)); ?>" class="btn btn-primary" target="_blank"> <i class="fas fa-print"></i> Download </a>
                               
                            
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-danger" colspan="9"><?php echo app('translator')->get('No Data'); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                 </div>
                
                <?php echo e($objects->appends(@$_GET)->links('partials.pagination')); ?>

            </div>
        </div>
    </div>
    
    
   
    

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script>
         $(document).on('click', '.recharge', function () {
          
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/surokkha/index.blade.php ENDPATH**/ ?>