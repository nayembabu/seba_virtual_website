
<?php $__env->startSection('title'); ?>
    সাইন কপি অর্ডার
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style>
    .classic-card {
        background: linear-gradient(to bottom, #ffffff 0%, #f8f9fa 100%);
        border: none;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1) !important;
    }

    .classic-header {
        background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
        color: white;
        padding: 20px;
        border-radius: 5px 5px 0 0;
        margin: -1.25rem -1.25rem 1rem -1.25rem;
    }

    .btn-option {
        position: relative;
        padding: 8px 12px;
        font-size: 0.95rem;
        text-align: left;
        margin-bottom: 5px;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        transition: all 0.3s ease;
        width: 100%;
        height: 100%;
        min-height: 60px;
        background: #ffffff;
        color: #2c3e50;
        display: flex;
        align-items: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }
    
    .btn-option .btn-text {
        font-size: 0.88rem;
        color: #2c3e50;
        font-weight: 500;
        line-height: 1.2;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        word-break: break-word;
    }
    
    .btn-option .btn-subtext {
        font-size: 0.85rem;
        color: #666;
        margin-left: 4px;
    }
    
    .btn-option .text-block {
        flex: 1;
        min-width: 0;
        padding-right: 8px;
    }
    
    .option-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        margin-bottom: 20px;
        max-width: 1000px;
        margin-left: auto;
        margin-right: auto;
        padding: 0 15px;
    }
    
    .option-column {
        display: grid;
        grid-template-rows: repeat(3, 1fr);
        gap: 15px;
    }
    
    .btn-option i {
        font-size: 1.1rem;
        margin-right: 12px;
        color: #3498db;
        width: 24px;
        text-align: center;
    }
    
    .btn-option .badge {
        font-size: 0.9rem;
        padding: 5px 12px;
        background: #3498db;
        color: white;
        border-radius: 20px;
        margin-left: auto;
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    
    .btn-option:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.08);
        border-color: #3498db;
        background: linear-gradient(to bottom, #ffffff 0%, #e9f2ff 100%);
    }
    
    .btn-option.active {
        background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
        color: white;
        border-color: #2980b9;
    }
    
    .btn-option.active i {
        color: white;
    }
    
    .btn-option.active .badge {
        background: white;
        color: #2980b9;
    }

    @media (max-width: 768px) {
        .option-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            padding: 10px;
        }
        
        .option-column {
            display: grid;
            grid-template-columns: 1fr;
            grid-template-rows: auto;
            gap: 10px;
        }
        
        .btn-option {
            min-height: 70px;
            padding: 8px 10px;
            font-size: 0.9rem;
            margin-bottom: 0;
        }
        
        .btn-option i {
            font-size: 1rem;
            margin-right: 8px;
            width: 20px;
        }
        
        .btn-option .badge {
            font-size: 0.8rem;
            padding: 4px 8px;
            margin-left: 5px;
        }
        
        .btn-option .btn-text {
            font-size: 0.9rem;
            line-height: 1.2;
        }
        
        .text-block {
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
    }

    .btn-option:hover {
        border-color: #1976d2;
        background: #f8f9fa;
        transform: translateY(-2px);
    }

    .btn-option.active {
        background: linear-gradient(to right, #1976d2, #2196f3);
        color: white;
        border: none;
    }

    .btn-option i {
        margin-right: 12px;
        font-size: 1.2rem;
    }
    
    .btn-option .badge {
        background: #1976d2;
        color: white;
    }
    
    .btn-option.active .badge {
        background: white;
        color: #1976d2;
    }

    .form-container {
        width: 100%;
        padding: 20px;
        border-radius: 8px;
        background-color: #fff;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        display: none;
        margin-top: 20px;
        opacity: 0;
        transition: all 0.3s ease-out;
    }

    .form-container.active {
        opacity: 1;
        display: block;
    }

    .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }

    .close-modal {
        background: none;
        border: none;
        font-size: 1.5rem;
        color: #666;
        cursor: pointer;
        padding: 0;
    }

    .classic-table {
        border: 1px solid #e1e1e1;
        border-radius: 5px;
        overflow: hidden;
    }

    .classic-table thead {
        background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
        color: white;
    }

    /* Mobile Order Row Styles */
    .mobile-order-row {
        background: #fff;
        border: 1px solid #e6e6e6;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 8px;
        display: flex;
        align-items: flex-start;
        font-size: 0.9rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }

    .row-number {
        font-weight: 600;
        color: #1e4c78;
        margin-right: 15px;
        min-width: 28px;
        text-align: center;
        background: #f8f9fa;
        padding: 4px 8px;
        border-radius: 4px;
    }

    .row-content {
        flex: 1;
        color: #333;
        display: grid;
        grid-gap: 8px;
    }
    
    .row-content .info-line {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .row-content .service-type {
        font-weight: 500;
        color: #1e4c78;
    }

    .row-content .text-muted {
        color: #6c757d;
        font-size: 0.85rem;
    }
    
    .row-content .badge {
        padding: 6px 10px;
        font-size: 0.8rem;
        border-radius: 4px;
        font-weight: 500;
    }

    .row-content .btn-sm {
        padding: 5px 10px;
        font-size: 0.8rem;
        border-radius: 4px;
        margin-left: auto;
    }

    .row-content .badge.bg-warning {
        background: #ffc107 !important;
        color: #000;
    }
    
    .row-content .badge.bg-info {
        background: #0dcaf0 !important;
    }
    
    .row-content .badge.bg-success {
        background: #198754 !important;
    }
    
    .row-content .badge.bg-danger {
        background: #dc3545 !important;
    }

    @media (max-width: 767px) {
        .card {
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
        }
        
        .card-body {
            padding: 1rem;
        }

        .mobile-order-details {
            font-size: 0.9rem;
        }
    }
    
    .form-label {
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    
    .file-upload {
        border: 2px dashed #ddd;
        padding: 1.5rem;
        text-align: center;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .file-upload:hover {
        border-color: #1976d2;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="card classic-card m-0 m-md-4 my-4 m-md-0">
    <div class="card-body">
        <!-- Error Messages -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- Option Buttons -->
        <div class="option-grid">
            <div class="option-column">
                <button type="button" class="btn-option" data-form="1">
                    <i class="fas fa-check-circle"></i>
                    <div class="text-block">
                        <span class="btn-text">&nbsp;১০/১২/১৭ দিয়ে সাইন</span>
                       
                    </div>
                    <span class="badge">৳<?php echo e($orderTypes[1]->cost ?? 50); ?></span>
                </button>
                <button type="button" class="btn-option" data-form="2">
                    <i class="fas fa-check-circle"></i>
                    <div class="text-block">
                        <span class="btn-text">&nbsp;ফরম/নিবন্ধন নং/১৩ডিজিট দিয়ে সাইন</span>
                        
                    </div>
                    <span class="badge">৳<?php echo e($orderTypes[2]->cost ?? 60); ?></span>
                </button>
                <button type="button" class="btn-option" data-form="3">
                    <i class="fas fa-check-circle"></i>
                    <div class="text-block">
                        <span class="btn-text">&nbsp;অফিসিয়াল সারভার কপি</span>
                    
                    </div>
                    <span class="badge">৳<?php echo e($orderTypes[3]->cost ?? 70); ?></span>
                </button>
            </div>
            <div class="option-column">
                <button type="button" class="btn-option" data-form="4">
                    <i class="fas fa-check-circle"></i>
                    <div class="text-block">
                        <span class="btn-text">&nbsp;NID CMS COPY অর্ডার</span>
                  
                    </div>
                    <span class="badge">৳<?php echo e($orderTypes[4]->cost ?? 80); ?></span>
                </button>
                <button type="button" class="btn-option" data-form="5">
                    <i class="fas fa-check-circle"></i>
                    <div class="text-block">
                        <span class="btn-text">&nbsp;নাম ঠিকানা দিয়ে সাইন</span>
                     
                    </div>
                
                    <span class="badge">৳<?php echo e($orderTypes[5]->cost ?? 90); ?></span>
                </button>
                <button type="button" class="btn-option" data-form="6">
                    <i class="fas fa-check-circle"></i>
                    <div class="text-block">
                        <span class="btn-text">&nbsp;ম্যাচ ফাউন্ড / ডাবল ভোটার অ্যাকটিভ কপি</span>
                    
                    </div>
                    <span class="badge">৳<?php echo e($orderTypes[6]->cost ?? 100); ?></span>
                </button>
            </div>
        </div>

        <!-- Form 1: ১০/১২/১৭ দিয়ে সাইন -->
        <div id="form1" class="form-container">
            <div class="modal-header">
                <h5 class="modal-title">১০/১২/১৭ দিয়ে সাইন</h5>
                <button type="button" class="close-modal" onclick="hideForm()">&times;</button>
            </div>
            <form action="<?php echo e(route('user.sign.copy.order.store')); ?>" method="POST" class="needs-validation" id="form1Form" novalidate>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="form_type" value="1">
                <div class="form-group mb-3">
                    <textarea 
                        class="form-control" 
                        id="form1_info" 
                        name="form_info"
                        rows="4" 
                        required
                        style="font-family: 'SolaimanLipi', Arial, sans-serif; line-height: 1.8;"
                        oninput="syncInput1(this)"
                        onkeydown="handleEnterKey1(event, this)"
                        >নাম: 
এনআইডি নম্বর: 
 </textarea>
                </div>

                <div class="text-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="hideForm()">বাতিল</button>
                    <button type="submit" class="btn btn-success">জমা দিন</button>
                </div>
            </form>
        </div>

        <!-- Form 2: ফরম/নিবন্ধন নং/১৩ডিজিট -->
        <div id="form2" class="form-container">
            <div class="modal-header">
                <h5 class="modal-title">ফরম/নিবন্ধন নং/১৩ডিজিট দিয়ে সাইন</h5>
                <button type="button" class="close-modal" onclick="hideForm()">&times;</button>
            </div>
            <form action="<?php echo e(route('user.sign.copy.order.store')); ?>" method="POST" class="needs-validation" id="form2Form" novalidate>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="form_type" value="2">
                <div class="form-group mb-3">
                    <textarea 
                        class="form-control" 
                        id="form2_info" 
                        name="form_info"
                        rows="5" 
                        required
                        style="font-family: 'SolaimanLipi', Arial, sans-serif; line-height: 1.8;"
                        oninput="syncInput2(this)"
                        onkeydown="handleEnterKey2(event, this)"
                        >নাম: 
নিবন্ধন নম্বর: 
 </textarea>
                </div>

                <div class="text-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="hideForm()">বাতিল</button>
                    <button type="submit" class="btn btn-success">জমা দিন</button>
                </div>
            </form>
        </div>

        <!-- Form 3: অফিসিয়াল সারভার কপি -->
        <div id="form3" class="form-container">
            <div class="modal-header">
                <h5 class="modal-title">অফিসিয়াল সারভার কপি</h5>
                <button type="button" class="close-modal" onclick="hideForm()">&times;</button>
            </div>
            <form action="<?php echo e(route('user.sign.copy.order.store')); ?>" method="POST" class="needs-validation" id="form3Form" novalidate>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="form_type" value="3">
                <div class="form-group mb-3">
                    <textarea 
                        class="form-control" 
                        id="form3_info" 
                        name="form_info"
                        rows="5" 
                        required
                        style="font-family: 'SolaimanLipi', Arial, sans-serif; line-height: 1.8;"
                        oninput="syncInput3(this)"
                        onkeydown="handleEnterKey3(event, this)"
                        >এনআইডি নম্বর: 
জন্ম তারিখ: 
 </textarea>
                </div>

                <div class="text-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="hideForm()">বাতিল</button>
                    <button type="submit" class="btn btn-success">জমা দিন</button>
                </div>
            </form>
        </div>

        <!-- Form 4: NID CMS COPY -->
        <div id="form4" class="form-container">
            <div class="modal-header">
                <h5 class="modal-title">NID CMS COPY অর্ডার</h5>
                <button type="button" class="close-modal" onclick="hideForm()">&times;</button>
            </div>
            <form action="<?php echo e(route('user.sign.copy.order.store')); ?>" method="POST" class="needs-validation" id="form4Form" novalidate>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="form_type" value="4">
                <div class="form-group mb-3">
                    <textarea 
                        class="form-control" 
                        id="form4_info" 
                        name="form_info"
                        rows="6" 
                        required
                        style="font-family: 'SolaimanLipi', Arial, sans-serif; line-height: 1.8;"
                        oninput="syncInput4(this)"
                        onkeydown="handleEnterKey4(event, this)"
                        >এনআইডি নম্বর: 
জন্ম তারিখ: 
</textarea>
                </div>

                <div class="text-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="hideForm()">বাতিল</button>
                    <button type="submit" class="btn btn-success">জমা দিন</button>
                </div>
            </form>
        </div>
<!-- Form 5: নাম ঠিকানা দিয়ে সাইন -->
<div id="form5" class="form-container">
    <div class="modal-header">
        <h5 class="modal-title">নাম ঠিকানা দিয়ে সাইন</h5>
        <button type="button" class="close-modal" onclick="hideForm()">&times;</button>
    </div>
    <form action="<?php echo e(route('user.sign.copy.order.store')); ?>" method="POST" class="needs-validation" id="form5Form" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="form_type" value="5">
        
        <div class="form-group mb-3">
            <textarea 
                class="form-control" 
                id="form5_info" 
                name="form_info"
                rows="16" 
                required
                style="font-family: 'SolaimanLipi', Arial, sans-serif; line-height: 1.8;"
                oninput="syncInput(this)"
                onkeydown="handleEnterKey(event, this)"
                >নিজ নাম: 
পিতার নাম: 
মাতার নাম: 
স্বামী/স্ত্রী নাম: 
জন্ম সনদ (যদি থাকে): 
বিভাগ: 
জেলা: 
উপজেলা: 
ইউনিয়ন/পৌরসভা/সিটি করপোরেশন: 
ওয়ার্ড নং: 
ডাকঘর: 
গ্রাম: 
পিতার এনআইডি নং (যদি থাকে): 
মাতার এনআইডি নং (যদি থাকে): 
সাথে ভোটার হওয়া একজনের এনআইডি: </textarea>
        </div>
        
        <div class="text-end">
            <button type="button" class="btn btn-secondary me-2" onclick="hideForm()">বাতিল</button>
            <button type="submit" class="btn btn-success">জমা দিন</button>
        </div>
    </form>
</div>

<script>
const templateLines = [
    'নিজ নাম: ',
    'পিতার নাম: ',
    'মাতার নাম: ',
    'স্বামী/স্ত্রী নাম: ',
    'জন্ম সনদ (যদি থাকে): ',
    'বিভাগ: ',
    'জেলা: ',
    'উপজেলা: ',
    'ইউনিয়ন/পৌরসভা/সিটি করপোরেশন: ',
    'ওয়ার্ড নং: ',
    'ডাকঘর: ',
    'গ্রাম: ',
    'পিতার এনআইডি নং (যদি থাকে): ',
    'মাতার এনআইডি নং (যদি থাকে): ',
    'সাথে ভোটার হওয়া একজনের এনআইডি: '
];

function handleEnterKey(event, textarea) {
    if (event.key === 'Enter') {
        event.preventDefault();
        
        const cursorPos = textarea.selectionStart;
        const text = textarea.value;
        const lines = text.split('\n');
        
        // Find current line number
        let currentLineNum = 0;
        let charCount = 0;
        
        for (let i = 0; i < lines.length; i++) {
            if (charCount + lines[i].length >= cursorPos) {
                currentLineNum = i;
                break;
            }
            charCount += lines[i].length + 1;
        }
        
        // If not on last line, move to next line
        if (currentLineNum < lines.length - 1) {
            // Calculate position at start of next line (after the label)
            let nextLinePos = charCount + lines[currentLineNum].length + 1;
            
            // Move past the label on next line
            if (currentLineNum + 1 < templateLines.length) {
                nextLinePos += templateLines[currentLineNum + 1].length;
            }
            
            textarea.selectionStart = textarea.selectionEnd = nextLinePos;
        }
    }
}

function parseFormData(text) {
    const lines = text.split('\n');
    const fieldMap = {
        'নিজ নাম': 'name',
        'পিতার নাম': 'father_name',
        'মাতার নাম': 'mother_name',
        'স্বামী/স্ত্রী নাম': 'spouse_name',
        'জন্ম সনদ (যদি থাকে)': 'birth_cert',
        'বিভাগ': 'division',
        'জেলা': 'district',
        'উপজেলা': 'upazila',
        'ইউনিয়ন/পৌরসভা/সিটি করপোরেশন': 'union',
        'ওয়ার্ড নং': 'ward',
        'ডাকঘর': 'post_office',
        'গ্রাম': 'village',
        'পিতার এনআইডি নং (যদি থাকে)': 'father_nid',
        'মাতার এনআইডি নং (যদি থাকে)': 'mother_nid',
        'সাথে ভোটার হওয়া একজনের এনআইডি': 'voter_nid'
    };
    
    const formData = {};
    
    lines.forEach(line => {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
            const label = line.substring(0, colonIndex).trim();
            const value = line.substring(colonIndex + 1).trim();
            
            for (const [bengaliLabel, fieldName] of Object.entries(fieldMap)) {
                if (label === bengaliLabel || label === bengaliLabel.replace(' (যদি থাকে)', '')) {
                    if (value && value !== '') {
                        formData[fieldName] = value;
                    }
                    break;
                }
            }
        }
    });
    
    return formData;
}

function updateHiddenInputs(formData) {
    const form = document.querySelector('#form5 form');
    form.querySelectorAll('input[name^="form_data["]').forEach(el => el.remove());
    
    for (const [key, value] of Object.entries(formData)) {
        if (value && value.trim() !== '') {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = `form_data[${key}]`;
            input.value = value.trim();
            form.appendChild(input);
        }
    }
}

function syncInput(textarea) {
    const formData = parseFormData(textarea.value);
    updateHiddenInputs(formData);
}
</script>

        <!-- Form 6: ম্যাচ ফাউন্ড /ডাবল ভোটার -->
        <div id="form6" class="form-container">
            <div class="modal-header">
                <h5 class="modal-title">ম্যাচ ফাউন্ড /ডাবল ভোটার অ্যাকটিভ কপি</h5>
                <button type="button" class="close-modal" onclick="hideForm()">&times;</button>
            </div>
            <form action="<?php echo e(route('user.sign.copy.order.store')); ?>" method="POST" class="needs-validation" id="form6Form" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="form_type" value="6">
                
                <div class="form-group mb-3">
                    <textarea 
                        class="form-control" 
                        id="form6_info" 
                        name="form_info"
                        rows="16" 
                        required
                        style="font-family: 'SolaimanLipi', Arial, sans-serif; line-height: 1.8;"
                        oninput="syncInput6(this)"
                        onkeydown="handleEnterKey6(event, this)"
                        >নিজ নাম: 
পিতার নাম: 
মাতার নাম: 
স্বামী/স্ত্রী নাম: 
জন্ম সনদ (যদি থাকে): 
বিভাগ: 
জেলা: 
উপজেলা: 
ইউনিয়ন/পৌরসভা/সিটি করপোরেশন: 
ওয়ার্ড নং: 
ডাকঘর: 
গ্রাম: 
পিতার এনআইডি নং (যদি থাকে): 
মাতার এনআইডি নং (যদি থাকে): 
সাথে ভোটার হওয়া একজনের এনআইডি: </textarea>
                </div>
                
                <div class="form-group mb-3">
                    <label class="form-label">ব্যক্তির ছবি (যদি থাকে)</label>
                    <div class="file-upload">
                        <input type="file" class="form-control" name="form_data[photo]" accept="image/*">
                    </div>
                </div>

                <div class="text-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="hideForm()">বাতিল</button>
                    <button type="submit" class="btn btn-success">জমা দিন</button>
                </div>
            </form>
        </div>

<script>
const templateLines6 = [
    'নিজ নাম: ',
    'পিতার নাম: ',
    'মাতার নাম: ',
    'স্বামী/স্ত্রী নাম: ',
    'জন্ম সনদ (যদি থাকে): ',
    'বিভাগ: ',
    'জেলা: ',
    'উপজেলা: ',
    'ইউনিয়ন/পৌরসভা/সিটি করপোরেশন: ',
    'ওয়ার্ড নং: ',
    'ডাকঘর: ',
    'গ্রাম: ',
    'পিতার এনআইডি নং (যদি থাকে): ',
    'মাতার এনআইডি নং (যদি থাকে): ',
    'সাথে ভোটার হওয়া একজনের এনআইডি: '
];

function handleEnterKey6(event, textarea) {
    if (event.key === 'Enter') {
        event.preventDefault();
        
        const cursorPos = textarea.selectionStart;
        const text = textarea.value;
        const lines = text.split('\n');
        
        // Find current line number
        let currentLineNum = 0;
        let charCount = 0;
        
        for (let i = 0; i < lines.length; i++) {
            if (charCount + lines[i].length >= cursorPos) {
                currentLineNum = i;
                break;
            }
            charCount += lines[i].length + 1;
        }
        
        // If not on last line, move to next line
        if (currentLineNum < lines.length - 1) {
            // Calculate position at start of next line (after the label)
            let nextLinePos = charCount + lines[currentLineNum].length + 1;
            
            // Move past the label on next line
            if (currentLineNum + 1 < templateLines6.length) {
                nextLinePos += templateLines6[currentLineNum + 1].length;
            }
            
            textarea.selectionStart = textarea.selectionEnd = nextLinePos;
        }
    }
}

function parseFormData6(text) {
    const lines = text.split('\n');
    const fieldMap = {
        'নিজ নাম': 'name',
        'পিতার নাম': 'father_name',
        'মাতার নাম': 'mother_name',
        'স্বামী/স্ত্রী নাম': 'spouse_name',
        'জন্ম সনদ (যদি থাকে)': 'birth_cert',
        'বিভাগ': 'division',
        'জেলা': 'district',
        'উপজেলা': 'upazila',
        'ইউনিয়ন/পৌরসভা/সিটি করপোরেশন': 'union',
        'ওয়ার্ড নং': 'ward',
        'ডাকঘর': 'post_office',
        'গ্রাম': 'village',
        'পিতার এনআইডি নং (যদি থাকে)': 'father_nid',
        'মাতার এনআইডি নং (যদি থাকে)': 'mother_nid',
        'সাথে ভোটার হওয়া একজনের এনআইডি': 'voter_nid'
    };
    
    const formData = {};
    
    lines.forEach(line => {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
            const label = line.substring(0, colonIndex).trim();
            const value = line.substring(colonIndex + 1).trim();
            
            for (const [bengaliLabel, fieldName] of Object.entries(fieldMap)) {
                if (label === bengaliLabel || label === bengaliLabel.replace(' (যদি থাকে)', '')) {
                    if (value && value !== '') {
                        formData[fieldName] = value;
                    }
                    break;
                }
            }
        }
    });
    
    return formData;
}

function updateHiddenInputs6(formData) {
    const form = document.querySelector('#form6Form');
    
    // Remove existing hidden inputs but keep file input
    form.querySelectorAll('input[name^="form_data["]').forEach(el => {
        if (el.type !== 'file') {
            el.remove();
        }
    });
    
    // Add new hidden inputs
    for (const [key, value] of Object.entries(formData)) {
        if (value && value.trim() !== '') {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = `form_data[${key}]`;
            input.value = value.trim();
            form.appendChild(input);
        }
    }
}

function syncInput6(textarea) {
    const formData = parseFormData6(textarea.value);
    updateHiddenInputs6(formData);
}

// Add form submission handler for Form 6
document.addEventListener('DOMContentLoaded', function() {
    const form6 = document.getElementById('form6Form');
    if (form6) {
        form6.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = parseFormData6(document.getElementById('form6_info').value);
            
            if (Object.keys(formData).length === 0) {
                alert('অনুগ্রহ করে কমপক্ষে একটি তথ্য পূরণ করুন');
                return;
            }
            
            this.submit();
        });
    }
});
</script>

        <!-- Orders Table -->
                    <div class="mt-4">
                        <div class="mb-3" style="background: linear-gradient(90deg, #1e4c78 0%, #3498db 100%); color: white; padding: 10px 15px; border-radius: 4px;">
                            <h5 class="m-0 text-center">অর্ডার তালিকা</h5>
                        </div>
                        <?php if(isset($orders)): ?>
                            <div class="alert alert-info">
                                সর্বমোট অর্ডার: <?php echo e($orders->count()); ?> টি
                            </div>
                        <?php endif; ?>

                        <!-- Desktop View -->
                        <div class="classic-table d-none d-md-block">
                            <table class="table table-bordered table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ক্রমিক</th>
                                        <th>অর্ডার ধরন</th>
                                        <th>এনআইডি/ফরম নং</th>
                                        <th>নাম</th>
                                        <th>তারিখ</th>
                                        <th>স্ট্যাটাস</th>
                                        <th>ডাউনলোড</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $orders ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(($orders ? $orders->count() : 0) - $key); ?></td>
                                        <td>
                                            <?php switch($order->form_type):
                                                case (1): ?>
                                                    ১০/১২/১৭ দিয়ে সাইন
                                                    <?php break; ?>
                                                <?php case (2): ?>
                                                    ফরম/নিবন্ধন নং দিয়ে সাইন
                                                    <?php break; ?>
                                                <?php case (3): ?>
                                                    অফিসিয়াল সারভার কপি
                                                    <?php break; ?>
                                                <?php case (4): ?>
                                                    NID CMS COPY
                                                    <?php break; ?>
                                                <?php case (5): ?>
                                                    নাম ঠিকানা দিয়ে সাইন
                                                    <?php break; ?>
                                                <?php case (6): ?>
                                                    ম্যাচ ফাউন্ড কপি
                                                    <?php break; ?>
                                            <?php endswitch; ?>
                                        </td>
                                        <td>
                                            <?php
                                                try {
                                                    $formData = is_array($order->form_data) ? $order->form_data : json_decode($order->form_data, true);
                                                    echo $formData['nid'] ?? 'N/A';
                                                } catch (\Exception $e) {
                                                    echo 'N/A';
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                                try {
                                                    $formData = is_array($order->form_data) ? $order->form_data : json_decode($order->form_data, true);
                                                    echo $formData['name'] ?? 'N/A';
                                                } catch (\Exception $e) {
                                                    echo 'N/A';
                                                }
                                            ?>
                                        </td>
                                        <td><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                                        <td>
                                            <?php if($order->status == 0): ?>
                                                <span class="badge bg-warning">পেন্ডিং</span>
                                            <?php elseif($order->status == 1): ?>
                                                <span class="badge bg-info">অনুমোদিত</span>
                                            <?php elseif($order->status == 2): ?>
                                                <span class="badge bg-danger">বাতিল</span>
                                            <?php elseif($order->status == 3): ?>
                                                <span class="badge bg-success">সম্পন্ন</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">অজানা</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($order->status == 2): ?>
                                                <!-- Order Rejected - Show Reason -->
                                                <div class="alert alert-danger mb-0 py-1 px-2" style="font-size: 0.85rem;">
                                                    <strong>বাতিলের কারণ:</strong><br>
                                                    <?php echo e($order->status_note ?? 'কোন কারণ উল্লেখ করা হয়নি'); ?>

                                                </div>
                                            <?php elseif($order->admin_note): ?>
                                                <a href="<?php echo e(route('pdf.download', $order->admin_note)); ?>" class="btn btn-sm" style="background-color: #27ae60; color: white; border: none; padding: 8px 15px; border-radius: 4px;" title="ডাউনলোড করুন">
                                                    <i class="fas fa-download"></i> ডাউনলোড
                                                </a>
                                            <?php else: ?>
                                <span class="badge bg-secondary" style="font-size: 0.75rem;">নেই</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">কোন অর্ডার নেই</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Mobile View -->
                        <div class="d-md-none">
                            <?php $__empty_1 = true; $__currentLoopData = $orders ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="mobile-order-row">
                                <div class="row-number"><?php echo e(($orders ? $orders->count() : 0) - $key); ?></div>
                                <div class="row-content">
                                    <div class="info-line">
                                        <span class="service-type">
                                            <?php switch($order->form_type):
                                                case (1): ?>
                                                    ১০/১২/১৭ দিয়ে সাইন
                                                    <?php break; ?>
                                                <?php case (2): ?>
                                                    ফরম/নিবন্ধন নং দিয়ে সাইন
                                                    <?php break; ?>
                                                <?php case (3): ?>
                                                    অফিসিয়াল সারভার কপি
                                                    <?php break; ?>
                                                <?php case (4): ?>
                                                    NID CMS COPY
                                                    <?php break; ?>
                                                <?php case (5): ?>
                                                    নাম ঠিকানা দিয়ে সাইন
                                                    <?php break; ?>
                                                <?php case (6): ?>
                                                    ম্যাচ ফাউন্ড কপি
                                                    <?php break; ?>
                                            <?php endswitch; ?>
                                        </span>
                                    </div>
                                    <div class="info-line">
                                        <?php
                                            try {
                                                $formData = is_array($order->form_data) ? $order->form_data : json_decode($order->form_data, true);
                                                $nid = $formData['nid'] ?? null;
                                                $name = $formData['name'] ?? null;
                                            } catch (\Exception $e) {
                                                $nid = null;
                                                $name = null;
                                            }
                                        ?>
                                        <?php if($nid): ?>
                                            <span class="text-primary"><?php echo e($nid); ?></span>
                                            <?php if($name): ?>
                                                <span class="text-muted mx-1">|</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if($name): ?>
                                            <span><?php echo e($name); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="info-line">
                                        <?php if($order->status == 0): ?>
                                            <span class="badge bg-warning">পেন্ডিং</span>
                                        <?php elseif($order->status == 1): ?>
                                            <span class="badge bg-info">অনুমোদিত</span>
                                        <?php elseif($order->status == 2): ?>
                                            <span class="badge bg-danger">বাতিল</span>
                                        <?php elseif($order->status == 3): ?>
                                            <span class="badge bg-success">সম্পন্ন</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">অজানা</span>
                                        <?php endif; ?>
                                        <span class="text-muted"><?php echo e($order->created_at->format('d/m/Y')); ?></span>
                                        <?php if($order->status == 2): ?>
                                            <!-- Show rejection reason for mobile -->
                                            <div class="alert alert-danger mb-0 mt-2 py-1 px-2" style="font-size: 0.8rem; width: 100%;">
                                                <strong style="font-size: 0.75rem;">বাতিলের কারণ:</strong><br>
                                                <span style="font-size: 0.75rem;"><?php echo e($order->status_note ?? 'কোন কারণ উল্লেখ করা হয়নি'); ?></span>
                                            </div>
                                        <?php elseif($order->admin_note): ?>
                                            <a href="<?php echo e(route('pdf.download', $order->admin_note)); ?>" class="btn btn-sm" style="background-color: #27ae60; color: white; border: none; padding: 6px 12px; border-radius: 4px; font-size: 0.75rem;">
                                                <i class="fas fa-download"></i> ডাউনলোড
                                                 </a>
                                        <?php else: ?>
                                <span class="badge bg-secondary" style="font-size: 0.75rem;">নেই</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center p-3 text-muted">
                                <i class="fas fa-inbox fa-2x mb-2"></i>
                                <p>কোন অর্ডার নেই</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
    </div>
</div>

<?php $__env->startPush('js'); ?>
<script>
// Form 1 JavaScript
const templateLines1 = [
    'নাম: ',
    'এনআইডি নম্বর: ',
    'ঠিকানা: ',
    'মোবাইল নম্বর: '
];

function handleEnterKey1(event, textarea) {
    if (event.key === 'Enter') {
        event.preventDefault();
        
        const cursorPos = textarea.selectionStart;
        const text = textarea.value;
        const lines = text.split('\n');
        
        let currentLineNum = 0;
        let charCount = 0;
        
        for (let i = 0; i < lines.length; i++) {
            if (charCount + lines[i].length >= cursorPos) {
                currentLineNum = i;
                break;
            }
            charCount += lines[i].length + 1;
        }
        
        if (currentLineNum < lines.length - 1) {
            let nextLinePos = charCount + lines[currentLineNum].length + 1;
            if (currentLineNum + 1 < templateLines1.length) {
                nextLinePos += templateLines1[currentLineNum + 1].length;
            }
            textarea.selectionStart = textarea.selectionEnd = nextLinePos;
        }
    }
}

function parseFormData1(text) {
    const lines = text.split('\n');
    const fieldMap = {
        'নাম': 'name',
        'এনআইডি নম্বর': 'nid',
        'ঠিকানা': 'address',
        'মোবাইল নম্বর': 'mobile'
    };
    
    const formData = {};
    
    lines.forEach(line => {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
            const label = line.substring(0, colonIndex).trim();
            const value = line.substring(colonIndex + 1).trim();
            
            if (fieldMap[label] && value !== '') {
                formData[fieldMap[label]] = value;
            }
        }
    });
    
    return formData;
}

function syncInput1(textarea) {
    const formData = parseFormData1(textarea.value);
    updateHiddenInputs1(formData);
}

function updateHiddenInputs1(formData) {
    const form = document.querySelector('#form1Form');
    // Remove existing hidden inputs
    form.querySelectorAll('input[name^="form_data["]').forEach(el => el.remove());
    
    // Add new hidden inputs
    for (const [key, value] of Object.entries(formData)) {
        if (value && value.trim() !== '') {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = `form_data[${key}]`;
            input.value = value.trim();
            form.appendChild(input);
        }
    }
}

// Form 2 JavaScript
const templateLines2 = [
    'নাম: ',
    'নিবন্ধন নম্বর: ',
    'জেলা: ',
    'উপজেলা: ',
    'মোবাইল নম্বর: '
];

function handleEnterKey2(event, textarea) {
    if (event.key === 'Enter') {
        event.preventDefault();
        
        const cursorPos = textarea.selectionStart;
        const text = textarea.value;
        const lines = text.split('\n');
        
        let currentLineNum = 0;
        let charCount = 0;
        
        for (let i = 0; i < lines.length; i++) {
            if (charCount + lines[i].length >= cursorPos) {
                currentLineNum = i;
                break;
            }
            charCount += lines[i].length + 1;
        }
        
        if (currentLineNum < lines.length - 1) {
            let nextLinePos = charCount + lines[currentLineNum].length + 1;
            if (currentLineNum + 1 < templateLines2.length) {
                nextLinePos += templateLines2[currentLineNum + 1].length;
            }
            textarea.selectionStart = textarea.selectionEnd = nextLinePos;
        }
    }
}

function parseFormData2(text) {
    const lines = text.split('\n');
    const fieldMap = {
        'নাম': 'name',
        'নিবন্ধন নম্বর': 'registration_no',
        'জেলা': 'district',
        'উপজেলা': 'upazila',
        'মোবাইল নম্বর': 'mobile'
    };
    
    const formData = {};
    
    lines.forEach(line => {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
            const label = line.substring(0, colonIndex).trim();
            const value = line.substring(colonIndex + 1).trim();
            
            if (fieldMap[label] && value !== '') {
                formData[fieldMap[label]] = value;
            }
        }
    });
    
    return formData;
}

function syncInput2(textarea) {
    const formData = parseFormData2(textarea.value);
    updateHiddenInputs2(formData);
}

function updateHiddenInputs2(formData) {
    const form = document.querySelector('#form2Form');
    form.querySelectorAll('input[name^="form_data["]').forEach(el => el.remove());
    
    for (const [key, value] of Object.entries(formData)) {
        if (value && value.trim() !== '') {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = `form_data[${key}]`;
            input.value = value.trim();
            form.appendChild(input);
        }
    }
}

// Form 3 JavaScript
const templateLines3 = [
    'এনআইডি নম্বর: ',
    'জন্ম তারিখ: ',
    'জেলা: ',
    'উপজেলা: ',
    'মোবাইল নম্বর: '
];

function handleEnterKey3(event, textarea) {
    if (event.key === 'Enter') {
        event.preventDefault();
        
        const cursorPos = textarea.selectionStart;
        const text = textarea.value;
        const lines = text.split('\n');
        
        let currentLineNum = 0;
        let charCount = 0;
        
        for (let i = 0; i < lines.length; i++) {
            if (charCount + lines[i].length >= cursorPos) {
                currentLineNum = i;
                break;
            }
            charCount += lines[i].length + 1;
        }
        
        if (currentLineNum < lines.length - 1) {
            let nextLinePos = charCount + lines[currentLineNum].length + 1;
            if (currentLineNum + 1 < templateLines3.length) {
                nextLinePos += templateLines3[currentLineNum + 1].length;
            }
            textarea.selectionStart = textarea.selectionEnd = nextLinePos;
        }
    }
}

function parseFormData3(text) {
    const lines = text.split('\n');
    const fieldMap = {
        'এনআইডি নম্বর': 'nid',
        'জন্ম তারিখ': 'dob',
        'জেলা': 'district',
        'উপজেলা': 'upazila',
        'মোবাইল নম্বর': 'mobile'
    };
    
    const formData = {};
    
    lines.forEach(line => {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
            const label = line.substring(0, colonIndex).trim();
            const value = line.substring(colonIndex + 1).trim();
            
            if (fieldMap[label] && value !== '') {
                formData[fieldMap[label]] = value;
            }
        }
    });
    
    return formData;
}

function syncInput3(textarea) {
    const formData = parseFormData3(textarea.value);
    updateHiddenInputs3(formData);
}

function updateHiddenInputs3(formData) {
    const form = document.querySelector('#form3Form');
    form.querySelectorAll('input[name^="form_data["]').forEach(el => el.remove());
    
    for (const [key, value] of Object.entries(formData)) {
        if (value && value.trim() !== '') {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = `form_data[${key}]`;
            input.value = value.trim();
            form.appendChild(input);
        }
    }
}

// Form 4 JavaScript
const templateLines4 = [
    'এনআইডি নম্বর: ',
    'জন্ম তারিখ: ',
    'জেলা: ',
    'উপজেলা: ',
    'ইউনিয়ন/পৌরসভা: ',
    'মোবাইল নম্বর: '
];

function handleEnterKey4(event, textarea) {
    if (event.key === 'Enter') {
        event.preventDefault();
        
        const cursorPos = textarea.selectionStart;
        const text = textarea.value;
        const lines = text.split('\n');
        
        let currentLineNum = 0;
        let charCount = 0;
        
        for (let i = 0; i < lines.length; i++) {
            if (charCount + lines[i].length >= cursorPos) {
                currentLineNum = i;
                break;
            }
            charCount += lines[i].length + 1;
        }
        
        if (currentLineNum < lines.length - 1) {
            let nextLinePos = charCount + lines[currentLineNum].length + 1;
            if (currentLineNum + 1 < templateLines4.length) {
                nextLinePos += templateLines4[currentLineNum + 1].length;
            }
            textarea.selectionStart = textarea.selectionEnd = nextLinePos;
        }
    }
}

function parseFormData4(text) {
    const lines = text.split('\n');
    const fieldMap = {
        'এনআইডি নম্বর': 'nid',
        'জন্ম তারিখ': 'dob',
        'জেলা': 'district',
        'উপজেলা': 'upazila',
        'ইউনিয়ন/পৌরসভা': 'union',
        'মোবাইল নম্বর': 'mobile'
    };
    
    const formData = {};
    
    lines.forEach(line => {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
            const label = line.substring(0, colonIndex).trim();
            const value = line.substring(colonIndex + 1).trim();
            
            if (fieldMap[label] && value !== '') {
                formData[fieldMap[label]] = value;
            }
        }
    });
    
    return formData;
}

function syncInput4(textarea) {
    const formData = parseFormData4(textarea.value);
    updateHiddenInputs4(formData);
}

function updateHiddenInputs4(formData) {
    const form = document.querySelector('#form4Form');
    form.querySelectorAll('input[name^="form_data["]').forEach(el => el.remove());
    
    for (const [key, value] of Object.entries(formData)) {
        if (value && value.trim() !== '') {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = `form_data[${key}]`;
            input.value = value.trim();
            form.appendChild(input);
        }
    }
}

// Add form submission handlers
document.addEventListener('DOMContentLoaded', function() {
    [1, 2, 3, 4].forEach(formNumber => {
        const form = document.getElementById(`form${formNumber}Form`);
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                const textarea = document.getElementById(`form${formNumber}_info`);
                const formData = window[`parseFormData${formNumber}`](textarea.value);
                
                if (Object.keys(formData).length === 0) {
                    alert('অনুগ্রহ করে কমপক্ষে একটি তথ্য পূরণ করুন');
                    return;
                }
                
                // Create and add hidden inputs for form_data
                for (const [key, value] of Object.entries(formData)) {
                    if (value && value.trim() !== '') {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = `form_data[${key}]`;
                        input.value = value.trim();
                        this.appendChild(input);
                    }
                }
                
                this.submit();
            });
        }
    });
});

// Field mapping for form data
const fieldMap = {
    'নিজ নাম': 'name',
    'পিতার নাম': 'father_name',
    'মাতার নাম': 'mother_name',
    'স্বামী/স্ত্রী নাম': 'spouse_name',
    'জন্ম সনদ (যদি থাকে)': 'birth_cert',
    'বিভাগ': 'division',
    'জেলা': 'district',
    'উপজেলা': 'upazila',
    'ইউনিয়ন/পৌরসভা/সিটি করপোরেশন': 'union',
    'ওয়ার্ড নং': 'ward',
    'ডাকঘর': 'post_office',
    'গ্রাম': 'village',
    'পিতার এনআইডি নং (যদি থাকে)': 'father_nid',
    'মাতার এনআইডি নং (যদি থাকে)': 'mother_nid',
    'সাথে ভোটার হওয়া একজনের এনআইডি': 'voter_nid'
};

// Function to parse form data
function parseFormData(text) {
    const lines = text.split('\n');
    const formData = {};
    
    lines.forEach(line => {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
            const label = line.substring(0, colonIndex).trim();
            const value = line.substring(colonIndex + 1).trim();
            
            // Find the corresponding field name
            for (const [bengaliLabel, fieldName] of Object.entries(fieldMap)) {
                if (label === bengaliLabel && value && value !== '') {
                    formData[fieldName] = value;
                    break;
                }
            }
        }
    });
    
    return formData;
}

// Handle keydown events
function handleKeyDown(event, textarea) {
    if (event.key === 'Enter') {
        event.preventDefault();
        const cursorPos = textarea.selectionStart;
        const currentValue = textarea.value;
        const textBeforeCursor = currentValue.substring(0, cursorPos);
        const textAfterCursor = currentValue.substring(cursorPos);
        textarea.value = textBeforeCursor + '\n' + textAfterCursor;
        textarea.selectionStart = textarea.selectionEnd = cursorPos + 1;
    }
}

// Function to update hidden inputs
function updateHiddenInputs(formData) {
    // Remove existing hidden inputs
    document.querySelectorAll('input[name^="form_data["]').forEach(el => el.remove());
    
    // Create new hidden inputs
    const form = document.querySelector('#form5Form');
    if (!form) return;
    
    Object.entries(formData).forEach(([key, value]) => {
        if (value && value.trim() !== '') {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = `form_data[${key}]`;
            input.value = value.trim();
            form.appendChild(input);
        }
    });
}

// Function to sync input
function syncInput(textarea) {
    const template = Object.keys(fieldMap).join(':\n') + ':';
    const lines = textarea.value.split('\n');
    const templateLines = template.split('\n');
    
    // Process each line
    const processedLines = lines.map((line, index) => {
        if (index >= templateLines.length) return line;
        
        const templateLine = templateLines[index];
        const colonIndex = templateLine.indexOf(':');
        
        if (colonIndex === -1) return line;
        
        const label = templateLine.substring(0, colonIndex + 1);
        const userInput = line.substring(line.indexOf(':') + 1).trim();
        
        return `${label} ${userInput}`;
    });
    
    // Ensure all template lines exist
    while (processedLines.length < templateLines.length) {
        processedLines.push(templateLines[processedLines.length]);
    }
    
    textarea.value = processedLines.join('\n');
    
    // Parse and update hidden inputs
    const formData = parseFormData(textarea.value);
    updateHiddenInputs(formData);
}

document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('.form-container');
    
    // Add form submission handler for Form 5
    const form5 = document.getElementById('form5Form');
    if (form5) {
        form5.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = parseFormData(document.getElementById('form5_info').value);
            
            if (Object.keys(formData).length === 0) {
                alert('অনুগ্রহ করে কমপক্ষে একটি তথ্য পূরণ করুন');
                return;
            }
            
            // Add hidden inputs for form data
            Object.entries(formData).forEach(([key, value]) => {
                let input = document.createElement('input');
                input.type = 'hidden';
                input.name = `form_data[${key}]`;
                input.value = value;
                this.appendChild(input);
            });
            
            this.submit();
        });
    }
    
    function showForm(formId) {
        hideForm();
        const form = document.getElementById('form' + formId);
        if (form) {
            form.style.display = 'block';
            setTimeout(() => form.classList.add('active'), 10);
        }
        
        document.querySelectorAll('.btn-option').forEach(btn => {
            btn.classList.remove('active');
        });
        const activeBtn = document.querySelector(`[data-form="${formId}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }
    }
    
    function hideForm() {
        forms.forEach(form => {
            form.style.display = 'none';
            form.classList.remove('active');
        });
        
        document.querySelectorAll('.btn-option').forEach(btn => {
            btn.classList.remove('active');
        });
    }
    
    document.querySelectorAll('.btn-option').forEach(button => {
        button.onclick = function() {
            const formId = this.getAttribute('data-form');
            showForm(formId);
        };
    });

    window.showForm = showForm;
    window.hideForm = hideForm;
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project files\ifixfast24\resources\views/user/sign_copy_order/index.blade.php ENDPATH**/ ?>