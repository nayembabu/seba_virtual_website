
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("Application List"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .fa-ellipsis-v:before {
            content: "\f142";
        }
    </style>
    
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            
            
            
              
               <br/>
          
                <table class="categories-show-table table table-hover table-striped table-bordered">
                    <thead class="thead-dark">
                    <tr>
                       
                        <th scope="col"><?php echo app('translator')->get('No.'); ?></th>
                         <th scope="col"><?php echo app('translator')->get('ID No'); ?></th>
                          <th scope="col"><?php echo app('translator')->get('name'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Type'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('User'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                        <th scope="col" style="text-align:center"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            
                            <td data-label="<?php echo app('translator')->get('No.'); ?>">
                                <?php echo e($key + 1); ?>

                                </td>
                           <td data-label="<?php echo app('translator')->get('ID No'); ?>">
                                <?php echo e($application->nid); ?>

                                
                            </td>
                            <td data-label="<?php echo app('translator')->get('name'); ?>">
                                <?php echo e($application->name); ?>

                                
                            </td>
                            <td data-label="<?php echo app('translator')->get('Type'); ?>">
                                <?php echo e($application->type); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('user'); ?>">
                                <?php echo e(@$application->user->name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                
                                <?php if( $application->status == '0' ): ?>
                                <b style="color:red">Pending</b>
                                <?php endif; ?>
                                
                                <?php if( $application->status == '2' ): ?>
                                <b style="color:purple">Accepted</b>
                                <?php endif; ?>
                                
                                <?php if( $application->status == '4' ): ?>
                                <b style="color:blue">Waiting for Confirmation</b>
                                <?php endif; ?>
                                
                                <?php if( $application->status == '5' ): ?>
                                <b style="color:green">Confirmed</b>
                                <?php endif; ?>
                                
                                
                                <?php if( $application->status == '1' ): ?>
                                <b style="color:green">Delivered</b><br/>
                                 <a class="btn btn-info btn-sm" target="_blank" href="<?php echo e(url('storage/uploads/'.$application->file)); ?>">View File</a>
                                 <a href="javascript:void(0);" class="btn btn-warning btn-sm change" data-id="<?php echo e($application->id); ?>">Change File</a>
                                <?php endif; ?>
                              
                                
                            </td>
                           
                          <td data-label="<?php echo app('translator')->get('Date'); ?>">
                                <?php echo e(date('d F Y',strtotime(@$application->created_at))); ?>

                            </td>
                            
                            <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-lg-center text-right">
                                <?php if( $application->status == '2' && $application->type !== 'Advanced'): ?>
                                        
                                         <a data-id="<?php echo e($application->id); ?>" href="javascript:void(0);" class="deliver btn btn-success"> <i class="fas fa-check"></i> Upload File & Deliver </a>
                                         
                                         <a data-id="<?php echo e($application->id); ?>" href="javascript:void(0);" class="cancel btn btn-danger"> <i class="fas fa-times"></i> Cancel </a>
                               
                                 <?php endif; ?>
                                 
                                 <?php if( $application->type == 'Advanced' ): ?>
                                 
                                 
                                 <?php if( $application->status == '2'  ): ?>
                                  <a data-id="<?php echo e($application->id); ?>" href="javascript:void(0);" class="photo btn btn-success"> <i class="fas fa-photos"></i> Upload Photo </a>
                                   <a data-id="<?php echo e($application->id); ?>" href="javascript:void(0);" class="cancel btn btn-danger"> <i class="fas fa-times"></i> Cancel </a>
                                 <?php endif; ?>
                                 
                                  <?php if( $application->status == '5'  ): ?>
                                         <a data-id="<?php echo e($application->id); ?>" href="javascript:void(0);" class="deliver btn btn-success"> <i class="fas fa-check"></i> Upload File & Deliver </a>
                                          <a data-id="<?php echo e($application->id); ?>" href="javascript:void(0);" class="cancel btn btn-danger"> <i class="fas fa-times"></i> Cancel </a>
                                 <?php endif; ?>
                                 
                                 
                                <a data-info='<?php echo $application->extra; ?>' href='javascript:void(0);' class='view-info btn btn-info'> <i class="fas fa-eye"></i> View Info </a>
                                 <?php endif; ?>
                                 
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-danger" colspan="9"><?php echo app('translator')->get('No Data'); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($applications->appends(@$_GET)->links('partials.pagination')); ?>

            </div>
        </div>
    </div>
    
    
    
    <div class="modal fade" id="status-ch" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header modal-colored-header bg-primary">
                    <h5 class="modal-title"><?php echo app('translator')->get('Deliver Appliccation'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(route('mod.deliver-application')); ?>" enctype="multipart/form-data">
                        <input name="id" value="" type="hidden" id="uid" />
                        <label>File</label>
                        <input class="form-control" type="file" name="file" required /><br/>
                        <button class="btn btn-success">Deliver</button>
                        <?php echo csrf_field(); ?>
                    </form>
                   
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="modal fade" id="status-change" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header modal-colored-header bg-primary">
                    <h5 class="modal-title"><?php echo app('translator')->get('Change Application File'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(route('mod.redeliver-application')); ?>" enctype="multipart/form-data">
                        <input name="id" value="" type="hidden" id="uidc" />
                        <label>File</label>
                        <input class="form-control" type="file" name="file" required /><br/>
                        <button class="btn btn-success">Change</button>
                        <?php echo csrf_field(); ?>
                    </form>
                   
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="modal fade" id="cancel" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header modal-colored-header bg-primary">
                    <h5 class="modal-title"><?php echo app('translator')->get('Cancel Application'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(route('mod.cancel-application')); ?>" enctype="multipart/form-data">
                    <input name="id" value="" type="hidden" id="cid" />
                    <label for="cancel_reason">Cancel Reason</label>
                    <select class="form-control" name="cancel_reason" id="cancel_reason" required>
                        <option value="">Select a reason</option>
                        <option value="Not ready">Not ready</option>
                        <option value="Match Found">Match Found</option>
                        <option value="Doubble Voter">Doubble Voter</option>
                        <option value="Lock">Lock</option>
                        <option value="No Data">No Data</option>
                        <option value="নামের সাথে মিল নাই">নামের সাথে মিল নাই</option>
                        <option value="ইউজার পাস ভুল"> ইউজার পাস ভুল</option>
                        <option value="আজকের সময় শেষ দয়া করে কাল আবার দেন ">আজকের সময় শেষ দয়া করে কাল আবার দেন ">No </option>
                    </select>
                    <button class="btn btn-danger">Cancel</button>
                    <?php echo csrf_field(); ?>
                </form>
                   
                </div>
            </div>
        </div>
    </div>
    
    
   
    
     

    

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script>
        
         $(document).on('click', '.deliver', function () {
            var id = $(this).attr('data-id');
            $('#uid').val(id);
            $('#status-ch').modal('show');
        });
        
         $(document).on('click', '.photo', function () {
            var id = $(this).attr('data-id');
            $('#fid').val(id);
            $('#photo-m').modal('show');
        });
        
         $(document).on('click', '.change', function () {
            var id = $(this).attr('data-id');
            $('#uidc').val(id);
            $('#status-change').modal('show');
        });
        
        $(document).on('click', '.cancel', function () {
            var id = $(this).attr('data-id');
            $('#cid').val(id);
            $('#cancel').modal('show');
        });
        
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('mod.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/mod/my-applications.blade.php ENDPATH**/ ?>