<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>TIN Orders Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            z-index: 1000;
            overflow-y: auto;
            transition: all 0.3s;
        }
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
            padding: 20px;
            transition: all 0.3s;
        }
        .page-header {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .badge-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-processing {
            background: #e7d4f5;
            color: #5a21b5;
        }
        .badge-completed {
            background: #d1ecf1;
            color: #0c5460;
        }
        .badge-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .table thead {
            background: #f8f9fa;
        }
        .table thead th {
            border: none;
            color: #667eea;
            font-weight: 600;
            padding: 15px;
            font-size: 13px;
            text-transform: uppercase;
        }
        .table tbody td {
            border: none;
            padding: 15px;
            vertical-align: middle;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }
        .table tbody tr:hover {
            background: #f9f9f9;
        }
        .expand-icon {
            cursor: pointer;
            transition: transform 0.3s;
            color: #667eea;
        }
        
        /* Mobile Sidebar Toggle Button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transition: all 0.3s;
        }
        .sidebar-toggle:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        .sidebar-toggle i {
            font-size: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar-toggle {
                display: block;
            }
            .sidebar {
                width: 0;
                padding: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 10px;
                padding-top: 70px;
            }
        }
    </style>
</head>
<body>
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Mobile Menu Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Page Header -->
        <div class="page-header mb-4">
            <div class="d-flex align-items-center gap-3 mb-3">
                <div style="font-size: 28px; color: #667eea;">
                    <i class="fas fa-file-invoice"></i>
                </div>
                <div>
                    <h2 class="mb-1" style="color: #333;">টিন অর্ডার ম্যানেজমেন্ট</h2>
                    <p class="text-muted mb-0" style="font-size: 13px;">সকল টিন সার্ভিস অর্ডারের তালিকা এবং পরিচালনা</p>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h3 id="stat-total">0</h3>
                        <p class="mb-0">Total Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h3 id="stat-pending">0</h3>
                        <p class="mb-0">Pending</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h3 id="stat-processing">0</h3>
                        <p class="mb-0">Processing</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h3 id="stat-completed">0</h3>
                        <p class="mb-0">Completed</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search & Filter Bar -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="searchInput" 
                            placeholder="Search by NID, TIN, Mobile..."
                        >
                    </div>
                    <div class="col-md-2">
                        <select id="statusFilter" class="form-select">
                            <option value="">All Status</option>
                            <option value="0">Pending</option>
                            <option value="1">Processing</option>
                            <option value="2">Completed</option>
                            <option value="3">Rejected</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="typeFilter" class="form-select">
                            <option value="">All Services</option>
                            <option value="1">টিন সার্টিফিকেট অর্ডার</option>
                            <option value="2">নিউ টিন আবেদন</option>
                            <option value="3">জিরো রিটার্ন আবেদন</option>
                            <option value="4">টিন সার্টিফিকেট কারেকশন</option>
                            <option value="5">টিন আইডি পাসওয়ার্ড সেট</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-secondary w-100" onclick="resetFilters()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-success w-100" onclick="exportOrders()">
                            <i class="fas fa-download"></i> Export CSV
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orders Table -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0">সকল টিন অর্ডার</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th></th>
                                <th>Order ID</th>
                                <th>User ID</th>
                                <th>Service Type</th>
                                <th>Form Data</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>PDF Upload</th>
                                <th>নোট</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="ordersTableBody">
                            <tr>
                                <td colspan="9" class="text-center py-4 text-muted">
                                    <i class="fas fa-spinner fa-spin"></i> Loading orders...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white">
                <nav>
                    <ul class="pagination mb-0" id="pagination"></ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Rejection Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-times-circle"></i> অর্ডার বাতিল করুন
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3"><strong>বাতিল করার কারণ নির্বাচন করুন:</strong></p>
                    <div class="d-flex flex-column gap-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason1" value="তথ্য অসম্পূর্ণ বা ভুল">
                            <label class="form-check-label" for="reason1">তথ্য অসম্পূর্ণ বা ভুল</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason2" value="NID/TIN নম্বর বৈধ নয়">
                            <label class="form-check-label" for="reason2">NID/TIN নম্বর বৈধ নয়</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason3" value="ডকুমেন্ট প্রয়োজন">
                            <label class="form-check-label" for="reason3">ডকুমেন্ট প্রয়োজন</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason4" value="ব্যবহারকারীর বাতিলের অনুরোধ">
                            <label class="form-check-label" for="reason4">ব্যবহারকারীর বাতিলের অনুরোধ</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল করুন</button>
                    <button type="button" class="btn btn-danger" onclick="confirmReject()">
                        <i class="fas fa-check"></i> নিশ্চিত করুন
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentPage = 1;
        let currentRejectOrderId = null;

        document.addEventListener('DOMContentLoaded', function() {
            loadOrders();
            setupEventListeners();
        });

        function setupEventListeners() {
            document.getElementById('searchInput').addEventListener('keyup', function() {
                currentPage = 1;
                loadOrders();
            });

            document.getElementById('statusFilter').addEventListener('change', function() {
                currentPage = 1;
                loadOrders();
            });

            document.getElementById('typeFilter').addEventListener('change', function() {
                currentPage = 1;
                loadOrders();
            });
        }

        function loadOrders(page = 1) {
            currentPage = page;
            const search = document.getElementById('searchInput').value;
            const status = document.getElementById('statusFilter').value;
            const type = document.getElementById('typeFilter').value;

            const queryParams = new URLSearchParams();
            if (search) queryParams.append('search', search);
            if (status !== '') queryParams.append('status', status);
            if (type) queryParams.append('type', type);
            queryParams.append('page', page);

            fetch(`/admin/tin-orders/get-orders?${queryParams}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                renderOrders(data.orders);
                updateStats(data.stats);
                updatePagination(data.pagination);
            })
            .catch(error => {
                console.error('Error loading orders:', error);
                document.getElementById('ordersTableBody').innerHTML = 
                    '<tr><td colspan="9" class="text-center py-4 text-danger">Error loading orders.</td></tr>';
            });
        }

        function renderOrders(orders) {
            const tbody = document.getElementById('ordersTableBody');
            
            if (orders.length === 0) {
                tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted">No orders found</td></tr>';
                return;
            }

            tbody.innerHTML = orders.map(order => `
                <tr class="order-row" onclick="toggleDetails(${order.id})" style="cursor: pointer;">
                    <td>
                        <i class="fas fa-chevron-right expand-icon" id="icon-${order.id}"></i>
                    </td>
                    <td><strong>#${order.id}</strong></td>
                    <td>${order.user_id || 'N/A'}</td>
                    <td>
                        <span class="badge bg-info text-white">${order.form_type_name || getServiceName(order.type)}</span>
                    </td>
                    <td>${formatFormData(order.form_data)}</td>
                    <td>${getStatusBadge(order.status)}</td>
                    <td>${formatDate(order.created_at)}</td>
                    <td onclick="event.stopPropagation();">
                        ${getPdfButton(order)}
                    </td>
                    <td onclick="event.stopPropagation();">
                        <input type="text" class="form-control form-control-sm" id="note-${order.id}" value="${order.text || ''}" placeholder="নোট লিখুন...">
                        <button class="btn btn-sm btn-primary mt-1" onclick="saveNote(${order.id})" title="নোট সেভ করুন">
                            <i class="fas fa-save"></i> Save
                        </button>
                    </td>
                    <td onclick="event.stopPropagation();">
                        ${getActionButtons(order)}
                    </td>
                </tr>

                <!-- Details Row -->
                <tr id="details-row-${order.id}" class="details-row" style="display: none;">
                    <td colspan="10">
                        <div class="p-4" style="background: #f9f9f9; border-left: 4px solid #667eea;">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="mb-3"><i class="fas fa-info-circle"></i> Order Details</h6>
                                    <p><strong>Order ID:</strong> #${order.id}</p>
                                    <p><strong>User ID:</strong> ${order.user_id}</p>
                                    <p><strong>Service:</strong> ${order.form_type_name || getServiceName(order.type)}</p>
                                    <p><strong>Form Data:</strong></p>
                                    <div class="ms-3">${formatFormDataDetailed(order.form_data)}</div>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="mb-3"><i class="fas fa-clock"></i> Status Info</h6>
                                    <p><strong>Status:</strong> ${getStatusBadge(order.status)}</p>
                                    <p><strong>Created:</strong> ${formatDate(order.created_at)}</p>
                                    <p><strong>Updated:</strong> ${formatDate(order.updated_at)}</p>
                                </div>
                            </div>
                            <hr>
                            <button class="btn btn-sm btn-secondary" onclick="toggleDetails(${order.id})">
                                <i class="fas fa-times"></i> Close
                            </button>
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        function toggleDetails(orderId) {
            const detailsRow = document.getElementById('details-row-' + orderId);
            const icon = document.getElementById('icon-' + orderId);
            
            if (detailsRow.style.display === 'none') {
                detailsRow.style.display = 'table-row';
                icon.classList.replace('fa-chevron-right', 'fa-chevron-down');
            } else {
                detailsRow.style.display = 'none';
                icon.classList.replace('fa-chevron-down', 'fa-chevron-right');
            }
        }

        function getActionButtons(order) {
            if (order.status == 0) {
                return `
                    <button class="btn btn-sm btn-success" onclick="processOrder(${order.id}, ${order.status})" title="Approve">
                        <i class="fas fa-check"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="rejectOrder(${order.id})" title="Reject">
                        <i class="fas fa-times"></i>
                    </button>
                `;
            } else if (order.status == 1) {
                return `
                    <button class="btn btn-sm btn-primary" onclick="processOrder(${order.id}, ${order.status})" title="Complete">
                        <i class="fas fa-check-double"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="rejectOrder(${order.id})" title="Reject">
                        <i class="fas fa-times"></i>
                    </button>
                `;
            }
            return '<span class="text-muted">No actions</span>';
        }

        function getPdfButton(order) {
            // Check if PDF exists (admin_note contains the PDF path)
            if (order.admin_note && order.admin_note.includes('.pdf')) {
                return `
                    <button class="btn btn-sm btn-success" onclick="downloadPdf(${order.id})" title="Download PDF">
                        <i class="fas fa-download"></i> Download
                    </button>
                `;
            } else {
                return `
                    <input type="file" id="pdf-file-${order.id}" accept=".pdf" style="display: none;" onchange="uploadPdf(${order.id})">
                    <button class="btn btn-sm btn-primary" onclick="document.getElementById('pdf-file-${order.id}').click()" title="Upload PDF">
                        <i class="fas fa-upload"></i> Upload
                    </button>
                `;
            }
        }

        function uploadPdf(orderId) {
            const fileInput = document.getElementById('pdf-file-' + orderId);
            const file = fileInput.files[0];

            if (!file) {
                return;
            }

            // Validate file type
            if (!file.name.toLowerCase().endsWith('.pdf')) {
                alert('শুধুমাত্র PDF ফাইল আপলোড করুন');
                fileInput.value = '';
                return;
            }

            // Validate file size (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                alert('ফাইলের সাইজ ১০ MB এর বেশি হতে পারবে না');
                fileInput.value = '';
                return;
            }

            const formData = new FormData();
            formData.append('pdf', file);

            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            // Show loading state
            const uploadBtn = fileInput.nextElementSibling;
            const originalHTML = uploadBtn.innerHTML;
            uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            uploadBtn.disabled = true;

            fetch(`/admin/tin-orders/${orderId}/upload-pdf`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('PDF সফলভাবে আপলোড হয়েছে!');
                    loadOrders(currentPage); // Reload orders to show Download button
                } else {
                    alert(data.message || 'PDF আপলোড করতে সমস্যা হয়েছে');
                    uploadBtn.innerHTML = originalHTML;
                    uploadBtn.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('PDF আপলোড করতে সমস্যা হয়েছে');
                uploadBtn.innerHTML = originalHTML;
                uploadBtn.disabled = false;
            });

            // Clear file input
            fileInput.value = '';
        }

        function downloadPdf(orderId) {
            window.open(`/admin/tin-orders/${orderId}/download-pdf`, '_blank');
        }

        function saveNote(orderId) {
            const noteText = document.getElementById('note-' + orderId).value;
            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            const saveBtn = event.target;
            const originalHTML = saveBtn.innerHTML;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            saveBtn.disabled = true;

            fetch(`/admin/tin-orders/${orderId}/save-note`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ text: noteText })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('নোট সফলভাবে সেভ হয়েছে এবং অর্ডার সম্পন্ন হয়েছে!');
                    loadOrders(currentPage); // Reload orders to show updated status
                } else {
                    alert(data.message || 'নোট সেভ করতে সমস্যা হয়েছে');
                    saveBtn.innerHTML = originalHTML;
                    saveBtn.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('নোট সেভ করতে সমস্যা হয়েছে');
                saveBtn.innerHTML = originalHTML;
                saveBtn.disabled = false;
            });
        }

        function processOrder(orderId, currentStatus) {
            const newStatus = currentStatus == 0 ? 1 : 2;
            updateOrderStatus(orderId, newStatus);
        }

        function rejectOrder(orderId) {
            currentRejectOrderId = orderId;
            new bootstrap.Modal(document.getElementById('rejectModal')).show();
        }

        function confirmReject() {
            if (!currentRejectOrderId) return;
            const reason = document.querySelector('input[name="rejectionReason"]:checked');
            if (!reason) {
                alert('Please select a rejection reason');
                return;
            }
            updateOrderStatus(currentRejectOrderId, 3, reason.value);
            bootstrap.Modal.getInstance(document.getElementById('rejectModal')).hide();
        }

        function updateOrderStatus(orderId, status, reason = '') {
            fetch(`/admin/tin-orders/${orderId}/update-status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ status, reason })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadOrders(currentPage);
                    document.querySelectorAll('input[name="rejectionReason"]').forEach(r => r.checked = false);
                }
            })
            .catch(error => console.error('Error:', error));
        }

        function updateStats(stats) {
            document.getElementById('stat-total').textContent = stats.total;
            document.getElementById('stat-pending').textContent = stats.pending;
            document.getElementById('stat-processing').textContent = stats.processing;
            document.getElementById('stat-completed').textContent = stats.completed;
        }

        function updatePagination(pagination) {
            const paginationEl = document.getElementById('pagination');
            if (!pagination || pagination.last_page <= 1) {
                paginationEl.innerHTML = '';
                return;
            }

            let html = '';
            if (pagination.current_page > 1) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="loadOrders(${pagination.current_page - 1}); return false;">Previous</a></li>`;
            }

            for (let i = 1; i <= pagination.last_page; i++) {
                html += `<li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                    <a class="page-link" href="#" onclick="loadOrders(${i}); return false;">${i}</a>
                </li>`;
            }

            if (pagination.current_page < pagination.last_page) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="loadOrders(${pagination.current_page + 1}); return false;">Next</a></li>`;
            }

            paginationEl.innerHTML = html;
        }

        function resetFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('statusFilter').value = '';
            document.getElementById('typeFilter').value = '';
            loadOrders(1);
        }

        function exportOrders() {
            window.location.href = '/admin/tin-orders/export';
        }

        function getStatusBadge(status) {
            const badges = {
                0: '<span class="badge-status badge-pending">Pending</span>',
                1: '<span class="badge-status badge-processing">Processing</span>',
                2: '<span class="badge-status badge-completed">Completed</span>',
                3: '<span class="badge-status badge-rejected">Rejected</span>'
            };
            return badges[status] || `<span class="badge-status">${status}</span>`;
        }

        function getServiceName(type) {
            const names = {
                1: 'টিন সার্টিফিকেট অর্ডার',
                2: 'নিউ টিন আবেদন',
                3: 'জিরো রিটার্ন আবেদন',
                4: 'টিন সার্টিফিকেট কারেকশন',
                5: 'টিন আইডি পাসওয়ার্ড সেট'
            };
            return names[type] || 'Unknown';
        }

        function formatFormData(formData) {
            try {
                if (typeof formData === 'string') formData = JSON.parse(formData);
                
                if (formData.nid_tin_mobile) return formData.nid_tin_mobile;
                if (formData.nid_no) return 'NID: ' + formData.nid_no;
                if (formData.tin_number) return 'TIN: ' + formData.tin_number;
                if (formData.user_id) return 'User: ' + formData.user_id;
                if (formData.tin_no) return 'TIN: ' + formData.tin_no;
                
                return 'View Details';
            } catch (e) {
                return 'N/A';
            }
        }

        function formatFormDataDetailed(formData) {
            try {
                if (typeof formData === 'string') formData = JSON.parse(formData);
                
                let html = '<ul class="list-unstyled mb-0">';
                for (let [key, value] of Object.entries(formData)) {
                    if (value) html += `<li><strong>${key}:</strong> ${value}</li>`;
                }
                html += '</ul>';
                return html;
            } catch (e) {
                return 'N/A';
            }
        }

        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            return new Date(dateString).toLocaleDateString('en-US', { 
                year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' 
            });
        }
    </script>
</body>
</html>
<?php /**PATH /home/ifixfast24/public_html/resources/views/admin/tin_order/index.blade.php ENDPATH**/ ?>