
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get($title); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            <div class="text-right">
                <a href="<?php echo e(route('user.ssc_certificate.create')); ?>" class="btn btn-success"> <i class="fas fa-plus"></i> Add SSC Certificate </a>
            </div>
            
            <div style="overflow-x:auto;">
                <table class="categories-show-table table table-hover table-striped table-bordered">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="col"><?php echo app('translator')->get('No.'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Student Name'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Registration No'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Roll No'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('School Name'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('GPA'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Certificate'); ?></th>
                    
                        <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('No.'); ?>">
                                <?php echo e($key + 1); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Student Name'); ?>">
                                <?php echo e($data->student_name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Registration No'); ?>">
                                <?php echo e($data->registration_no); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Roll No'); ?>">
                                <?php echo e($data->roll_no); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('School Name'); ?>">
                                <?php echo e($data->school_name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('GPA'); ?>">
                                <?php echo e($data->gpa); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Certificate'); ?>">
                                <a href="<?php echo e(route('user.ssc_certificate.show', $data->id)); ?>" class="btn btn-primary" target="_blank"> <i class="fas fa-print"></i> Print</a>
                            </td>

                            <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-lg-center text-right">
                                <a href="<?php echo e(route('user.ssc_certificate.edit', $data->id)); ?>" class="btn btn-info"> <i class="fas fa-pencil-alt"></i> Edit </a>
                                
                                <form style="display:inline-block" action="<?php echo e(route('user.ssc_certificate.destroy', $data->id)); ?>" method="post" onsubmit="return confirm('Do you really want to delete this?');">
                                    <?php echo csrf_field(); ?> 
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger"> <i class="fas fa-trash"></i> Delete </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-danger" colspan="9"><?php echo app('translator')->get('No Data'); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php echo e($objects->appends(@$_GET)->links('partials.pagination')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            // Add any JavaScript functionality here if needed
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/ssc_certificate/index.blade.php ENDPATH**/ ?>