<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Upsheba is a trusted platform for providing essential services in Bangladesh. Get all the information and tools you need with ease.">
    <meta name="keywords" content="Upsheba, Bangladesh, services, information, tools">
    <meta name="robots" content="index, follow">
    <meta name="author" content="Upsheba Team">
    
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e($basic->site_title); ?> </title>
    
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(url('')); ?>/assets/site/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('')); ?>/assets/site/favicon.ico">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('')); ?>/assets/site/favicon.ico">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('')); ?>/assets/site/favicon.ico">
    
    <!-- Bootstrap and Fonts -->
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/site/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/site/fonts/simple-line-icons.min.css">
    
    <!-- Additional Stylesheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.css">
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/site/css/styles.min.css">
    
    <?php echo $__env->yieldPushContent('style'); ?>
    
    <style>
        /* Custom styles can go here */
    </style>
</head>

<body>
    <main class="page landing-page">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
  
    <!-- Scripts -->
    <script src="<?php echo e(url('')); ?>/assets/site/js/jquery.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/site/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/site/js/script.min.js"></script>
    
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH /home/ifixfast24/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>