<aside class="left-sidebar" data-sidebarbg="skin1">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar" data-sidebarbg="skin1">
       
        <style>
            :root {
                --sidebar-bg: black;
                --sidebar-hover: #2d3446;
                --text-primary: #ffffff;
                --text-secondary: rgba(255, 255, 255, 0.7);
                --accent-color: #82C91E;
                --transition-speed: 0.3s;
            }

            .left-sidebar {
                background-color: var(--sidebar-bg);
                color: var(--text-primary);
                width: 260px;
                transition: all var(--transition-speed) ease;
                border-right: 1px solid rgba(255, 255, 255, 0.1);
            }

            .scroll-sidebar {
                background-color: var(--sidebar-bg);
                height: calc(100vh - 60px); /* Adjust height to account for header if any */
                max-height: 100vh;
                padding: 10px 0;
                overflow-y: auto;
                position: fixed;
                width: 260px;
            }

            .scroll-sidebar::-webkit-scrollbar {
                width: 6px;
            }

            .scroll-sidebar::-webkit-scrollbar-track {
                background: var(--sidebar-bg);
            }

            .scroll-sidebar::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
            }

            .sidebar-nav {
                padding: 0;
            }
            
            .sidebar-nav li {
                list-style: none;
                margin: 4px 8px;
            }

            .sidebar-nav li a {
                text-decoration: none;
            }

            .hide-menu {
                font-size: 14px;
                color: var(--text-secondary);
                margin-left: 14px;
                display: block;
                line-height: 1.4;
                transition: color var(--transition-speed) ease;
                 white-space: normal !important;
                overflow-wrap: break-word !important;
                 word-break: break-word !important;
            }
            
            .dashboard {
                font-size: 15px;
                color: var(--text-primary);
                margin-left: 44px;
                display: block;
                font-weight: 500;
            }   

            .sidebar-link {
                position: relative;
                padding: 10px 16px;
                display: flex;
                align-items: center;
                border-radius: 8px;
                transition: all var(--transition-speed) ease;
                margin: 2px 0;
            }

            .sidebar-link:hover {
                background-color: var(--sidebar-hover);
                transform: translateX(4px);
            }

            .sidebar-link:hover .hide-menu,
            .sidebar-link:hover i {
                color: var(--text-primary);
            }

            .sidebar-link i {
                position: absolute;
                left: 16px;
                font-size: 16px;
                color: var(--text-secondary);
                transition: all var(--transition-speed) ease;
            }

            .nav-header {
                font-size: 16px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                color: var(--accent-color);
                padding: 16px 24px 8px;
                font-weight: 600;
                opacity: 0.8;
            }

            .sidebar-item {
                position: relative;
            }

            .sidebar-item.active .sidebar-link {
                background-color: var(--sidebar-hover);
            }

            .sidebar-item.active .hide-menu,
            .sidebar-item.active i {
                color: var(--accent-color);
            }

            /* Add responsive adjustments */
            @media (max-width: 991px) {
                .left-sidebar {
                    width: 240px;
                }
                
                .scroll-sidebar {
                    width: 240px;
                    height: calc(100vh - 60px);
                }
                
                .sidebar-link {
                    padding: 8px 12px;
                }

                .hide-menu, .dashboard {
                    font-size: 13px;
                }

                .nav-header {
                    padding: 12px 20px 6px;
                }
            }

            /* Animation for hover effect */
            @keyframes  slideIn {
                from {
                    transform: translateX(0);
                }
                to {
                    transform: translateX(4px);
                }
            }
        </style>
       <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <!-- GENERAL -->
                <li class="nav-header">GENERAL</li>
                
                <li class="sidebar-item <?php echo e(menuActive(['user.dashboard'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.dashboard')); ?>">
                        <i class="fas fa-id-card" style="color: #fff"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word;">
                            ড্যাশবোর্ড
                        </span>
                    </a>
                </li>

               
              
                    
<li class="sidebar-item <?php echo e(menuActive(['user.ssl-commerz','user.bkash','user.recharge','user.recharge-form'],3)); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('user.recharge')); ?>" aria-expanded="false">
                           <i class="fas fa-wallet" style="color: #FFD700"></i>
                            <span class="nav-label">
                            <span class="hide-menu" style="color: #ffffff">Recharge</span>
                        </a>
                    </li> 
                  
                    
                <!-- NID SERVICES -->
                <li class="nav-header">NID SERVICES</li>
              
                <li class="sidebar-item <?php echo e(menuActive(['user.sign.copy.order.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.sign.copy.order.index')); ?>">
                        <i class="fas fa-signature" style="color: #FF69B4"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                            সাইন কপি অর্ডার
                        </span>
                    </a>
                </li>  
                
                 <li class="sidebar-item <?php echo e(menuActive(['user.nid.order.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.nid.order.index')); ?>">
                        <i class="fas fa-id-card" style="color: #FF69B4"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                            NID Order
                        </span>
                    </a>
                </li>
                   <li class="sidebar-item <?php echo e(menuActive(['user.passport.order.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.passport.order.index')); ?>">
                        <i class="fas fa-passport" style="color: #FF69B4"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                            পাসপোর্ট অর্ডার
                        </span>
                    </a>
                </li>
                 </li>
                   <li class="sidebar-item <?php echo e(menuActive(['user.sim.conversion.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.sim.conversion.index')); ?>">
                        <i class="fas fa-sim-card" style="color: #FF69B4"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                    সীম বায়োমেট্রিক
                        </span>
                    </a>
                </li>  
                 </li>
                   <li class="sidebar-item <?php echo e(menuActive(['user.sim.network.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.sim.network.index')); ?>">
                        <i class="fas fa-sim-card" style="color: #FF69B4"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                            সিম নেটওয়ার্ক অর্ডার
                        </span>
                    </a>
                </li> 
                 <li class="sidebar-item <?php echo e(menuActive(['user.tin.order.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.tin.order.index')); ?>">
                        <i class="fas fa-id-card" style="color: #FF69B4"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                            টিন সেবা
                        </span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e(menuActive(['user.sign-to-server.index'],3)); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('user.sign-to-server.index')); ?>">
                            <i class="fas fa-list" style="color: #fff"></i>
                            <span class="hide-menu">Sign To Server</span>
                        </a>
                    </li>
             

                
                <li class="sidebar-item <?php echo e(menuActive(['user.nid.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.nid.index')); ?>">
                        <i class="fas fa-id-card" style="color: #FF69B4"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                            NID Manual
                        </span>
                    </a>
                </li>

                
<li class="sidebar-item <?php echo e(menuActive(['user.smartcard.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.smartcard.index')); ?>">
                        <i class="fas fa-id-card" style="color: #d1e1e2ff"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                            Smart Card
                        </span>
                    </a>
                </li>   
                
                <li class="sidebar-item <?php echo e(menuActive(['user.nibondon.*'],3)); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('user.nibondon.index')); ?>">
                        <i class="fas fa-file-alt" style="color: #4CAF50"></i>
                        <span class="hide-menu" style="white-space: normal; word-break: break-word; color: #ffffff">
                            নিবন্ধন 
                        </span>
                    </a>
                </li>

                     
   <!-- NID SERVICES -->
                <li class="nav-header">Vaccine</li>                  
                    
     <li class="sidebar-item <?php echo e(menuActive(['user.surokkha.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.surokkha.index')); ?>">
        <i class="fas fa-syringe" style="color: #FF6B6B"></i>
        <span class="hide-menu" style="color: #ffffff">Vaccine Entry</span>
    </a>
</li>
<li class="sidebar-item <?php echo e(menuActive(['user.death_certificate.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.death_certificate.index')); ?>">
        <i class="fas fa-scroll" style="color: #808080"></i>
        <span class="hide-menu" style="color: #ffffff">Death Certificate</span>
    </a>
</li>
<li class="sidebar-item <?php echo e(menuActive(['user.pdo.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.pdo.index')); ?>">
        <i class="fas fa-certificate" style="color: #4CAF50"></i>
        <span class="hide-menu" style="color: #ffffff">Training Certificate</span>
    </a>
</li>

<li class="sidebar-item <?php echo e(menuActive(['user.land.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.land.index')); ?>">
        <i class="fas fa-home" style="color: #87CEEB"></i>
        <span class="hide-menu" style="color: #ffffff">Land Development</span>
    </a>
</li>
<li class="sidebar-item <?php echo e(menuActive(['user.ssc.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.ssc_certificate.index')); ?>">
        <i class="fas fa-graduation-cap" style="color: #FF4081"></i>
        <span class="hide-menu" style="color: #ffffff">SSC Certificate</span>
    </a>
</li>



<li class="sidebar-item <?php echo e(menuActive(['user.police.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.police.index')); ?>">
        <i class="fas fa-shield-alt" style="color: #1E90FF"></i>
        <span class="hide-menu" style="color: #ffffff">Police Verification</span>
    </a>
</li>
<li class="sidebar-item <?php echo e(menuActive(['user.trade.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.trade.index')); ?>">
        <i class="fas fa-store" style="color: #FFA500"></i>
        <span class="hide-menu" style="color: #ffffff">Trade License</span>
    </a>
</li>

<li class="sidebar-item <?php echo e(menuActive(['user.nagorik-sonod.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.nagorik-sonod.index')); ?>">
        <i class="fas fa-user-check" style="color: #9370DB"></i>
        <span class="hide-menu" style="color: #ffffff">Nagorik Sonod</span>
    </a>
</li> 

<li class="sidebar-item <?php echo e(menuActive(['user.uttoradhikarsonod.*'],3)); ?>">
    <a class="sidebar-link" href="<?php echo e(route('user.uttoradhikarsonod.index')); ?>">
        <i class="fas fa-users" style="color: #20B2AA"></i>
        <span class="hide-menu" style="color: #ffffff">Uttoradhikar Sonod</span>
    </a>
</li> 

<li class="sidebar-item <?php echo e(menuActive(['user.transactions'],3)); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('user.transactions')); ?>" aria-expanded="false">
                            <i class="fas fa-money-bill-wave" style="color: #98FB98"></i>
                            <span class="hide-menu">Transaction Details</span>
                        </a>
                   
 </li>



            </ul>
        </nav>
       
    </div>
   
</aside>
<?php /**PATH /home/ifixfast24/public_html/resources/views/user/layouts/sidebar.blade.php ENDPATH**/ ?>