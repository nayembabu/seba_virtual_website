<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e($basic->site_title); ?> </title>
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/site/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/site/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.css">
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/site/css/styles.min.css">
    <?php echo $__env->yieldPushContent('style'); ?>
    <style>
    /* Apply fixed background color and black text color to the header */
    .header-animation {
        background-color: #FF5733; /* Fixed background color */
        color: black; /* Fixed text color */
    }

    /* Apply the same background color to the logo's background */
    .navbar-brand {
        background-color: #f7fcfb; /* Same background color as header */
        padding: 5px; /* Add some padding if necessary */
    }
</style>

</head>

<body>
    <header class="topbar header-animation" data-navbarbg="skin6">

        <nav class="navbar top-navbar navbar-expand-md">
            <div class="navbar-header" data-logobg="skin6">
                <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i
                        class="ti-menu ti-close"></i></a>
                        
                <div class="navbar-brand" style="display: flex; justify-content: center; width: 100%;">
                    <a href="<?php echo e(route('user.dashboard')); ?>" style="text-align: center;">
                    <span class="logo-text">
                        <img src="<?php echo e(asset('assets/uploads/logo/Whats-App-Image-2025-06-04-at-13-33-05-1b06f411-removebg-preview.png')); ?>" alt="homepage"
                             class="dark-logo" style="height: 70px; margin: auto;"/>
                        <img src="<?php echo e(asset('assets/uploads/logo/Whats-App-Image-2025-06-04-at-13-33-05-1b06f411-removebg-preview.png')); ?>" class="light-logo"
                             alt="homepage" style="height: 70px; margin: auto;"/>
                    </span>
                    </a>
                    
                </div>
                

                <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)"
                    data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i
                        class="ti-more"></i></a>
            </div>

            <div class="navbar-collapse collapse" id="navbarSupportedContent">
                
                
                <ul class="navbar-nav float-left mr-auto ml-3 pl-1">
                    <li class="nav-item" id="pushNotificationArea">
                        <a class="nav-link dropdown-toggle pl-md-3 position-relative" href="<?php echo e(route('user.notifications')); ?>"
                            id="bell">
                            <span>
                                <i data-feather="bell" class="svg-icon"></i>
                            </span>
                            <span class="badge badge-primary notify-no rounded-circle" > <?php echo e(get_unread_notification(Auth::guard('web')->user()->id)); ?> </span>
                        </a>
                    </li>
                    <li class="nav-item"><br/>
                        <span class="text-success">Balance : <?php echo e(inum(Auth::guard('web')->user()->balance)); ?> </span>
                    </li>
                    
                </ul>

                <ul class="navbar-nav float-right">
                    <li class="nav-item d-none d-md-block">
                        <a class="nav-link" href="javascript:void(0)">
                            <form class="navbar-search-form" onsubmit="return false;">
                                <div class="customize-input">
                                    <input class="form-control custom-shadow custom-radius border-0 bg-white"
                                        type="search" name="navbar_search" id="navbar_search" autocomplete="off"
                                        placeholder="Search" aria-label="Search">
                                    <i class="form-control-icon" data-feather="search"></i>
                                </div>

                                <div id="navbar_search_result_area">
                                    <ul class="navbar_search_result"></ul>
                                </div>
                            </form>
                        </a>
                    </li>

                    <!-- ============================================================== -->
                    <!-- User profile and search
                    .ti-menu:before {
                    content: "\e68e";
                    }
                    -->
                    <!-- ============================================================== -->
                    <li class="nav-item dropdown"> 


                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            
                            <div class="m-profile"> Profile <i class="fas fa-chevron-down"></i> </div>
                            
                            <span class="ml-2 d-none d-lg-inline-block"><span class="text-dark"><?php echo app('translator')->get('Hello,'); ?></span> <span
                                    class="text-dark"><?php echo e(Auth::User()->name); ?></span> <i
                                    data-feather="chevron-down"
                                    class="svg-icon"></i></span>
                        </a>


                        <div class="dropdown-menu dropdown-menu-right user-dd animated flipInY">

                            <a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>">
                                <i class="svg-icon mr-2 ml-1 icon-user"></i>
                                <?php echo app('translator')->get('Profile'); ?>
                            </a>

                            <a class="dropdown-item" href="<?php echo e(route('user.updatePassword')); ?>">
                                <i class="svg-icon mr-2 ml-1 icon-settings"></i>
                                <?php echo app('translator')->get('Password'); ?>
                            </a>

                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>"><i
                                    data-feather="power" class="svg-icon mr-2 ml-1"></i>
                                <?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>

                        </div>
                    </li>


                </ul>
            </div>

        </nav>
    </header>
</body>

</html>
<?php /**PATH /home/ifixfast24/public_html/resources/views/user/layouts/header.blade.php ENDPATH**/ ?>