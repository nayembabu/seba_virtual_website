<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Passport Orders Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            z-index: 1000;
            overflow-y: auto;
            transition: all 0.3s;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0 10px;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.2);
            color: white;
            transform: translateX(5px);
        }
        .sidebar-menu a i {
            margin-right: 12px;
            font-size: 18px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
            padding: 20px;
            transition: all 0.3s;
        }
        .top-navbar {
            background: white;
            padding: 15px 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            text-align: center;
            transition: all 0.3s;
        }
        .stat-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-5px);
        }
        .stat-card h6 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .stat-card h3 {
            color: #667eea;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .stat-card .icon {
            font-size: 32px;
            color: #667eea;
            opacity: 0.2;
        }
        .badge-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-approved {
            background: #d4edda;
            color: #155724;
        }
        .badge-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .badge-completed {
            background: #d1ecf1;
            color: #0c5460;
        }
        .badge-processing {
            background: #e7d4f5;
            color: #5a21b5;
        }
        .badge-cancelled {
            background: #f8d7da;
            color: #721c24;
        }
        .table-wrapper {
            overflow-x: auto;
        }
        .table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .table thead th {
            border: none !important;
            color: white !important;
            font-weight: 600;
            padding: 15px;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: transparent !important;
        }
        .table tbody td {
            border: none;
            padding: 15px;
            vertical-align: middle;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }
        .table tbody tr:hover {
            background: #f9f9f9;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .action-buttons .btn {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 5px;
        }
        .btn-action {
            background: #667eea;
            color: white;
            border: none;
        }
        .btn-action:hover {
            background: #5568d3;
            color: white;
        }
        .btn-reject {
            background: #dc3545;
            color: white;
            border: none;
        }
        .btn-reject:hover {
            background: #c82333;
            color: white;
        }
        .btn-complete {
            background: #28a745;
            color: white;
            border: none;
        }
        .btn-complete:hover {
            background: #218838;
            color: white;
        }
        .expand-icon {
            cursor: pointer;
            transition: transform 0.3s;
            color: #667eea;
        }
        .expand-icon.expanded {
            transform: rotate(180deg);
        }
        .details-section {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 10px;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 15px;
        }
        .detail-item {
            padding: 12px;
            background: white;
            border-radius: 5px;
            border-left: 3px solid #667eea;
        }
        .detail-item strong {
            color: #667eea;
            display: block;
            font-size: 12px;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        .detail-item span {
            color: #333;
            font-size: 14px;
        }
        .search-box {
            position: relative;
        }
        .search-box input {
            padding-left: 35px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-group select {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 8px 12px;
        }
        
        /* Mobile Sidebar Toggle Button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transition: all 0.3s;
        }
        .sidebar-toggle:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        .sidebar-toggle i {
            font-size: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar-toggle {
                display: block;
            }
            .sidebar {
                width: 0;
                padding: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 10px;
                padding-top: 70px;
            }
            .stat-card {
                margin-bottom: 15px;
            }
            .action-buttons {
                flex-direction: column;
            }
            .action-buttons .btn {
                width: 100%;
            }
            .details-grid {
                grid-template-columns: 1fr;
            }
            .top-navbar {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Mobile Menu Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Page Title with Bengali -->
        <div class="page-header mb-4">
            <div class="d-flex align-items-center gap-3 mb-3">
                <div style="font-size: 28px; color: #667eea;">
                    <i class="fas fa-passport"></i>
                </div>
                <div>
                    <h2 class="mb-1" style="color: #333;">পাসপোর্ট অর্ডার ম্যানেজমেন্ট</h2>
                    <p class="text-muted mb-0" style="font-size: 13px;">সকল পাসপোর্ট অর্ডারের তালিকা এবং পরিচালনা</p>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h3><?php echo e($orders->count()); ?></h3>
                        <p class="mb-0">Total Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h3><?php echo e($orders->where('status', 0)->count()); ?></h3>
                        <p class="mb-0">Pending</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h3><?php echo e($orders->where('status', 1)->count()); ?></h3>
                        <p class="mb-0">Processing</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h3><?php echo e($orders->where('status', 2)->count()); ?></h3>
                        <p class="mb-0">Completed</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="searchInput" 
                            placeholder="Search by user ID, form type..."
                        >
                    </div>
                    <div class="col-md-3">
                        <select id="statusFilter" class="form-select">
                            <option value="">All Status</option>
                            <option value="0">Pending</option>
                            <option value="1">Processing</option>
                            <option value="2">Completed</option>
                            <option value="3">Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="formTypeFilter" class="form-select">
                            <option value="">All Form Types</option>
                            <option value="1">MRP Passport to SB Copy</option>
                            <option value="3">NID/Nibondhon to Passport Info</option>
                            <option value="4">BMET 78% Approve</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-secondary w-100" onclick="resetFilters()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orders Table -->
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-passport me-2"></i>সকল পাসপোর্ট অর্ডার</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0" style="font-size: 14px;">
                        <thead style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                            <tr>
                                <th style="color: white;"></th>
                                <th style="color: white;">ID</th>
                                <th style="color: white;">User</th>
                                <th style="color: white;">সেবার নাম</th>
                                <th style="color: white;">Price</th>
                                <th style="color: white;">স্ট্যাটাস</th>
                                <th style="color: white;">PDF Upload</th>
                                <th style="color: white;">তারিখ</th>
                                <th style="color: white;">নোট</th>
                                <th style="color: white;">একশন</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="order-row" onclick="toggleDetails(<?php echo e($order->id); ?>)" style="cursor: pointer;">
                                    <td>
                                        <i class="fas fa-chevron-right expand-icon-<?php echo e($order->id); ?>" id="icon-<?php echo e($order->id); ?>"></i>
                                    </td>
                                    <td>
                                        <strong>#<?php echo e($order->id); ?></strong>
                                    </td>
                                    <td>
                                        <strong><?php echo e($order->user->name ?? 'N/A'); ?></strong><br>
                                        <small class="text-muted"><?php echo e($order->user->email ?? 'N/A'); ?></small>
                                    </td>
                                    <td>
                                        <?php if($order->form_type == 1): ?>
                                            <span class="badge" style="background: #3498db; color: white; font-size: 11px;">MRP Passport to SB Copy</span>
                                        <?php elseif($order->form_type == 3): ?>
                                            <span class="badge" style="background: #9b59b6; color: white; font-size: 11px;">NID/Nibondhon to Passport</span>
                                        <?php elseif($order->form_type == 4): ?>
                                            <span class="badge" style="background: #e74c3c; color: white; font-size: 11px;">BMET 78% Approve</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary" style="font-size: 11px;">Type <?php echo e($order->form_type); ?></span>
                                        <?php endif; ?>
                                        <div style="font-size: 11px; color: #666; margin-top: 3px;"><?php echo e($order->form_type_name ?? 'N/A'); ?></div>
                                    </td>
                                    <td><strong>৳ <?php echo e(number_format($order->cost ?? 0, 2)); ?></strong></td>
                                    <td>
                                        <?php if($order->status == 0): ?>
                                            <span class="badge-status badge-pending">Pending</span>
                                        <?php elseif($order->status == 1): ?>
                                            <span class="badge-status badge-processing">Processing</span>
                                        <?php elseif($order->status == 2): ?>
                                            <span class="badge-status badge-completed">Completed</span>
                                        <?php elseif($order->status == 3): ?>
                                            <span class="badge-status badge-cancelled">Cancelled</span>
                                        <?php else: ?>
                                            <span class="badge-status">Unknown</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="pdf-upload-section">
                                            <input type="file" id="pdf-<?php echo e($order->id); ?>" accept=".pdf" style="display: none;" class="pdf-input" onchange="uploadPDF(<?php echo e($order->id); ?>, this)">
                                            <?php if($order->admin_note && (strpos($order->admin_note, '/passport_pdfs/') === 0 || strpos($order->admin_note, '/storage/') === 0)): ?>
                                                <a href="javascript:void(0)" onclick="downloadPDF(<?php echo e($order->id); ?>)" style="display: block; width: 100%; background-color: #27ae60; color: white; border: none; padding: 8px; border-radius: 4px; text-decoration: none; text-align: center; font-size: 13px;">
                                                    <i class="fas fa-download"></i> Download
                                                </a>
                                            <?php else: ?>
                                                <button type="button" onclick="document.getElementById('pdf-<?php echo e($order->id); ?>').click();" style="width: 100%; background-color: #2196F3; color: white; border: none; padding: 8px; border-radius: 4px; font-size: 13px; cursor: pointer;">
                                                    <i class="fas fa-cloud-upload-alt"></i> Upload
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td style="font-size: 12px;">
                                        <?php echo e($order->created_at->format('d M, Y')); ?><br>
                                        <small class="text-muted"><?php echo e($order->created_at->format('h:i A')); ?></small>
                                    </td>
                                    <td onclick="event.stopPropagation();">
                                        <div style="max-width: 200px;">
                                            <textarea id="note-<?php echo e($order->id); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px; min-height: 60px; resize: vertical; font-family: inherit;"><?php echo e($order->text ?? ''); ?></textarea>
                                            <button onclick="saveNote(<?php echo e($order->id); ?>)" style="width: 100%; margin-top: 5px; background-color: #3498db; color: white; border: none; padding: 6px; border-radius: 4px; font-size: 12px; cursor: pointer;">Save</button>
                                        </div>
                                    </td>
                                    <td onclick="event.stopPropagation();">
                                        <?php if($order->status == 0): ?>
                                            <button class="btn btn-sm" style="background: #667eea; color: white;" onclick="updateOrderStatus(<?php echo e($order->id); ?>, 1)" title="প্রসেসিং করুন">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="showRejectModal(<?php echo e($order->id); ?>)" title="বাতিল করুন">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        <?php elseif($order->status == 1): ?>
                                            <button class="btn btn-sm btn-success" onclick="updateOrderStatus(<?php echo e($order->id); ?>, 2)" title="সম্পন্ন করুন">
                                                <i class="fas fa-check-double"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="showRejectModal(<?php echo e($order->id); ?>)" title="বাতিল করুন">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <!-- Expandable Details Row -->
                                <tr id="details-row-<?php echo e($order->id); ?>" class="details-row" style="display: none;">
                                    <td colspan="9">
                                        <div class="details-panel p-4" style="background: #f9f9f9; border-left: 4px solid #667eea;">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <h6 class="mb-3"><i class="fas fa-user-circle"></i> User Information</h6>
                                                    <p><strong>Order ID:</strong> #<?php echo e($order->id); ?></p>
                                                    <p><strong>User Name:</strong> <?php echo e($order->user->name ?? 'N/A'); ?></p>
                                                    <p><strong>Email:</strong> <?php echo e($order->user->email ?? 'N/A'); ?></p>
                                                    <p><strong>Phone:</strong> <?php echo e($order->user->phone ?? 'N/A'); ?></p>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6 class="mb-3"><i class="fas fa-info-circle"></i> Order Information</h6>
                                                    <p><strong>Form Type:</strong> <?php echo e($order->form_type); ?></p>
                                                    <p><strong>Form Type Name:</strong> <?php echo e($order->form_type_name ?? 'N/A'); ?></p>
                                                    <p><strong>Price:</strong> ৳ <?php echo e(number_format($order->cost ?? 0, 2)); ?></p>
                                                    <p><strong>Status:</strong>
                                                        <?php if($order->status == 0): ?>
                                                            <span class="badge-status badge-pending">Pending</span>
                                                        <?php elseif($order->status == 1): ?>
                                                            <span class="badge-status badge-processing">Processing</span>
                                                        <?php elseif($order->status == 2): ?>
                                                            <span class="badge-status badge-completed">Completed</span>
                                                        <?php elseif($order->status == 3): ?>
                                                            <span class="badge-status badge-cancelled">Cancelled</span>
                                                        <?php endif; ?>
                                                    </p>
                                                    <p><strong>Created:</strong> <?php echo e($order->created_at->format('d M, Y H:i:s')); ?></p>
                                                </div>
                                            </div>

                                            <hr>

                                            <h6 class="mb-3"><i class="fas fa-list"></i> Form Data</h6>
                                            <?php
                                                $formData = is_string($order->form_data) ? json_decode($order->form_data, true) : $order->form_data;
                                            ?>
                                            <?php if(is_array($formData) && count($formData) > 0): ?>
                                                <div class="row">
                                                    <?php $__currentLoopData = $formData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-6 mb-2">
                                                            <div class="p-2" style="background: white; border-radius: 5px; border-left: 3px solid #667eea;">
                                                                <strong><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:</strong><br>
                                                                <span class="text-muted"><?php echo e(is_array($value) ? json_encode($value) : $value); ?></span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php else: ?>
                                                <p class="text-muted">No form data available</p>
                                            <?php endif; ?>

                                            <hr>

                                            <div class="d-flex justify-content-end gap-2">
                                                <button class="btn btn-sm btn-secondary" onclick="toggleDetails(<?php echo e($order->id); ?>)">
                                                    <i class="fas fa-times"></i> Close
                                                </button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-danger py-4">
                                        <i class="fas fa-inbox"></i> No orders found
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white">
                <nav>
                    <ul class="pagination mb-0">
                        <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Rejection Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="rejectModalLabel">
                        <i class="fas fa-times-circle"></i> অর্ডার বাতিল করুন
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3"><strong>বাতিল করার কারণ নির্বাচন করুন:</strong></p>
                    <div class="d-flex flex-column gap-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason1" value="নথিপত্র অসম্পূর্ণ বা অবৈধ">
                            <label class="form-check-label" for="reason1">
                                নথিপত্র অসম্পূর্ণ বা অবৈধ
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason2" value="ডকুমেন্টের মান দুর্বল">
                            <label class="form-check-label" for="reason2">
                                ডকুমেন্টের মান দুর্বল
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason3" value="তথ্য মিলছে না">
                            <label class="form-check-label" for="reason3">
                                তথ্য মিলছে না
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason4" value="ব্যবহারকারীর বাতিলের অনুরোধ">
                            <label class="form-check-label" for="reason4">
                                ব্যবহারকারীর বাতিলের অনুরোধ
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল করুন</button>
                    <button type="button" class="btn btn-danger" onclick="confirmReject()">
                        <i class="fas fa-check"></i> নিশ্চিত করুন
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleDetails(orderId) {
            const detailsRow = document.getElementById('details-row-' + orderId);
            const icon = document.getElementById('icon-' + orderId);
            
            if (detailsRow.style.display === 'none' || !detailsRow.style.display) {
                detailsRow.style.display = 'table-row';
                icon.classList.remove('fa-chevron-right');
                icon.classList.add('fa-chevron-down');
            } else {
                detailsRow.style.display = 'none';
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-right');
            }
        }

        function downloadPDF(orderId) {
            const downloadUrl = `/admin/passport-orders/${orderId}/download-pdf`;
            console.log('Downloading from:', downloadUrl);
            
            // Create a temporary link and click it
            const link = document.createElement('a');
            link.href = downloadUrl;
            link.download = 'order_' + orderId + '.pdf';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function updateOrderStatus(orderId, newStatus, skipConfirm = false) {
            const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>';
            
            fetch(`/admin/passport-orders/${orderId}/update-status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ status: newStatus })
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    location.reload(); // Reload page to see changes
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        function uploadPDF(orderId, fileInput) {
            const file = fileInput.files[0];
            if (!file) return;

            // Check if file is PDF
            if (file.type !== 'application/pdf') {
                fileInput.value = '';
                return;
            }

            // Check file size (max 10MB)
            const maxSize = 10 * 1024 * 1024;
            if (file.size > maxSize) {
                fileInput.value = '';
                return;
            }

            const formData = new FormData();
            formData.append('pdf', file);
            formData.append('order_id', orderId);

            const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>';

            const uploadBtn = fileInput.parentElement.querySelector('button') || fileInput.parentElement.querySelector('a');
            uploadBtn.disabled = true;
            uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> আপলোড হচ্ছে...';

            const uploadUrl = `/admin/passport-orders/${orderId}/upload-pdf`;

            fetch(uploadUrl, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(response => {
                return response.json();
            })
            .then(data => {
                if(data.success) {
                    // Auto update status to Completed (2) without confirmation and without alert
                    updateOrderStatus(orderId, 2, true);
                } else {
                    uploadBtn.disabled = false;
                    uploadBtn.innerHTML = '<i class="fas fa-cloud-upload-alt"></i> Upload';
                    fileInput.value = '';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                uploadBtn.disabled = false;
                uploadBtn.innerHTML = '<i class="fas fa-cloud-upload-alt"></i> Upload';
                fileInput.value = '';
            });
        }

        function saveNote(orderId) {
            const noteText = document.getElementById('note-' + orderId).value;
            const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>';
            
            fetch(`/admin/passport-orders/${orderId}/save-note`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ note: noteText })
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    // Auto update status to Completed (2)
                    updateOrderStatus(orderId, 2, true);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        // Rejection Modal Functions
        let currentRejectOrderId = null;

        function showRejectModal(orderId) {
            currentRejectOrderId = orderId;
            const rejectModal = new bootstrap.Modal(document.getElementById('rejectModal'));
            rejectModal.show();
        }

        function confirmReject() {
            const selectedReason = document.querySelector('input[name="rejectionReason"]:checked');
            
            if (!selectedReason) {
                alert('দয়া করে একটি কারণ নির্বাচন করুন');
                return;
            }

            const rejectionReason = selectedReason.value;
            const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>';
            
            fetch(`/admin/passport-orders/${currentRejectOrderId}/save-rejection-reason`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ rejection_reason: rejectionReason })
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    // Close modal
                    const rejectModal = bootstrap.Modal.getInstance(document.getElementById('rejectModal'));
                    rejectModal.hide();
                    
                    // Reset radio buttons
                    document.querySelectorAll('input[name="rejectionReason"]').forEach(input => input.checked = false);
                    
                    // Update order status to Cancelled (3)
                    updateOrderStatus(currentRejectOrderId, 3, true);
                } else {
                    alert('ত্রুটি হয়েছে। দয়া করে পুনরায় চেষ্টা করুন।');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('ত্রুটি হয়েছে। দয়া করে পুনরায় চেষ্টা করুন।');
            });
        }
    </script>
</body>
</html>
<?php /**PATH /home/ifixfast24/public_html/resources/views/admin/Passport_order/index.blade.php ENDPATH**/ ?>