<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>SIM Network Orders Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            z-index: 1000;
            overflow-y: auto;
            transition: all 0.3s;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0 10px;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.2);
            color: white;
            transform: translateX(5px);
        }
        .sidebar-menu a i {
            margin-right: 12px;
            font-size: 18px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
            padding: 20px;
            transition: all 0.3s;
        }
        .page-header {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            text-align: center;
            transition: all 0.3s;
        }
        .stat-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-5px);
        }
        .badge-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-processing {
            background: #e7d4f5;
            color: #5a21b5;
        }
        .badge-completed {
            background: #d1ecf1;
            color: #0c5460;
        }
        .badge-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .table thead {
            background: #f8f9fa;
        }
        .table thead th {
            border: none;
            color: #667eea;
            font-weight: 600;
            padding: 15px;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .table tbody td {
            border: none;
            padding: 15px;
            vertical-align: middle;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }
        .table tbody tr:hover {
            background: #f9f9f9;
        }
        .expand-icon {
            cursor: pointer;
            transition: transform 0.3s;
            color: #667eea;
        }
        
        /* Mobile Sidebar Toggle Button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transition: all 0.3s;
        }
        .sidebar-toggle:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        .sidebar-toggle i {
            font-size: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar-toggle {
                display: block;
            }
            .sidebar {
                width: 0;
                padding: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 10px;
                padding-top: 70px;
            }
        }
    </style>
</head>
<body>
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Mobile Menu Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Page Header -->
        <div class="page-header mb-4">
            <div class="d-flex align-items-center gap-3 mb-3">
                <div style="font-size: 28px; color: #667eea;">
                    <i class="fas fa-network-wired"></i>
                </div>
                <div>
                    <h2 class="mb-1" style="color: #333;">সিম নেটওয়ার্ক অর্ডার ম্যানেজমেন্ট</h2>
                    <p class="text-muted mb-0" style="font-size: 13px;">সকল সিম নেটওয়ার্ক সার্ভিস অর্ডারের তালিকা এবং পরিচালনা</p>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h3 id="stat-total">0</h3>
                        <p class="mb-0">Total Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h3 id="stat-pending">0</h3>
                        <p class="mb-0">Pending</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h3 id="stat-processing">0</h3>
                        <p class="mb-0">Processing</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h3 id="stat-completed">0</h3>
                        <p class="mb-0">Completed</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search & Filter Bar -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="searchInput" 
                            placeholder="Search by phone number, NID, IMEI..."
                        >
                    </div>
                    <div class="col-md-2">
                        <select id="statusFilter" class="form-select">
                            <option value="">All Status</option>
                            <option value="0">Pending</option>
                            <option value="1">Processing</option>
                            <option value="2">Completed</option>
                            <option value="3">Rejected</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="typeFilter" class="form-select">
                            <option value="">All Services</option>
                            <option value="1">কল লিস্ট ৩ মাস</option>
                            <option value="2">রবি/এয়ারটেল SMS</option>
                            <option value="3">বাংলালিংক SMS</option>
                            <option value="4">নাম্বার টু লোকেশন</option>
                            <option value="5">NID টু নাম্বার</option>
                            <option value="6">IMEI টু লোকেশন</option>
                            <option value="7">IMEI টু এক্টিভ</option>
                            <option value="8">নাম্বার টু IMEI</option>
                            <option value="9">বিকাশ ইনফো</option>
                            <option value="10">নগদ ইনফো</option>
                            <option value="11">রকেট ইনফো</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-secondary w-100" onclick="resetFilters()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-success w-100" onclick="exportOrders()">
                            <i class="fas fa-download"></i> Export CSV
                        </button>
                    </div>
                </div>
            </div>
        </div>

      <!-- Orders Table -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0">সকল সিম নেটওয়ার্ক অর্ডার</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th></th>
                                <th>Order ID</th>
                                <th>User ID</th>
                                <th>Service Type</th>
                                <th>Form Data</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>PDF Upload</th>
                                <th>Note</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="ordersTableBody">
                            <tr>
                                <td colspan="11" class="text-center py-4 text-muted">
                                    <i class="fas fa-spinner fa-spin"></i> Loading orders...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white">
                <nav>
                    <ul class="pagination mb-0" id="pagination">
                        <!-- Pagination will be loaded here -->
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Rejection Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-times-circle"></i> অর্ডার বাতিল করুন
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3"><strong>বাতিল করার কারণ নির্বাচন করুন:</strong></p>
                    <div class="d-flex flex-column gap-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason1" value="তথ্য অসম্পূর্ণ বা ভুল">
                            <label class="form-check-label" for="reason1">তথ্য অসম্পূর্ণ বা ভুল</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason2" value="নম্বর/IMEI/NID বৈধ নয়">
                            <label class="form-check-label" for="reason2">নম্বর/IMEI/NID বৈধ নয়</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason3" value="সার্ভিস বর্তমানে অনুপলব্ধ">
                            <label class="form-check-label" for="reason3">সার্ভিস বর্তমানে অনুপলব্ধ</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason4" value="ব্যবহারকারীর বাতিলের অনুরোধ">
                            <label class="form-check-label" for="reason4">ব্যবহারকারীর বাতিলের অনুরোধ</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল করুন</button>
                    <button type="button" class="btn btn-danger" onclick="confirmReject()">
                        <i class="fas fa-check"></i> নিশ্চিত করুন
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentPage = 1;
        let currentRejectOrderId = null;

        document.addEventListener('DOMContentLoaded', function() {
            loadOrders();
            setupEventListeners();
        });

        function setupEventListeners() {
            document.getElementById('searchInput').addEventListener('keyup', function() {
                currentPage = 1;
                loadOrders();
            });

            document.getElementById('statusFilter').addEventListener('change', function() {
                currentPage = 1;
                loadOrders();
            });

            document.getElementById('typeFilter').addEventListener('change', function() {
                currentPage = 1;
                loadOrders();
            });
        }

        function loadOrders(page = 1) {
            currentPage = page;
            const search = document.getElementById('searchInput').value;
            const status = document.getElementById('statusFilter').value;
            const type = document.getElementById('typeFilter').value;

            const queryParams = new URLSearchParams();
            if (search) queryParams.append('search', search);
            if (status !== '') queryParams.append('status', status);
            if (type) queryParams.append('type', type);
            queryParams.append('page', page);

            fetch(`/admin/sim-network-orders/get-orders?${queryParams}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                renderOrders(data.orders);
                updateStats(data.stats);
                updatePagination(data.pagination);
            })
            .catch(error => {
                console.error('Error loading orders:', error);
                document.getElementById('ordersTableBody').innerHTML = 
                    '<tr><td colspan="10" class="text-center py-4 text-danger">Error loading orders. Please try again.</td></tr>';
            });
        }

        function renderOrders(orders) {
            const tbody = document.getElementById('ordersTableBody');
            
            if (orders.length === 0) {
                tbody.innerHTML = '<tr><td colspan="11" class="text-center py-4 text-muted">No orders found</td></tr>';
                return;
            }

            tbody.innerHTML = orders.map(order => `
                <tr class="order-row" onclick="toggleDetails(${order.id})" style="cursor: pointer;">
                    <td>
                        <i class="fas fa-chevron-right expand-icon" id="icon-${order.id}"></i>
                    </td>
                    <td><strong>#${order.id}</strong></td>
                    <td>${order.user_id || 'N/A'}</td>
                    <td>
                        <span class="badge bg-info text-white">${order.form_type_name || getServiceName(order.type)}</span>
                    </td>
                    <td>${formatFormData(order.form_data)}</td>
                    <td>${getTypeBadge(order.type)}</td>
                    <td>${getStatusBadge(order.status)}</td>
                    <td>${formatDate(order.created_at)}</td>
                    <td onclick="event.stopPropagation();">
                        ${getPdfButton(order)}
                    </td>
                    <td onclick="event.stopPropagation();">
                        <div class="input-group input-group-sm">
                            <input 
                                type="text" 
                                class="form-control note-input" 
                                id="note-input-${order.id}" 
                                placeholder="নোট..." 
                                value="${order.text || ''}"
                                style="font-size: 12px;"
                            >
                            <button 
                                class="btn btn-primary" 
                                onclick="saveNote(${order.id})" 
                                title="Save Note"
                                style="padding: 0 10px;"
                            >
                                <i class="fas fa-save"></i>
                            </button>
                        </div>
                    </td>
                    <td onclick="event.stopPropagation();">
                        ${getActionButtons(order)}
                    </td>
                </tr>

                <!-- Expandable Details Row -->
                <tr id="details-row-${order.id}" class="details-row" style="display: none;">
                    <td colspan="11">
                        <div class="details-panel p-4" style="background: #f9f9f9; border-left: 4px solid #667eea;">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <h6 class="mb-3"><i class="fas fa-info-circle"></i> Order Information</h6>
                                    <p><strong>Order ID:</strong> #${order.id}</p>
                                    <p><strong>User ID:</strong> ${order.user_id}</p>
                                    <p><strong>Service:</strong> ${order.form_type_name || getServiceName(order.type)}</p>
                                    <p><strong>Form Data:</strong></p>
                                    <div class="ms-3">${formatFormDataDetailed(order.form_data)}</div>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="mb-3"><i class="fas fa-clock"></i> Status & Timestamps</h6>
                                    <p><strong>Status:</strong> ${getStatusBadge(order.status)}</p>
                                    <p><strong>Created:</strong> ${formatDate(order.created_at)}</p>
                                    <p><strong>Updated:</strong> ${formatDate(order.updated_at)}</p>
                                </div>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-end gap-2">
                                <button class="btn btn-sm btn-secondary" onclick="toggleDetails(${order.id})">
                                    <i class="fas fa-times"></i> Close
                                </button>
                            </div>
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        function toggleDetails(orderId) {
            const detailsRow = document.getElementById('details-row-' + orderId);
            const icon = document.getElementById('icon-' + orderId);
            
            if (detailsRow.style.display === 'none' || !detailsRow.style.display) {
                detailsRow.style.display = 'table-row';
                icon.classList.remove('fa-chevron-right');
                icon.classList.add('fa-chevron-down');
            } else {
                detailsRow.style.display = 'none';
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-right');
            }
        }

        function getActionButtons(order) {
            if (order.status == 0) { // Pending
                return `
                    <button class="btn btn-sm btn-success" onclick="processOrder(${order.id}, ${order.status})" title="Approve">
                        <i class="fas fa-check"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="rejectOrder(${order.id})" title="Reject">
                        <i class="fas fa-times"></i>
                    </button>
                `;
            } else if (order.status == 1) { // Processing
                return `
                    <button class="btn btn-sm btn-primary" onclick="processOrder(${order.id}, ${order.status})" title="Complete">
                        <i class="fas fa-check-double"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="rejectOrder(${order.id})" title="Reject">
                        <i class="fas fa-times"></i>
                    </button>
                `;
            }
            return '<span class="text-muted">No actions</span>';
        }

        function getPdfButton(order) {
            // Check if PDF exists (admin_note contains the PDF path)
            if (order.admin_note && order.admin_note.includes('.pdf')) {
                return `
                    <button class="btn btn-sm btn-success" onclick="downloadPdf(${order.id})" title="Download PDF">
                        <i class="fas fa-download"></i> Download
                    </button>
                `;
            } else {
                return `
                    <input type="file" id="pdf-file-${order.id}" accept=".pdf" style="display: none;" onchange="uploadPdf(${order.id})">
                    <button class="btn btn-sm btn-primary" onclick="document.getElementById('pdf-file-${order.id}').click()" title="Upload PDF">
                        <i class="fas fa-upload"></i> Upload
                    </button>
                `;
            }
        }

        function uploadPdf(orderId) {
            const fileInput = document.getElementById('pdf-file-' + orderId);
            const file = fileInput.files[0];

            if (!file) {
                return;
            }

            // Validate file type
            if (!file.name.toLowerCase().endsWith('.pdf')) {
                alert('শুধুমাত্র PDF ফাইল আপলোড করুন');
                fileInput.value = '';
                return;
            }

            // Validate file size (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                alert('ফাইলের সাইজ ১০ MB এর বেশি হতে পারবে না');
                fileInput.value = '';
                return;
            }

            const formData = new FormData();
            formData.append('pdf', file);

            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            // Show loading state
            const uploadBtn = fileInput.nextElementSibling;
            const originalHTML = uploadBtn.innerHTML;
            uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            uploadBtn.disabled = true;

            fetch(`/admin/sim-network-orders/${orderId}/upload-pdf`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('PDF সফলভাবে আপলোড হয়েছে!');
                    // Auto-update status to Completed (2)
                    updateOrderStatus(orderId, 2);
                } else {
                    alert(data.message || 'PDF আপলোড করতে সমস্যা হয়েছে');
                    uploadBtn.innerHTML = originalHTML;
                    uploadBtn.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('PDF আপলোড করতে সমস্যা হয়েছে');
                uploadBtn.innerHTML = originalHTML;
                uploadBtn.disabled = false;
            });

            // Clear file input
            fileInput.value = '';
        }

        function downloadPdf(orderId) {
            window.open(`/admin/sim-network-orders/${orderId}/download-pdf`, '_blank');
        }

        function saveNote(orderId) {
            const noteInput = document.getElementById('note-input-' + orderId);
            const noteText = noteInput.value.trim();
            
            if (!noteText) {
                alert('অনুগ্রহ করে নোট লিখুন');
                return;
            }

            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            const saveBtn = noteInput.nextElementSibling;
            const originalHTML = saveBtn.innerHTML;
            
            // Show loading state
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

            fetch(`/admin/sim-network-orders/${orderId}/update-note`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ text: noteText })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    saveBtn.innerHTML = originalHTML;
                    saveBtn.disabled = false;
                    alert(data.message || 'নোট সফলভাবে সংরক্ষিত হয়েছে!');
                    // Reload orders to reflect the status change immediately
                    loadOrders(currentPage);
                } else {
                    saveBtn.innerHTML = originalHTML;
                    saveBtn.disabled = false;
                    alert(data.message || 'নোট সংরক্ষণে ত্রুটি হয়েছে');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                saveBtn.innerHTML = originalHTML;
                saveBtn.disabled = false;
                alert('নোট সংরক্ষণে সমস্যা হয়েছে');
            });
        }

        function updateStats(stats) {
            document.getElementById('stat-total').textContent = stats.total;
            document.getElementById('stat-pending').textContent = stats.pending;
            document.getElementById('stat-processing').textContent = stats.processing;
            document.getElementById('stat-completed').textContent = stats.completed;
        }

        function updatePagination(pagination) {
            const paginationEl = document.getElementById('pagination');
            if (!pagination || pagination.last_page <= 1) {
                paginationEl.innerHTML = '';
                return;
            }

            let html = '';
            if (pagination.current_page > 1) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="loadOrders(${pagination.current_page - 1}); return false;">Previous</a></li>`;
            }

            for (let i = 1; i <= pagination.last_page; i++) {
                html += `<li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                    <a class="page-link" href="#" onclick="loadOrders(${i}); return false;">${i}</a>
                </li>`;
            }

            if (pagination.current_page < pagination.last_page) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="loadOrders(${pagination.current_page + 1}); return false;">Next</a></li>`;
            }

            paginationEl.innerHTML = html;
        }

        function processOrder(orderId, currentStatus) {
            const newStatus = currentStatus == 0 ? 1 : 2;
            updateOrderStatus(orderId, newStatus);
        }

        function rejectOrder(orderId) {
            currentRejectOrderId = orderId;
            const rejectModal = new bootstrap.Modal(document.getElementById('rejectModal'));
            rejectModal.show();
        }

        function confirmReject() {
            if (!currentRejectOrderId) return;

            const reason = document.querySelector('input[name="rejectionReason"]:checked');
            if (!reason) {
                alert('অনুগ্রহ করে একটি কারণ নির্বাচন করুন');
                return;
            }

            updateOrderStatus(currentRejectOrderId, 3, reason.value);
            bootstrap.Modal.getInstance(document.getElementById('rejectModal')).hide();
        }

        function updateOrderStatus(orderId, status, reason = '') {
            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/admin/sim-network-orders/${orderId}/update-status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ status: status, reason: reason })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadOrders(currentPage);
                    clearRejectionForm();
                } else {
                    alert(data.message || 'Error updating order status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error updating order status');
            });
        }

        function clearRejectionForm() {
            document.querySelectorAll('input[name="rejectionReason"]').forEach(radio => {
                radio.checked = false;
            });
        }

        function resetFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('statusFilter').value = '';
            document.getElementById('typeFilter').value = '';
            currentPage = 1;
            loadOrders();
        }

        function exportOrders() {
            window.location.href = '/admin/sim-network-orders/export';
        }

        function getStatusBadge(status) {
            const badges = {
                0: '<span class="badge-status badge-pending">Pending</span>',
                1: '<span class="badge-status badge-processing">Processing</span>',
                2: '<span class="badge-status badge-completed">Completed</span>',
                3: '<span class="badge-status badge-rejected">Rejected</span>'
            };
            return badges[status] || `<span class="badge-status">${status}</span>`;
        }

        function getTypeBadge(type) {
            const services = {
                1: '<span class="badge bg-primary">কল লিস্ট</span>',
                2: '<span class="badge bg-danger">রবি SMS</span>',
                3: '<span class="badge bg-success">বাংলালিংক SMS</span>',
                4: '<span class="badge bg-info">লোকেশন</span>',
                5: '<span class="badge bg-warning text-dark">NID সার্চ</span>',
                6: '<span class="badge bg-secondary">IMEI লোকেশন</span>',
                7: '<span class="badge bg-dark">IMEI এক্টিভ</span>',
                8: '<span class="badge bg-primary">IMEI সার্চ</span>',
                9: '<span class="badge bg-success">বিকাশ</span>',
                10: '<span class="badge bg-danger">নগদ</span>',
                11: '<span class="badge bg-info">রকেট</span>'
            };
            return services[type] || `<span class="badge bg-secondary">${type}</span>`;
        }

        function getServiceName(type) {
            const names = {
                1: 'কল লিস্ট ৩ মাস',
                2: 'রবি/এয়ারটেল SMS',
                3: 'বাংলালিংক SMS',
                4: 'নাম্বার টু লোকেশন',
                5: 'NID টু নাম্বার',
                6: 'IMEI টু লোকেশন',
                7: 'IMEI টু এক্টিভ',
                8: 'নাম্বার টু IMEI',
                9: 'বিকাশ ইনফো',
                10: 'নগদ ইনফো',
                11: 'রকেট ইনফো'
            };
            return names[type] || 'Unknown';
        }

        function formatFormData(formData) {
            try {
                if (typeof formData === 'string') {
                    formData = JSON.parse(formData);
                }
                
                if (formData.number) return formData.number;
                if (formData.bkash_number) return formData.bkash_number;
                if (formData.nagad_number) return formData.nagad_number;
                if (formData.rocket_number) return formData.rocket_number;
                if (formData.nid_10) return 'NID: ' + formData.nid_10;
                if (formData.nid_17) return 'NID: ' + formData.nid_17;
                if (formData.imei_1) return 'IMEI: ' + formData.imei_1;
                
                return 'View Details';
            } catch (e) {
                return 'N/A';
            }
        }

        function formatFormDataDetailed(formData) {
            try {
                if (typeof formData === 'string') {
                    formData = JSON.parse(formData);
                }
                
                let html = '<ul class="list-unstyled mb-0">';
                for (let [key, value] of Object.entries(formData)) {
                    if (value) {
                        html += `<li><strong>${key}:</strong> ${value}</li>`;
                    }
                }
                html += '</ul>';
                return html;
            } catch (e) {
                return 'N/A';
            }
        }

        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
            return new Date(dateString).toLocaleDateString('en-US', options);
        }
    </script>
</body>
</html>
<?php /**PATH /home/ifixfast24/public_html/resources/views/admin/sim_network_order/index.blade.php ENDPATH**/ ?>