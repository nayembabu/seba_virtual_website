<aside class="left-sidebar" data-sidebarbg="skin6">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar" data-sidebarbg="skin6">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">

               
                    <li class="sidebar-item">
                        <a class="sidebar-link" href="<?php echo e(route('mod.index')); ?>" aria-expanded="false">
                            <i data-feather="home" class="feather-icon"></i>
                            <span class="hide-menu"><?php echo app('translator')->get('Dashboard'); ?></span>
                        </a>
                    </li>
                    
                      <li class="sidebar-item <?php echo e(menuActive(['mod.applications'],3)); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('mod.applications')); ?>" aria-expanded="false">
                           <i class="fas fa-file"></i>
                            <span class="hide-menu"><?php echo app('translator')->get('Applications'); ?> ( <span style="color:red" id="tt"> <?php echo e(get_pending_app_count()); ?> </span> ) </span>
                        </a>
                    </li>
                    
                     <li class="sidebar-item <?php echo e(menuActive(['mod.my-applications'],3)); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('mod.my-applications')); ?>" aria-expanded="false">
                           <i class="fas fa-file"></i>
                            <span class="hide-menu"><?php echo app('translator')->get('My Applications'); ?></span>
                        </a>
                    </li>
               
                
                    
                    
            
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
<?php /**PATH /home/ifixfast24/public_html/resources/views/mod/layouts/sidebar.blade.php ENDPATH**/ ?>