

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get($title ?? 'Edit Sign To Server Entry'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            <h4 class="mb-3"><?php echo app('translator')->get($title ?? 'Edit Entry'); ?></h4>

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <form action="<?php echo e(route('user.sign-to-server.update', $signToServer->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="id_number">ID Number</label>
                            <input type="text" name="id_number" id="id_number" class="form-control" value="<?php echo e(old('id_number', $signToServer->id_number)); ?>" required>
                            <?php $__errorArgs = ['id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="pin_number">PIN Number</label>
                            <input type="text" name="pin_number" id="pin_number" class="form-control" value="<?php echo e(old('pin_number', $signToServer->pin_number)); ?>" required>
                            <?php $__errorArgs = ['pin_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="name_bangla">Name (Bangla)</label>
                            <input type="text" name="name_bangla" id="name_bangla" class="form-control" value="<?php echo e(old('name_bangla', $signToServer->name_bangla)); ?>" required>
                            <?php $__errorArgs = ['name_bangla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="name_english">Name (English)</label>
                            <input type="text" name="name_english" id="name_english" class="form-control" value="<?php echo e(old('name_english', $signToServer->name_english)); ?>" required>
                            <?php $__errorArgs = ['name_english'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="date_of_birth">Date of Birth</label>
                            <input type="date" name="date_of_birth" id="date_of_birth" class="form-control" value="<?php echo e(old('date_of_birth', $signToServer->date_of_birth)); ?>">
                            <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e(old('phone', $signToServer->phone)); ?>" required>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="mb-3" id="bn_show" style="display:none">
                            <label>Date of Birth:</label>
                            <input type="text" class="form-control" placeholder="Birth Number" name="date_of_birth" value="<?php echo e(old('birth_no', $signToServer->birth_no ?? '')); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Father's Name:</label>
                            <input type="text" class="form-control" placeholder="Father's Name" name="father_name" value="<?php echo e(old('father_name', $signToServer->father_name)); ?>">
                        </div>
                        <div class="mb-3">
                            <label>Father's ID:</label>
                            <input type="text" class="form-control" placeholder="Father's ID" name="father_id" value="<?php echo e(old('father_id', $signToServer->father_id)); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Mother's Name:</label>
                            <input type="text" class="form-control" placeholder="Mother's Name" name="mother_name" value="<?php echo e(old('mother_name', $signToServer->mother_name)); ?>">
                        </div>
                        <div class="mb-3">
                            <label>Mother's ID:</label>
                            <input type="text" class="form-control" placeholder="Mother's ID" name="mother_id" value="<?php echo e(old('mother_id', $signToServer->mother_id)); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Spouse's Name:</label>
                            <input type="text" class="form-control" placeholder="Spouse Name" name="spouse_name" value="<?php echo e(old('spouse_name', $signToServer->spouse_name)); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Place of Birth:</label>
                            <input type="text" class="form-control" placeholder="Birth Place" name="birth_place" value="<?php echo e(old('birth_place', $signToServer->place_of_birth ?? $signToServer->birth_place ?? '')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="present_address">Present Address</label>
                            <textarea name="present_address" id="present_address" class="form-control" rows="3"><?php echo e(old('present_address', $signToServer->present_address)); ?></textarea>
                            <?php $__errorArgs = ['present_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="photo">Photo</label>
                            <input type="file" name="photo" id="photo" class="form-control-file">
                            <?php if($signToServer->photo): ?>
                                <?php
                                    $photoUrl = url('public/sign_to_server/' . basename($signToServer->photo));
                                ?>
                                <div class="mt-2">
                                    <a href="<?php echo e($photoUrl); ?>" target="_blank"><img src="<?php echo e($photoUrl); ?>" alt="photo" style="max-width:160px;max-height:160px;"></a>
                                </div>
                            <?php endif; ?>
+                            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="signature">Signature</label>
                            <input type="file" name="signature" id="signature" class="form-control-file">
                            <?php if($signToServer->signature): ?>
                                <?php
                                    $sigUrl = url('public/sign_to_server/' . basename($signToServer->signature));
                                ?>
                                <div class="mt-2">
                                    <a href="<?php echo e($sigUrl); ?>" target="_blank"><img src="<?php echo e($sigUrl); ?>" alt="signature" style="max-width:160px;max-height:80px;"></a>
                                </div>
                            <?php endif; ?>
+                            <?php $__errorArgs = ['signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

    

                        <div class="mb-3">
                            <label>Religion:</label>
                            <select class="form-control" name="religion">
                                <option value="">Select</option>
                                <option value="islam" <?php echo e(old('religion', $signToServer->religion) == 'islam' ? 'selected' : ''); ?>>ইসলাম</option>
                                <option value="hinduism" <?php echo e(old('religion', $signToServer->religion) == 'hinduism' ? 'selected' : ''); ?>>হিন্দু</option>
                                <option value="christianity" <?php echo e(old('religion', $signToServer->religion) == 'christianity' ? 'selected' : ''); ?>>খ্রিস্টান</option>
                                <option value="buddhism" <?php echo e(old('religion', $signToServer->religion) == 'buddhism' ? 'selected' : ''); ?>>বৌদ্ধ</option>
                                <option value="other" <?php echo e(old('religion', $signToServer->religion) == 'other' ? 'selected' : ''); ?>>অন্যান্য</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label>Blood Group:</label>
                            <select class="form-control" name="blood_group">
                                <?php $bg = old('blood_group', $signToServer->blood_group); ?>
                                <option value="Unknown" <?php echo e($bg == 'Unknown' ? 'selected' : ''); ?>>অজানা</option>
                                <option value="A+" <?php echo e($bg == 'A+' ? 'selected' : ''); ?>>A+</option>
                                <option value="A-" <?php echo e($bg == 'A-' ? 'selected' : ''); ?>>A-</option>
                                <option value="B+" <?php echo e($bg == 'B+' ? 'selected' : ''); ?>>B+</option>
                                <option value="B-" <?php echo e($bg == 'B-' ? 'selected' : ''); ?>>B-</option>
                                <option value="O+" <?php echo e($bg == 'O+' ? 'selected' : ''); ?>>O+</option>
                                <option value="O-" <?php echo e($bg == 'O-' ? 'selected' : ''); ?>>O-</option>
                                <option value="AB+" <?php echo e($bg == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                                <option value="AB-" <?php echo e($bg == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label>Occupation:</label>
                            <input type="text" class="form-control" placeholder="Occupation" name="occupation" value="<?php echo e(old('occupation', $signToServer->occupation)); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Education:</label>
                            <input type="text" class="form-control" placeholder="Educational Qualification" name="education" value="<?php echo e(old('education', $signToServer->education)); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Form No.:</label>
                            <input type="text" class="form-control" placeholder="Form No." name="form_no" value="<?php echo e(old('form_no', $signToServer->form_no)); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Voter No.:</label>
                            <input type="text" class="form-control" placeholder="Voter No." name="voter_no" value="<?php echo e(old('voter_no', $signToServer->voter_no)); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Voter Area:</label>
                            <input type="text" class="form-control" placeholder="Voter Area" name="voter_area" value="<?php echo e(old('voter_area', $signToServer->voter_area)); ?>">
                        </div>

                        <div class="mb-3">
                            <label>Gender:</label>
                            <select class="form-control" name="gender">
                                <?php $g = old('gender', $signToServer->gender); ?>
                                <option value="">Select</option>
                                <option value="male" <?php echo e(strtolower($g) == 'male' ? 'selected' : ''); ?>>পুরুষ</option>
                                <option value="female" <?php echo e(strtolower($g) == 'female' ? 'selected' : ''); ?>>মহিলা</option>
                                <option value="other" <?php echo e(strtolower($g) == 'other' ? 'selected' : ''); ?>>অন্যান্য</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="permanent_address">Permanent Address</label>
                            <textarea name="permanent_address" id="permanent_address" class="form-control" rows="3"><?php echo e(old('permanent_address', $signToServer->permanent_address)); ?></textarea>
                            <?php $__errorArgs = ['permanent_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                </div>

                <div class="text-right">
                    <button class="btn btn-primary">Update</button>
                </div>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/sign-to-server/edit.blade.php ENDPATH**/ ?>