
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('login', 'active'); ?>
<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<style>
    .login-page {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        background: linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%);
        padding: 20px;
    }

    .login-form {
        background: rgba(255, 255, 255, 0.1);
        padding: 40px;
        border-radius: 15px;
        backdrop-filter: blur(10px);
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
        border: 1px solid rgba(255, 255, 255, 0.18);
        width: 100%;
        max-width: 400px;
    }

    .logo {
        transition: transform 0.3s ease;
    }

    .logo img {
        border-radius: 50%;
        background: white;
        padding: 15px;
        box-shadow: 0 0 15px rgba(255, 255, 255, 0.1);
    }

    .logo:hover {
        transform: scale(1.05);
    }

    .form-group {
        margin-bottom: 25px;
        position: relative;
    }

    .form-control {
        background: rgba(255, 255, 255, 0.05) !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        border-radius: 8px !important;
        color: #fff !important;
        padding: 12px 20px !important;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        background: rgba(255, 255, 255, 0.1) !important;
        border-color: rgba(255, 255, 255, 0.5) !important;
        box-shadow: 0 0 15px rgba(255, 255, 255, 0.1) !important;
    }

    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.6);
    }

    .btn {
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 600;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }

    .btn-primary {
        background: linear-gradient(45deg, #4a90e2, #63b3ed);
        border: none;
    }

    .btn-primary:hover {
        background: linear-gradient(45deg, #63b3ed, #4a90e2);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(74, 144, 226, 0.3);
    }

    .btn-success {
        background: linear-gradient(45deg, #48bb78, #68d391);
        border: none;
    }

    .btn-success:hover {
        background: linear-gradient(45deg, #68d391, #48bb78);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(72, 187, 120, 0.3);
    }

    .button-space {
        margin-bottom: 15px;
    }

    a {
        color: rgba(255, 255, 255, 0.8) !important;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    a:hover {
        color: #fff !important;
        text-decoration: none;
    }

    .alert {
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .preloader {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 40px;
        height: 40px;
        border: 4px solid rgba(255, 255, 255, 0.1);
        border-left-color: #4a90e2;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        z-index: 9999;
        display: none;
    }

    @keyframes  spin {
        0% { transform: translate(-50%, -50%) rotate(0deg); }
        100% { transform: translate(-50%, -50%) rotate(360deg); }
    }

    .form-floating {
        position: relative;
    }

    .form-floating label {
        color: rgba(255, 255, 255, 0.6);
    }
</style>

<div class="login-page">
    <div class="login-form">
        <form method="post" action="<?php echo e(route('login.submit')); ?>">
            <?php echo csrf_field(); ?>

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <div class="logo text-center mb-4">
                <img src="<?php echo e(asset('assets/uploads/logo/Screenshot_2025-10-18_021531-removebg-preview.png')); ?>" style="width: 200px;" alt="Logo">
            </div>

            <div class="form-group">
                <div class="form-floating">
                    <input class="form-control" type="email" id="email" name="username" placeholder="Email">
                    <i class="fas fa-envelope position-absolute" style="right: 15px; top: 15px; color: rgba(255,255,255,0.5);"></i>
                </div>
            </div>

            <div class="form-group">
                <div class="form-floating">
                    <input class="form-control" type="password" id="password" name="password" placeholder="Password">
                    <i class="fas fa-lock position-absolute" style="right: 15px; top: 15px; color: rgba(255,255,255,0.5);"></i>
                </div>
            </div>

            <button class="btn btn-primary btn-block w-100 button-space" type="submit">
                <i class="fas fa-sign-in-alt me-2"></i> Log In
            </button>

            <?php if(get_settings()->register_option == '1'): ?>
            <div class="text-center button-space">
                <a class="btn btn-success btn-block w-100" href="<?php echo e(route('register')); ?>">
                    <i class="fas fa-user-plus me-2"></i> Register
                </a>
            </div>
            <?php endif; ?>

            <div class="text-center mt-3">
                <a href="<?php echo e(route('password.request')); ?>" class="text-light">
                    <i class="fas fa-key me-1"></i> Forgot Password?
                </a>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>