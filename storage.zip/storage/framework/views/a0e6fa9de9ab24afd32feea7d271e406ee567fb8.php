
<?php $__env->startSection('title'); ?>
    Smart Card List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <?php if($notification): ?>
                <div class="alert alert-info">
                    <?php echo e($notification); ?>

                </div>
            <?php endif; ?>
            <div class="text-right">
                <a href="<?php echo e(route('user.smartcard.create')); ?>" class="btn btn-success"> <i class="fas fa-plus"></i> Add New Smart Card </a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>No.</th>
                            <th>Name (Bangla)</th>
                            <th>Name (English)</th>
                            <th>NID Number</th>
                            <th>Date of Birth</th>
                            <th>Issue Date</th>
                            <th>Download</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $smartcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($smartcards->firstItem() + $key); ?></td>
                                <td><?php echo e($card->name_bn); ?></td>
                                <td><?php echo e($card->name_en); ?></td>
                                <td><?php echo e($card->nid_no); ?></td>
                                <td><?php echo e($card->date_of_birth->format('d/m/Y')); ?></td>
                                <td><?php echo e($card->issue_date->format('d/m/Y')); ?></td>
                               
                                    <td data-label="<?php echo app('translator')->get('Certificate'); ?>">
                                <a href="<?php echo e(route('user.smartcard.show',  $card->id)); ?>" class="btn btn-primary" target="_blank"> <i class="fas fa-print"></i> Print</a>
                                </td>
                                <td>
                                    
                                    <div class="text-lg-center text-right">
                                        
                                        <a href="<?php echo e(route('user.smartcard.edit',  $card->id)); ?>" class="btn btn-info"> <i class="fas fa-pencil-alt"></i> Edit </a>

                                         <form style="display:inline-block" action="<?php echo e(route('user.smartcard.destroy',  $card->id)); ?>" method="post" onsubmit="return confirm('Do you really want to delete this?');">
                                    <?php echo csrf_field(); ?> 
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger"> <i class="fas fa-trash"></i> Delete </button>
                                </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">No Smart Cards found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($smartcards->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
    .badge {
        font-size: 0.9em;
        padding: 5px 10px;
    }
    .btn-group .btn {
        margin: 0 2px;
    }
    .alert {
        border-radius: 0.25rem;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        // Auto hide alerts after 5 seconds
        setTimeout(function() {
            $('.alert:not(.alert-info)').fadeOut('slow');
        }, 5000);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/smartcard/index.blade.php ENDPATH**/ ?>