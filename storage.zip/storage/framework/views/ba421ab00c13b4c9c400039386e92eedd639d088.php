<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>ID Card Orders Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            position: fixed;
         function getStatusBadge(status) {
            const badges = {
                'pending': '<span class="badge-status badge-pending">Pending</span>',
                'processing': '<span class="badge-status badge-processing">Processing</span>',
                'completed': '<span class="badge-status badge-completed">Completed</span>',
                'rejected': '<span class="badge-status badge-rejected">Rejected</span>'
            };
            return badges[status] || `<span class="badge-status">${status}</span>`;
        }  left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            z-index: 1000;
            overflow-y: auto;
            transition: all 0.3s;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0 10px;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.2);
            color: white;
            transform: translateX(5px);
        }
        .sidebar-menu a i {
            margin-right: 12px;
            font-size: 18px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
            padding: 20px;
            transition: all 0.3s;
        }
        .top-navbar {
            background: white;
            padding: 15px 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            text-align: center;
            transition: all 0.3s;
        }
        .stat-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-5px);
        }
        .stat-card h6 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .stat-card h3 {
            color: #667eea;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .stat-card .icon {
            font-size: 32px;
            color: #667eea;
            opacity: 0.2;
        }
        .badge-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-approved {
            background: #d4edda;
            color: #155724;
        }
        .badge-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .badge-completed {
            background: #d1ecf1;
            color: #0c5460;
        }
        .badge-processing {
            background: #e7d4f5;
            color: #5a21b5;
        }
        .table-wrapper {
            overflow-x: auto;
        }
        .table thead {
            background: #f8f9fa;
        }
        .table thead th {
            border: none;
            color: #667eea;
            font-weight: 600;
            padding: 15px;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .table tbody td {
            border: none;
            padding: 15px;
            vertical-align: middle;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
        }
        .table tbody tr:hover {
            background: #f9f9f9;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .action-buttons .btn {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 5px;
        }
        .btn-action {
            background: #667eea;
            color: white;
            border: none;
        }
        .btn-action:hover {
            background: #5568d3;
            color: white;
        }
        .btn-reject {
            background: #dc3545;
            color: white;
            border: none;
        }
        .btn-reject:hover {
            background: #c82333;
            color: white;
        }
        .btn-complete {
            background: #28a745;
            color: white;
            border: none;
        }
        .btn-complete:hover {
            background: #218838;
            color: white;
        }
        .expand-icon {
            cursor: pointer;
            transition: transform 0.3s;
            color: #667eea;
        }
        .expand-icon.expanded {
            transform: rotate(180deg);
        }
        .details-section {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 10px;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 15px;
        }
        .detail-item {
            padding: 12px;
            background: white;
            border-radius: 5px;
            border-left: 3px solid #667eea;
        }
        .detail-item strong {
            color: #667eea;
            display: block;
            font-size: 12px;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        .detail-item span {
            color: #333;
            font-size: 14px;
        }
        .search-box {
            position: relative;
        }
        .search-box input {
            padding-left: 35px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-group select {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 8px 12px;
        }
        
        /* Mobile Sidebar Toggle Button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transition: all 0.3s;
        }
        .sidebar-toggle:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        .sidebar-toggle i {
            font-size: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar-toggle {
                display: block;
            }
            .sidebar {
                width: 0;
                padding: 0;
            }
            .main-content {
                margin-left: 0;
                padding: 10px;
                padding-top: 70px;
            }
            .stat-card {
                margin-bottom: 15px;
            }
            .action-buttons {
                flex-direction: column;
            }
            .action-buttons .btn {
                width: 100%;
            }
            .details-grid {
                grid-template-columns: 1fr;
            }
            .top-navbar {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Mobile Menu Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Page Title with Bengali -->
        <div class="page-header mb-4">
            <div class="d-flex align-items-center gap-3 mb-3">
                <div style="font-size: 28px; color: #667eea;">
                    <i class="fas fa-id-card"></i>
                </div>
                <div>
                    <h2 class="mb-1" style="color: #333;">এনআইডি অর্ডার ম্যানেজমেন্ট</h2>
                    <p class="text-muted mb-0" style="font-size: 13px;">সকল এনআইডি অর্ডারের তালিকা এবং পরিচালনা</p>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h3 id="stat-total">0</h3>
                        <p class="mb-0">Total Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h3 id="stat-pending">0</h3>
                        <p class="mb-0">Pending</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h3 id="stat-approved">0</h3>
                        <p class="mb-0">Approved</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h3 id="stat-completed">0</h3>
                        <p class="mb-0">Completed</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="searchInput" 
                            placeholder="Search orders by user name, phone, NID..."
                        >
                    </div>
                    <div class="col-md-4">
                        <select id="statusFilter" class="form-select">
                            <option value="">All Orders</option>
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orders Table -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0">সকল এনআইডি অর্ডার</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th></th>
                                <th>Order ID</th>
                                <th>User Name</th>
                                <th>NID</th>
                                <th>Form Type</th>
                                <th>Cost</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>PDF Upload</th>
                                <th>Notes</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="ordersTableBody">
                            <!-- Orders will be loaded here -->
                            <tr>
                                <td colspan="10" class="text-center py-4 text-muted">
                                    <i class="fas fa-spinner fa-spin"></i> Loading orders...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white">
                <nav>
                    <ul class="pagination mb-0" id="pagination">
                        <!-- Pagination will be loaded here -->
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- Rejection Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="rejectModalLabel">
                        <i class="fas fa-times-circle"></i> অর্ডার বাতিল করুন
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
               <div class="modal-body">
                    <p class="mb-3"><strong>বাতিল করার কারণ নির্বাচন করুন:</strong></p>
                    <div class="d-flex flex-column gap-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason1" value="নথিপত্র অসম্পূর্ণ বা অবৈধ">
                            <label class="form-check-label" for="reason1">
                                নথিপত্র অসম্পূর্ণ বা অবৈধ
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason2" value="ডকুমেন্টের মান দুর্বল">
                            <label class="form-check-label" for="reason2">
                                ডকুমেন্টের মান দুর্বল
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason3" value="তথ্য মিলছে না">
                            <label class="form-check-label" for="reason3">
                                তথ্য মিলছে না
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="rejectionReason" id="reason4" value="ব্যবহারকারীর বাতিলের অনুরোধ">
                            <label class="form-check-label" for="reason4">
                                ব্যবহারকারীর বাতিলের অনুরোধ
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল করুন</button>
                    <button type="button" class="btn btn-danger" onclick="confirmReject()">
                        <i class="fas fa-check"></i> নিশ্চিত করুন
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentPage = 1;
        let currentRejectOrderId = null;
        let currentUploadOrderId = null;

        // Load orders on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadOrders();
            setupEventListeners();
        });

        function setupEventListeners() {
            document.getElementById('searchInput').addEventListener('keyup', function() {
                currentPage = 1;
                loadOrders();
            });

            document.getElementById('statusFilter').addEventListener('change', function() {
                currentPage = 1;
                loadOrders();
            });
        }

        function loadOrders(page = 1) {
            currentPage = page;
            const search = document.getElementById('searchInput').value;
            const status = document.getElementById('statusFilter').value;

            const queryParams = new URLSearchParams();
            if (search) queryParams.append('search', search);
            if (status) queryParams.append('status', status);
            queryParams.append('page', page);

            fetch(`/admin/id-card-orders/get-orders?${queryParams}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                renderOrders(data.orders);
                updateStats(data.stats);
                updatePagination(data.pagination);
            })
            .catch(error => {
                console.error('Error loading orders:', error);
            });
        }

        function renderOrders(orders) {
            const tbody = document.getElementById('ordersTableBody');
            
            if (orders.length === 0) {
                tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4 text-muted">No orders found</td></tr>';
                return;
            }

            tbody.innerHTML = orders.map(order => `
                <tr class="order-row" onclick="toggleDetails(${order.id})" style="cursor: pointer;">
                    <td>
                        <i class="fas fa-chevron-right expand-icon-${order.id}" id="icon-${order.id}"></i>
                    </td>
                    <td>
                        <strong>#${order.id}</strong>
                    </td>
                    <td>
                        <strong>${order.name}</strong><br>
                        <small class="text-muted">${order.email || 'N/A'}</small>
                    </td>
                    <td>${order.nid || 'N/A'}</td>
                    <td>
                        <span class="badge bg-info">${order.form_type_name || order.form_type}</span>
                    </td>
                    <td><strong>৳ ${parseFloat(order.cost).toFixed(2)}</strong></td>
                    <td>${getStatusBadge(order.status)}</td>
                    <td>${formatDate(order.created_at)}</td>
                    <td>
                        ${order.admin_note ? 
                            `<a href="/admin/id-card-orders/${order.id}/download-pdf" class="btn btn-sm btn-success" title="Download PDF">
                                <i class="fas fa-download"></i> Download
                            </a>` 
                            : (order.status === 'pending' || order.status === 'processing') ?
                            `<button class="btn btn-sm btn-primary" onclick="triggerFileUpload(${order.id}); event.stopPropagation();" title="Upload PDF">
                                <i class="fas fa-upload"></i> Upload
                            </button>
                            <input type="file" id="fileInput-${order.id}" accept=".pdf" style="display:none;" onchange="handleFileUpload(${order.id})">`
                            : ''
                        }
                    </td>
                    <td onclick="event.stopPropagation();">
                        <div class="input-group input-group-sm">
                            <input type="text" id="notes-${order.id}" class="form-control" placeholder="Add note..." value="${(order.text || '').replace(/"/g, '&quot;')}" onkeypress="if(event.key==='Enter') saveNotes(${order.id})">
                            <button class="btn btn-outline-primary" type="button" onclick="saveNotes(${order.id})" title="Save Note">
                                Save
                            </button>
                        </div>
                    </td>
                    <td onclick="event.stopPropagation();">
                        ${order.status === 'pending' ? 
                            `<button class="btn btn-sm btn-success" onclick="processOrder(${order.id}, '${order.status}')" title="Approve">
                                <i class="fas fa-check"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="rejectOrder(${order.id})" title="Reject">
                                <i class="fas fa-times"></i>
                            </button>` 
                            : order.status === 'processing' ? 
                            `<button class="btn btn-sm btn-primary" onclick="processOrder(${order.id}, '${order.status}')" title="Complete">
                                <i class="fas fa-check-double"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="rejectOrder(${order.id})" title="Reject">
                                <i class="fas fa-times"></i>
                            </button>` 
                            : ''
                        }
                    </td>
                </tr>

                <!-- Expandable Details Row -->
                <tr id="details-row-${order.id}" class="details-row" style="display: none;">
                    <td colspan="11">
                        <div class="details-panel p-4" style="background: #f9f9f9; border-left: 4px solid #667eea;">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <h6 class="mb-3"><i class="fas fa-user-circle"></i> User Information</h6>
                                    <p><strong>Order ID:</strong> #${order.id}</p>
                                    <p><strong>User Name:</strong> ${order.name}</p>
                                    <p><strong>Email:</strong> ${order.email || 'N/A'}</p>
                                    <p><strong>NID:</strong> ${order.nid || 'N/A'}</p>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="mb-3"><i class="fas fa-info-circle"></i> Order Information</h6>
                                    <p><strong>Form Type:</strong> ${order.form_type_name || order.form_type}</p>
                                    <p><strong>Cost:</strong> ৳ ${parseFloat(order.cost).toFixed(2)}</p>
                                    <p><strong>Status:</strong> ${getStatusBadge(order.status)}</p>
                                    <p><strong>Created:</strong> ${formatDate(order.created_at)}</p>
                                </div>
                            </div>

                            <hr>

                            <h6 class="mb-3"><i class="fas fa-list"></i> Additional Details</h6>
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <div class="p-2" style="background: white; border-radius: 5px; border-left: 3px solid #667eea;">
                                        <strong>Date of Birth:</strong><br>
                                        <span class="text-muted">${formatDate(order.dob) || 'N/A'}</span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="p-2" style="background: white; border-radius: 5px; border-left: 3px solid #667eea;">
                                        <strong>Last Updated:</strong><br>
                                        <span class="text-muted">${formatDate(order.updated_at)}</span>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-end gap-2">
                                <button class="btn btn-sm btn-secondary" onclick="toggleDetails(${order.id})">
                                    <i class="fas fa-times"></i> Close
                                </button>
                            </div>
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        function toggleDetails(orderId) {
            const detailsRow = document.getElementById('details-row-' + orderId);
            const icon = document.getElementById('icon-' + orderId);
            
            if (detailsRow.style.display === 'none' || !detailsRow.style.display) {
                detailsRow.style.display = 'table-row';
                icon.classList.remove('fa-chevron-right');
                icon.classList.add('fa-chevron-down');
            } else {
                detailsRow.style.display = 'none';
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-right');
            }
        }

        function updateStats(stats) {
            document.getElementById('stat-total').textContent = stats.total;
            document.getElementById('stat-pending').textContent = stats.pending;
            document.getElementById('stat-approved').textContent = stats.processing;
            document.getElementById('stat-completed').textContent = stats.completed;
        }

        function updatePagination(pagination) {
            const paginationEl = document.getElementById('pagination');
            if (!pagination || pagination.last_page <= 1) {
                paginationEl.innerHTML = '';
                return;
            }

            let html = '';
            if (pagination.current_page > 1) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="loadOrders(${pagination.current_page - 1})">Previous</a></li>`;
            }

            for (let i = 1; i <= pagination.last_page; i++) {
                html += `<li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                    <a class="page-link" href="#" onclick="loadOrders(${i})">${i}</a>
                </li>`;
            }

            if (pagination.current_page < pagination.last_page) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="loadOrders(${pagination.current_page + 1})">Next</a></li>`;
            }

            paginationEl.innerHTML = html;
        }

        function processOrder(orderId, currentStatus) {
            // If pending, mark as processing. If processing, mark as completed
            const newStatus = currentStatus === 'pending' ? 'processing' : 'completed';
            updateOrderStatus(orderId, newStatus);
        }

        function rejectOrder(orderId) {
            currentRejectOrderId = orderId;
            const rejectModal = new bootstrap.Modal(document.getElementById('rejectModal'));
            rejectModal.show();
        }

        function confirmReject() {
            if (!currentRejectOrderId) return;

            const reason = document.querySelector('input[name="rejectionReason"]:checked');

            if (!reason) {
                return;
            }

            updateOrderStatus(currentRejectOrderId, 'rejected', reason.value);
            bootstrap.Modal.getInstance(document.getElementById('rejectModal')).hide();
        }

        function updateOrderStatus(orderId, status, reason = '') {
            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/admin/id-card-orders/${orderId}/update-status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    status: status,
                    reason: reason
                })
            })
            .then(response => response.json())
            .then(data => {
                loadOrders(currentPage);
                clearRejectionForm();
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        function clearRejectionForm() {
            document.querySelectorAll('input[name="rejectionReason"]').forEach(radio => {
                radio.checked = false;
            });
        }

        function resetFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('statusFilter').value = '';
            currentPage = 1;
            loadOrders();
        }

        function saveNotes(orderId) {
            const notesInput = document.getElementById('notes-' + orderId);
            const noteText = notesInput.value.trim();
            
            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/admin/id-card-orders/${orderId}/save-notes`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    text: noteText
                })
            })
            .then(response => response.json())
            .then(data => {
                // Auto-update status to completed after saving notes
                updateOrderStatus(orderId, 'completed');
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        function getStatusBadge(status) {
            const badges = {
                'pending': '<span style="background: #fff3cd; color: #856404; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: 500;">Pending</span>',
                'processing': '<span style="background: #e7d4f5; color: #5a21b5; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: 500;">Processing</span>',
                'completed': '<span style="background: #d1ecf1; color: #0c5460; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: 500;">Completed</span>',
                'rejected': '<span style="background: #f8d7da; color: #721c24; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: 500;">Rejected</span>'
            };
            return badges[status] || `<span class="badge bg-secondary">${status}</span>`;
        }

        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
            return new Date(dateString).toLocaleDateString('en-US', options);
        }

        function triggerFileUpload(orderId) {
            const fileInput = document.getElementById('fileInput-' + orderId);
            fileInput.click();
        }

        function handleFileUpload(orderId) {
            const fileInput = document.getElementById('fileInput-' + orderId);
            const file = fileInput.files[0];

            if (!file) {
                return;
            }

            // Validate file type
            if (file.type !== 'application/pdf') {
                return;
            }

            // Validate file size (5MB = 5242880 bytes)
            if (file.size > 5242880) {
                return;
            }

            const formData = new FormData();
            formData.append('pdf_file', file);

            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/admin/id-card-orders/${orderId}/upload-pdf`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Auto-update status to completed after PDF upload
                updateOrderStatus(orderId, 'completed');
                fileInput.value = '';
            })
            .catch(error => {
                console.error('Error:', error);
                fileInput.value = '';
            });
        }
    </script>
</body>
</html>

<?php /**PATH /home/ifixfast24/public_html/resources/views/admin/id-card-order/index.blade.php ENDPATH**/ ?>