
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get($title); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            
            
         
               <div class="text-right">
                <a href="<?php echo e(route('user.sign-to-server.create')); ?>" class="btn btn-success"> <i class="fas fa-plus uppercase "></i> CREATE NEW ENTRY </a>
               </div>
               
                 <div style="overflow-x:auto;">
                <table class="categories-show-table table table-hover table-striped table-bordered" >
                    <thead class="thead-dark">
                     <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Photo</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID Number</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name (Bangla)</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name (English)</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>


                            <td data-label="<?php echo app('translator')->get('Photo'); ?>" class="text-center">
                                <?php if(!empty($data->photo)): ?>
                                    <?php
                                        $photoPath = $data->photo;
                                        if (\Illuminate\Support\Facades\Storage::disk('public')->exists($photoPath)) {
                                            try {
                                                $photoContents = \Illuminate\Support\Facades\Storage::disk('public')->get($photoPath);
                                                $mime = finfo_buffer(finfo_open(), $photoContents, FILEINFO_MIME_TYPE) ?: 'image/jpeg';
                                                $photoBase64 = 'data:' . $mime . ';base64,' . base64_encode($photoContents);
                                            } catch (\Exception $e) {
                                                $photoBase64 = null;
                                            }
                                        }
                                    ?>
                                    <?php if(!empty($photoBase64)): ?>
                                        <img src="<?php echo e($photoBase64); ?>" alt="Photo" class="img-thumbnail" style="max-width:60px;max-height:60px;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('storage/' . $data->photo)); ?>" alt="Photo" class="img-thumbnail" style="max-width:60px;max-height:60px;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="img-thumbnail" style="width:60px;height:60px;display:inline-block;background:#f5f5f5;"></div>
                                <?php endif; ?>
                            </td>

                            <td data-label="<?php echo app('translator')->get('ID Number'); ?>">
                               <?php echo e($data->id_number ?? ''); ?>

                            </td>

                            <td data-label="<?php echo app('translator')->get('Name (Bangla)'); ?>">
                               <?php echo e($data->name_bangla ?? ''); ?>

                            </td>

                            <td data-label="<?php echo app('translator')->get('Name (English)'); ?>">
                             <?php echo e($data->name_english ?? ''); ?>

                            </td>

                            <td data-label="<?php echo app('translator')->get('Phone'); ?>">
                                <?php echo e($data->phone ?? ''); ?>

                            </td>
                         
                            
                            <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-lg-center text-right">
        
                                          <a href="<?php echo e(route('user.sign-to-server.show-v1',$data->id)); ?>" class="btn btn-primary" target="_blank">V1</a>
                                            <a href="<?php echo e(route('user.sign-to-server.show-v2',$data->id)); ?>" class="btn btn-primary" target="_blank">V2</a>
                                            <a href="<?php echo e(route('user.sign-to-server.show-v3',$data->id)); ?>" class="btn btn-primary" target="_blank">V3</a>
                               
                                        <a href="<?php echo e(route('user.sign-to-server.edit', $data->id)); ?>" class="btn btn-info"> Edit </a>
                                
                                                                <form style="display:inline-block" action="<?php echo e(route('user.sign-to-server.destroy',$data->id)); ?>" method="post" onsubmit="return confirm('Do you really want to delete this?');">
                                                                                    <?php echo csrf_field(); ?>
                                                                                    <?php echo method_field('DELETE'); ?>
                                                                                 <button class="btn btn-danger"> Delete  </button>
                                                             </form>
                               
                              
                            
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-danger" colspan="9"><?php echo app('translator')->get('No Data'); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                 </div>
                
                <?php echo e($objects->appends(@$_GET)->links('partials.pagination')); ?>

            </div>
        </div>
    </div>
    
    
   
    

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script>
         $(document).on('click', '.recharge', function () {
          
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/user/sign-to-server/index.blade.php ENDPATH**/ ?>