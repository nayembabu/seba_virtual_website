
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("Application List"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .fa-ellipsis-v:before {
            content: "\f142";
        }
    </style>
    
    <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            <br/>
            <table class="categories-show-table table table-hover table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col"><?php echo app('translator')->get('No.'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('ID No'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Name'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Type'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('User'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                        <th scope="col" style="text-align:center"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr style="<?php echo e($application->type == 'Biometric' ? 'background-color: red; color: white;' : ''); ?>">
                            <td data-label="<?php echo app('translator')->get('No.'); ?>">
                                <?php echo e($key + 1); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('ID No'); ?>">
                                <?php echo e($application->nid); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                <?php echo e($application->name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Type'); ?>">
                                <?php echo e($application->type); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('User'); ?>">
                                <?php echo e(@$application->user->name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                <?php if($application->status == '0'): ?>
                                    <b style="color:red">Pending</b>
                                <?php elseif($application->status == '3'): ?>
                                    <b style="color:red">Cancelled ( <?php echo e($application->cancel_reason); ?> )</b>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Date'); ?>">
                                <?php echo e(date('d F Y', strtotime(@$application->created_at))); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-lg-center text-right">
                                <?php if($application->status == '0'): ?>
                                    <form style="display:inline-block" action="<?php echo e(route('mod.accept-application', $application->id)); ?>" method="post" onsubmit="return confirm('Do you really want to accept this application?');">
                                        <?php echo csrf_field(); ?> 
                                        <button class="btn btn-success"> <i class="fas fa-check"></i> Accept </button>
                                    </form>
                                <?php endif; ?>
                                <?php if($application->type == 'Advanced'): ?>
                                    <a data-info='<?php echo $application->extra; ?>' href='javascript:void(0);' class='view-info btn btn-info'> <i class="fas fa-eye"></i> View Info </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-danger" colspan="9"><?php echo app('translator')->get('No Data'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($applications->appends(@$_GET)->links('partials.pagination')); ?>

        </div>
    </div>
    
    <div class="modal fade" id="m-info" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header modal-colored-header bg-primary">
                    <h5 class="modal-title"><?php echo app('translator')->get('Application Info'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                </div>
                <div class="modal-body">
                    <div id="info-html"></div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        // Function to play notification sound
        function playNotificationSound() {
            var audio = new Audio('/assets/admin/noti.mp3');
            var playCount = 0;
            var maxPlays = 3; // Number of times to repeat

            function playSound() {
                audio.play().then(() => {
                    console.log('Sound played successfully');
                    playCount++;
                    if (playCount < maxPlays) {
                        setTimeout(playSound, 1500); // Adjusted to wait 1.5 seconds between repeats
                    }
                }).catch(error => {
                    console.error('Sound playback error:', error);
                });
            }

            playSound();
        }

        // AJAX request to check pending applications
        function checkPendingApplications() {
            $.ajax({
                type: 'POST',
                url: "<?php echo e(secure_url('mod/check-applications')); ?>",  // Ensure the request is HTTPS
                success: function(response) {
                    // Check the response for pending applications count
                    if (response.pending_count > 0) {
                        playNotificationSound(); // Play sound if there are pending applications
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error checking pending applications:', error);
                }
            });
        }

        // Set an interval to check for pending applications every 10 seconds
        setInterval(checkPendingApplications, 10000); // Check every 10 seconds
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mod.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifixfast24/public_html/resources/views/mod/applications.blade.php ENDPATH**/ ?>